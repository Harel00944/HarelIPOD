/* File: app_usb.c
   Why: Full corrected file:
   1) Keep existing menu options 1..8 as-is
   2) Add option 9: VS1053 TEST (sine)
   3) No other functional changes besides making option 9 work
*/

#include "app_usb.h"
#include "sd_mp3_list.h"   // HE: סריקת רשימת קבצי MP3 מה-SD לתפריט K

#include "usbd_cdc_if.h"
#include "st7735.h"
#include "gps_m8q.h"
#include "BNO055.h"
#include "spif.h"
#include "vs1053.h"
#include "main.h"      /* בשביל SD_HandleTypeDef, HAL_SD_*, GPIO */
#include "sd_tests.h"

#include "fatfs.h"
#include "ff.h"

#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include "mp3_player.h"   // HE: נגן MP3 מה-SD ל-VS1053

/* ===== Types ===== */
typedef enum
{
  APP_USB_STATE_MENU              = 0,
  APP_USB_STATE_GPS_SOL           = 1,
  APP_USB_STATE_GPS_RAW           = 2,
  APP_USB_STATE_BNO_EULER         = 3,
  APP_USB_STATE_FLASH_PLAY_SELECT = 99,

  APP_USB_STATE_VS1053_VOL        = 0x90,
  APP_USB_STATE_SD_TEST           = 0xA0, // HE: בדיקות SD מדורגות
  APP_USB_STATE_MP3_LIST          = 0xB0, // HE: מצב תפריט שירים מה-SD
  APP_USB_STATE_MP3_PICK          = 0xB1, // HE: מצב בחירת מספר שיר (קלט משתמש)
  APP_USB_STATE_BNO_QUAT          = 4 ,                                            // HE: מצב הדפסת קווטרניונים
  APP_USB_STATE_BNO_WORLD_ACC = 5   // HE: תאוצה לינארית בעולם

} AppUsbState_t;

/* ===== Defines ===== */
#define LED_D6_GPIO_Port        GPIOC
#define LED_D6_Pin              GPIO_PIN_13

#define LED_BLINK_PERIOD_MS     1000u
#define APP_RX_FIFO_SIZE        512u

#define BNO_DISPLAY_PERIOD_MS     50u
#define BNO_RECORD_PERIOD_MS     1000u
#define BNO_RECORD_DURATION_MS  10000u

#define GPS_SOL_PRINT_PERIOD_MS  1000u
#define CDC_TX_RETRY_TIMEOUT_MS    50u
#define LCD_TOGGLE_PERIOD_MS      1000u

#define APP_FL_BASE_ADDR   0x00200000u
#define APP_FL_META_SIZE   0x00001000u
#define APP_FL_SLOT_SIZE   0x00010000u
#define APP_FL_SLOT_COUNT  16u
#define APP_FL_MAGIC_REC   0x52454331u

#define REC_STATE_IDLE     0
#define REC_STATE_ACTIVE   1
#define REC_STATE_WRITING  2

#define MP3_UI_Y     50u   // HE: פס עדכון
#define MP3_UI_H     40u   // HE: גובה פס
#define MP3_UI_SCALE 3u    // HE: קנה מידה

/* ===== Private module variables ===== */
static uint32_t g_led_last_tick = 0;
static uint8_t  g_led_state = 1;

static uint8_t  g_sd_test_step = 0u;
static uint32_t g_sd_test_t0   = 0u;

static volatile uint8_t  g_rx_fifo[APP_RX_FIFO_SIZE];
static volatile uint16_t g_rx_w = 0;
static volatile uint16_t g_rx_r = 0;

static AppUsbState_t g_state = APP_USB_STATE_MENU;

static uint8_t g_bno_ok = 0;
static uint8_t g_bno_recover_tried = 0;

static SPIF_HandleTypeDef g_spif;
static uint8_t g_spif_inited = 0;

static SPI_HandleTypeDef *g_hspi_flash = NULL;
static GPIO_TypeDef *g_flash_cs_port = NULL;
static uint16_t g_flash_cs_pin = 0;

static uint32_t g_lcd_last_tick = 0;
static uint8_t  g_lcd_toggle = 0;

static uint32_t g_last_gps_sol_tick = 0;
static uint32_t g_last_bno_tick = 0;

static char g_line[32];
static uint8_t g_line_len = 0;

static uint8_t g_rec_state = REC_STATE_IDLE;
static uint32_t g_rec_start_time = 0;
static uint32_t g_rec_sample_count = 0;
static uint32_t g_rec_slot = 0;
static uint32_t g_rec_write_addr = 0;
static uint32_t g_rec_last_sample_time = 0;

static uint8_t  g_rec_map[APP_FL_SLOT_COUNT];
static uint8_t  g_rec_count = 0;

/* VS1053 */
static VS1053_Handle_t g_vs1053;
static uint8_t g_vs1053_attached = 0;
static uint8_t g_vs_sine_running = 0u;
static uint8_t g_vs_waiting_vol  = 0u;

/* SD Card */
static SD_HandleTypeDef *g_hsd = NULL;
static GPIO_TypeDef *g_sd_cd_port = NULL;
static uint16_t g_sd_cd_pin = 0;

static SdMp3List_t g_mp3_list;             // HE: רשימת שירים שנמצאו ב-SD
static uint8_t     g_mp3_list_printed = 0; // HE: הדפסה פעם אחת של התפריט

/* ===== Local structs ===== */
typedef struct __attribute__((packed))
{
  uint32_t magic;
  uint32_t index;
  uint32_t sample_period_ms;
  uint32_t sample_count;
  uint32_t start_time_ms;
  uint32_t end_time_ms;
} APP_FL_RecHeader_t;

typedef struct __attribute__((packed))
{
  int16_t  yaw_x16;
  int16_t  pitch_x16;
  int16_t  roll_x16;
  uint32_t sample_time_ms;
} APP_FL_Sample_t;

/* ===== Forward declarations ===== */
static void APP_PrintMenu(void);
static void APP_ProcessUsbChar(uint8_t ch);
static void SD_Test_StepTick(void); // HE: בדיקת SD בצעדים (Tick)

static void APP_Tx(const char *s);
static void APP_TxLen(const uint8_t *buf, uint16_t len);

static int  APP_RxFifo_Pop(uint8_t *out);
static void APP_RxFifo_Push(uint8_t b);

static void LCD_ToggleText_500ms(void);
static void LED_D6_UpdateFromGPS(void);

static void GPS_PrintSolution_Periodic(void);
static void BNO_PrintEuler_Once(void);

static void FLASH_EnsureInit(void);
static void FLASH_Test_10Sentences(void);
static void FLASH_Test_JEDEC(void);

static void APP_StartRecording(void);
static void APP_StopRecording(void);
static void APP_RecordingTick(void);

static void APP_FL_ListRecordingsAndBuildMap(void);
static uint8_t APP_FL_MapDisplayedIndexToSlot(uint32_t displayed_index_1based, uint32_t *out_slot);
static void APP_FL_PlaySlotToUSB_WithTiming(uint32_t slot);

static void APP_FL_EraseAllRecordings(void);

void APP_USB_SD_Attach(SD_HandleTypeDef *hsd,
                       GPIO_TypeDef *cd_port,
                       uint16_t cd_pin);
static void BNO_PrintWorldLinAcc_Once(void);   // HE: הצהרה קדמית

static void SD_Test_All(void);
static void SD_Test_CardDetect(void);
static void SD_Test_HAL_CID_CSD(void);
static void SD_Test_FatFs(void);
static void SD_Test_CDOnly(void);
static void SD_Test_HAL_Basic(void);

static void APP_PrintMp3ListMenu(void); // HE: תפריט רשימת שירים מה-SD
static void APP_ListSdRoot(void);       // HE: דיבוג שורש SD
static void BNO_PrintQuat_Once(void);                                              // HE: הדפסת קווטרניונים פעם אחת

/* ===== Helpers ===== */
static uint32_t APP_FL_SlotBase(uint32_t slot)
{
  return (APP_FL_BASE_ADDR + APP_FL_META_SIZE + (slot * APP_FL_SLOT_SIZE));
}

static uint8_t APP_FL_HeaderValid(const APP_FL_RecHeader_t *h)
{
  if (!h) return 0;
  if (h->magic != APP_FL_MAGIC_REC) return 0;
  if (h->index >= APP_FL_SLOT_COUNT) return 0;
  if (h->sample_period_ms == 0u) return 0;
  if (h->sample_count == 0u) return 0;
  return 1;
}

/* ===== Public API ===== */
void APP_USB_Init(SPI_HandleTypeDef *hspi_flash,
                  GPIO_TypeDef *flash_cs_port,
                  uint16_t flash_cs_pin,
                  uint8_t bno_ready)
{
  g_hspi_flash = hspi_flash;
  g_flash_cs_port = flash_cs_port;
  g_flash_cs_pin = flash_cs_pin;

  g_bno_ok = bno_ready ? 1u : 0u;
  g_bno_recover_tried = 0;

  g_state = APP_USB_STATE_MENU;
  g_rx_w = 0;
  g_rx_r = 0;
  g_line_len = 0;

  g_spif_inited = 0;
  memset(&g_spif, 0, sizeof(g_spif));

  g_rec_state = REC_STATE_IDLE;
  g_rec_sample_count = 0;

  g_lcd_last_tick = HAL_GetTick();
  g_led_last_tick = HAL_GetTick();
  g_last_gps_sol_tick = HAL_GetTick();
  g_last_bno_tick = HAL_GetTick();

  APP_PrintMenu();
}

void APP_USB_SD_Attach(SD_HandleTypeDef *hsd,
                       GPIO_TypeDef *cd_port,
                       uint16_t cd_pin)
{
  g_hsd = hsd;
  g_sd_cd_port = cd_port;
  g_sd_cd_pin = cd_pin;
}

void APP_USB_VS1053_Attach(SPI_HandleTypeDef *hspi_vs1053,
                           GPIO_TypeDef *xcs_port,  uint16_t xcs_pin,
                           GPIO_TypeDef *xdcs_port, uint16_t xdcs_pin,
                           GPIO_TypeDef *dreq_port, uint16_t dreq_pin,
                           GPIO_TypeDef *rst_port,  uint16_t rst_pin)
{
  memset(&g_vs1053, 0, sizeof(g_vs1053));
  g_vs1053.hspi = hspi_vs1053;
  g_vs1053.xcs_port = xcs_port;
  g_vs1053.xcs_pin = xcs_pin;
  g_vs1053.xdcs_port = xdcs_port;
  g_vs1053.xdcs_pin = xdcs_pin;
  g_vs1053.dreq_port = dreq_port;
  g_vs1053.dreq_pin = dreq_pin;
  g_vs1053.rst_port = rst_port;
  g_vs1053.rst_pin = rst_pin;

  g_vs1053_attached = (hspi_vs1053 && xcs_port && xdcs_port && dreq_port && rst_port) ? 1u : 0u;
  if (g_vs1053_attached)
  {
    VS1053_Attach(&g_vs1053);
  }
}

void APP_USB_Tick(void)
{
  uint32_t now = HAL_GetTick();                                                          // HE: זמן נוכחי

  MP3P_Tick();                                                                           // HE: ניגון MP3 ברקע
  APP_RecordingTick();                                                                   // HE: הקלטת BNO
  LCD_ToggleText_500ms();                                                                // HE: LCD
  LED_D6_UpdateFromGPS();                                                                // HE: LED

  /* ===== מצב בדיקות SD חוסם ===== */
  if (g_state == APP_USB_STATE_SD_TEST)                                                  // HE: בדיקת SD
  {
    SD_Test_StepTick();                                                                  // HE: טיפול בצעדים
    return;                                                                              // HE: לא ממשיכים
  }

  /* ===== תפריט שירים מה-SD, הדפסה חד פעמית ===== */
  if (g_state == APP_USB_STATE_MP3_LIST)                                                 // HE: תפריט MP3
  {
    if (g_mp3_list_printed == 0u)                                                        // HE: טרם הודפס
    {
      APP_PrintMp3ListMenu();                                                            // HE: הדפסת הרשימה
      g_mp3_list_printed = 1u;                                                           // HE: סמן כהודפס
      g_state = APP_USB_STATE_MP3_PICK;                                                  // HE: מעבר לבחירה
    }
  }

  /* ===== טיפול בקלט USB ===== */
  uint8_t ch;
  while (APP_RxFifo_Pop(&ch))                                                            // HE: שליפת תו
  {
    APP_ProcessUsbChar(ch);                                                              // HE: עיבוד תו
  }

  /* ===== מצבים רציפים ===== */
  if (g_state == APP_USB_STATE_GPS_SOL)                                                  // HE: GPS פתרון
  {
    GPS_PrintSolution_Periodic();
  }
  else if (g_state == APP_USB_STATE_GPS_RAW)                                             // HE: GPS RAW
  {
    GPS_M8Q_UsbStreamRawBytes();
  }
  else if (g_state == APP_USB_STATE_BNO_EULER)                                           // HE: BNO055
  {
    if ((now - g_last_bno_tick) >= BNO_DISPLAY_PERIOD_MS)
    {
      g_last_bno_tick = now;
      BNO_PrintEuler_Once();
    }
  }

  else if (g_state == APP_USB_STATE_BNO_WORLD_ACC)                               // HE: תאוצה בעולם
  {
    if ((now - g_last_bno_tick) >= BNO_DISPLAY_PERIOD_MS)                        // HE: כל 50ms
    {
      g_last_bno_tick = now;                                                     // HE: עדכון טיימר
      BNO_PrintWorldLinAcc_Once();                                               // HE: הדפסה
    }
  }

  /* File: app_usb.c                                                                 // HE: Tick למצבי הדפסה
     Why: Periodic quaternion printing                                                // HE: הדפסת קווטרניונים במחזוריות
  */
    else if (g_state == APP_USB_STATE_BNO_QUAT)                                       // HE: מצב קווטרניונים
    {
      if ((now - g_last_bno_tick) >= BNO_DISPLAY_PERIOD_MS)                           // HE: כל 50ms כמו אאולר
      {
        g_last_bno_tick = now;                                                        // HE: עדכון טיימר
        BNO_PrintQuat_Once();                                                         // HE: הדפסה
      }
    }

  /* IMPORTANT:
     Do NOT handle APP_USB_STATE_VS1053_VOL here.
     Volume input is handled only inside APP_ProcessUsbChar().
  */
}

void APP_USB_CDC_RxCallback(uint8_t *Buf, uint32_t Len)
{
  if (Buf == NULL || Len == 0u) return;
  for (uint32_t i = 0; i < Len; i++)
  {
    APP_RxFifo_Push(Buf[i]);
  }
}

/* ===== USB TX helpers ===== */
static void APP_TxLen(const uint8_t *buf, uint16_t len)
{
  if (buf == NULL || len == 0u) return;

  uint32_t t0 = HAL_GetTick();
  while (1)
  {
    uint8_t res = CDC_Transmit_FS((uint8_t*)buf, len);
    if (res == USBD_OK) return;

    if ((HAL_GetTick() - t0) >= CDC_TX_RETRY_TIMEOUT_MS) return;
    HAL_Delay(1);
  }
}

static void APP_Tx(const char *s)
{
  if (s == NULL) return;
  APP_TxLen((const uint8_t*)s, (uint16_t)strlen(s));
}

/* ===== RX FIFO ===== */
static int APP_RxFifo_Pop(uint8_t *out)
{
  if (out == NULL) return 0;
  if (g_rx_r == g_rx_w) return 0;
  *out = g_rx_fifo[g_rx_r];
  g_rx_r = (uint16_t)((g_rx_r + 1u) % APP_RX_FIFO_SIZE);
  return 1;
}

static void APP_RxFifo_Push(uint8_t b)
{
  uint16_t next = (uint16_t)((g_rx_w + 1u) % APP_RX_FIFO_SIZE);
  if (next == g_rx_r) return;
  g_rx_fifo[g_rx_w] = b;
  g_rx_w = next;
}

/* ===== UI / LED / LCD ===== */
static void APP_PrintMenu(void)
{
  APP_Tx("\r\n============================\r\n");
  APP_Tx("USB MENU:\r\n");
  APP_Tx("1) GPS  (LAT/LON/ALT/TIME/FIX)\r\n");
  APP_Tx("2) GPS RAW NMEA\r\n");
  APP_Tx("3) BNO055 (YAW/PITCH/ROLL)\r\n");
  APP_Tx("4) FLASH SPI: 10 sentences MCU<->FLASH\r\n");
  APP_Tx("5) FLASH SPI: JEDEC ID\r\n");
  APP_Tx("6) BNO055 Data Logger (10Sec) -> SPI FLASH\r\n");
  APP_Tx("7) Playback Recordings from SPI FLASH (timed)\r\n");
  APP_Tx("8) ERASE ALL recordings from SPI FLASH\r\n");
  APP_Tx("9) VS1053 TEST: Sine (10 sec)\r\n");
  APP_Tx("A) SD CARD Complete Test Suite\r\n");
  APP_Tx("P) Play MP3 from SD (file_example_MP3_1MG.mp3)\r\n");
  APP_Tx("K) Songs menu from SD (choose a file number)\r\n");   // HE: תפריט שירים מה-SD
  APP_Tx("J) BNO055 (QUAT qw,qx,qy,qz + |q|^2)\r\n");
  APP_Tx("Q) BNO055 World Linear Acc (ax_world, ay_world, az_world)\r\n");

  APP_Tx("m) show menu\r\n");
  APP_Tx("============================\r\n");
}

/* File: app_usb.c                                                                                 // HE: תפריט USB
   Why: While MP3 plays, do only small LCD updates using FillRect, avoid full-screen clears.       // HE: מסך מתעדכן בלי להרוס אודיו
*/
static void LCD_ToggleText_500ms(void)
{
  uint32_t now = HAL_GetTick();                                                        // HE: זמן נוכחי
  if (MP3P_IsPlaying()) return;                                                        // HE: כמו שהיה אצלך

  uint32_t period = MP3P_IsPlaying() ? 2000u : LCD_TOGGLE_PERIOD_MS;                   // HE: בזמן MP3 מחליפים כל 2 שניות

  if ((now - g_lcd_last_tick) < period) return;                                        // HE: עוד לא הזמן
  g_lcd_last_tick = now;                                                               // HE: עדכון טיימר
  g_lcd_toggle ^= 1u;                                                                  // HE: טוגול

  if (MP3P_IsPlaying())                                                                // HE: בזמן MP3
  {
    ST7735_FillRect(0u, MP3_UI_Y, ST7735_WIDTH, MP3_UI_H, ST7735_COLOR_BLACK);         // HE: ניקוי פס קטן בלבד

    if (g_lcd_toggle)                                                                  // HE: טקסט
      ST7735_ShowTextScaled_At("HAREL", 25u, (uint16_t)(MP3_UI_Y + 8u), MP3_UI_SCALE); // HE: ציור ללא FillScreen
    else
      ST7735_ShowTextScaled_At("IPOD", 20u, (uint16_t)(MP3_UI_Y + 8u), MP3_UI_SCALE);  // HE: ציור ללא FillScreen

    return;                                                                            // HE: יציאה
  }

  ST7735_FillScreen(ST7735_COLOR_BLACK);                                               // HE: מחוץ לניגון מותר כבד
  if (g_lcd_toggle) ST7735_ShowSentenceCenterScaled("HAREL", 4);                       // HE: גדול
  else             ST7735_ShowSentenceCenterScaled("IPOD", 4);                         // HE: גדול
}

static void APP_FL_EraseAllRecordings(void)
{
  FLASH_EnsureInit();
  if (!g_spif_inited)
  {
    APP_Tx("[FLASH] Not initialized\r\n");
    return;
  }

  APP_Tx("[FLASH] Erasing all recording slots...\r\n");

  for (uint32_t slot = 0; slot < APP_FL_SLOT_COUNT; slot++)
  {
    uint32_t addr = APP_FL_SlotBase(slot);
    uint32_t sector = SPIF_AddressToSector(addr);

    if (!SPIF_EraseSector(&g_spif, sector))
    {
      APP_Tx("[FLASH] Erase failed at slot ");
      {
        char msg[16];
        snprintf(msg, sizeof(msg), "%lu\r\n", (unsigned long)slot);
        APP_Tx(msg);
      }
      return;
    }
  }

  APP_Tx("[FLASH] All recording slots erased\r\n");
}

static void SD_Test_All(void)
{
  APP_Tx("\r\n[SD] TEST START\r\n");
  SD_Test_CardDetect();
  SD_Test_HAL_CID_CSD();
  SD_Test_FatFs();
  APP_Tx("[SD] TEST END\r\n");
}

static void SD_Test_CardDetect(void)
{
  if (!g_sd_cd_port)
  {
    APP_Tx("[SD] CD pin not attached\r\n");
    return;
  }

  GPIO_PinState st = HAL_GPIO_ReadPin(g_sd_cd_port, g_sd_cd_pin);

  /* שים לב: יש מחזיקים שה־CD הוא Active-Low. אם אצלך הפוך, פשוט תהפוך את התנאי */
  if (st == GPIO_PIN_RESET)
    APP_Tx("[SD] Card Detect: INSERTED (CD=0)\r\n");
  else
    APP_Tx("[SD] Card Detect: NOT inserted (CD=1)\r\n");
}

/* בתוך app_usb.c, החלף את SD_Test_HAL_CID_CSD עם: */
static void SD_Test_HAL_CID_CSD(void)
{
  HAL_SD_CardCIDTypeDef cid;
  HAL_SD_CardCSDTypeDef csd;

  APP_Tx("\r\n[SD] HAL CID/CSD test\r\n");

  if (!g_hsd)
  {
    APP_Tx("[SD] SD handle not attached (call APP_USB_SD_Attach)\r\n");
    return;
  }

  /* אם הכרטיס לא במצב TRANSFER, ננסה לאתחל */
  if (HAL_SD_GetCardState(g_hsd) != HAL_SD_CARD_TRANSFER)
  {
    APP_Tx("[SD] Card not in TRANSFER, trying HAL_SD_Init...\r\n");
    if (HAL_SD_Init(g_hsd) != HAL_OK)
    {
      APP_Tx("[SD] HAL_SD_Init FAILED\r\n");
      return;
    }
  }

  if (HAL_SD_GetCardCID(g_hsd, &cid) != HAL_OK)
  {
    APP_Tx("[SD] HAL_SD_GetCardCID FAILED\r\n");
    return;
  }

  if (HAL_SD_GetCardCSD(g_hsd, &csd) != HAL_OK)
  {
    APP_Tx("[SD] HAL_SD_GetCardCSD FAILED\r\n");
    return;
  }

  APP_Tx("[SD] CID/CSD OK\r\n");

  {
    char msg[128];
    snprintf(msg, sizeof(msg),
             "[SD] Manufacturer ID: 0x%02X, RCA: 0x%04lX\r\n",
             (unsigned)cid.ManufacturerID,
             (unsigned long)g_hsd->SdCard.RelCardAdd);
    APP_Tx(msg);
  }
}

static void LED_D6_UpdateFromGPS(void)
{
  const GPS_Data_t *d = GPS_M8Q_GetLastData();
  uint32_t now = HAL_GetTick();

  if (d == NULL || d->fix == 0)
  {
    HAL_GPIO_WritePin(LED_D6_GPIO_Port, LED_D6_Pin, GPIO_PIN_SET);
    g_led_state = 1;
    g_led_last_tick = now;
    return;
  }

  if ((now - g_led_last_tick) >= LED_BLINK_PERIOD_MS)
  {
    g_led_last_tick = now;
    g_led_state ^= 1u;
    HAL_GPIO_WritePin(LED_D6_GPIO_Port, LED_D6_Pin,
                      g_led_state ? GPIO_PIN_SET : GPIO_PIN_RESET);
  }
}


/* File: app_usb.c                                                                 // HE: הדפסת תאוצה לינארית בעולם
   Why: Print world-frame linear acceleration using quaternion rotation             // HE: שימוש בקווטרניון לסיבוב לעולם
*/

/* File: app_usb.c                                                                 // HE: הדפסת תאוצה לינארית בעולם
   Why: Q בתפריט מדפיס ax_world, ay_world, az_world ביחידות g                      // HE: לוקח סקייל מהחיישן
*/
/* File: app_usb.c                                                                 // HE: תיקון הדפסה בלי float
   Why: להדפיס ax/ay/az במילי-g כדי לא להיות תלוי ב-printf float                     // HE: פתרון לבעיה ax=g
*/

static void BNO_PrintWorldLinAcc_Once(void)                                         // HE: הדפסת תאוצה בעולם
{
  if (!g_bno_ok)                                                                    // HE: אם החיישן לא מוכן
  {
    if (!g_bno_recover_tried)                                                       // HE: ניסיון שחזור פעם אחת
    {
      g_bno_recover_tried = 1;                                                      // HE: סימון שניסינו
      if (BNO055_Begin())                                                           // HE: ניסיון init מחדש
      {
        g_bno_ok = 1;                                                               // HE: הצליח
        APP_Tx("BNO055 recovered\r\n");                                             // HE: הודעה
      }
      else
      {
        APP_Tx("BNO055 not ready\r\n");                                             // HE: הודעה
        return;                                                                     // HE: יציאה
      }
    }
    else
    {
      APP_Tx("BNO055 not ready\r\n");                                               // HE: הודעה
      return;                                                                       // HE: יציאה
    }
  }

  float axw = 0.0f, ayw = 0.0f, azw = 0.0f;                                         // HE: תאוצה בעולם (g)
  char msg[160];                                                                    // HE: באפר

  if (!BNO055_ReadWorldLinAcc_g(&axw, &ayw, &azw))                                  // HE: קריאה
  {
    APP_Tx("BNO055_ReadWorldLinAcc_g FAILED\r\n");                                  // HE: שגיאה
    return;                                                                         // HE: יציאה
  }

  int32_t ax_mg = (int32_t)(axw * 1000.0f);                                         // HE: g -> milli-g
  int32_t ay_mg = (int32_t)(ayw * 1000.0f);                                         // HE: g -> milli-g
  int32_t az_mg = (int32_t)(azw * 1000.0f);                                         // HE: g -> milli-g

  int n = snprintf(msg, sizeof(msg),                                                // HE: הדפסה בלי %f
                   "BNO055 World Linear Accel mg: ax=%ldmg ay=%ldmg az=%ldmg\r\n",
                   (long)ax_mg, (long)ay_mg, (long)az_mg);
  if (n > 0) APP_TxLen((const uint8_t*)msg, (uint16_t)n);                           // HE: שליחה
}







/* ===== GPS / BNO printing ===== */
static void GPS_PrintSolution_Periodic(void)
{
  uint32_t now = HAL_GetTick();
  if ((now - g_last_gps_sol_tick) < GPS_SOL_PRINT_PERIOD_MS) return;
  g_last_gps_sol_tick = now;

  const GPS_Data_t *d = GPS_M8Q_GetLastData();
  if (d == NULL)
  {
    APP_Tx("GPS: no data yet\r\n");
    return;
  }

  int32_t lat_1e7 = (int32_t)(d->lat_deg * 10000000.0);
  int32_t lon_1e7 = (int32_t)(d->lon_deg * 10000000.0);
  int32_t alt_cm  = (int32_t)(d->altitude_m * 100.0);

  int32_t lat_i = lat_1e7 / 10000000;
  int32_t lat_f = lat_1e7 % 10000000; if (lat_f < 0) lat_f = -lat_f;

  int32_t lon_i = lon_1e7 / 10000000;
  int32_t lon_f = lon_1e7 % 10000000; if (lon_f < 0) lon_f = -lon_f;

  int32_t alt_i = alt_cm / 100;
  int32_t alt_f = alt_cm % 100; if (alt_f < 0) alt_f = -alt_f;

  {
    char msg[220];
    int n = snprintf(msg, sizeof(msg),
                     "GPS: LAT=%ld.%07ld, LON=%ld.%07ld, ALT=%ld.%02ld m, TIME=%02u:%02u:%02u, FIX=%u\r\n",
                     (long)lat_i, (long)lat_f,
                     (long)lon_i, (long)lon_f,
                     (long)alt_i, (long)alt_f,
                     (unsigned)d->hour, (unsigned)d->minute, (unsigned)d->second,
                     (unsigned)d->fix);

    if (n > 0) APP_TxLen((const uint8_t*)msg, (uint16_t)n);
  }
}

static void BNO_PrintEuler_Once(void)
{
  if (!g_bno_ok)
  {
    if (!g_bno_recover_tried)
    {
      g_bno_recover_tried = 1;
      if (BNO055_Begin())
      {
        g_bno_ok = 1;
        APP_Tx("BNO055 recovered\r\n");
      }
      else
      {
        APP_Tx("BNO055 not ready\r\n");
        return;
      }
    }
    else
    {
      APP_Tx("BNO055 not ready\r\n");
      return;
    }
  }

  int16_t h16 = 0, r16 = 0, p16 = 0;
  char msg[160];

  if (!BNO055_ReadEuler_deg_x16(&h16, &r16, &p16))
  {
    APP_Tx("BNO055_ReadEuler_deg_x16 FAILED\r\n");
    return;
  }

  int32_t yaw_i    = (int32_t)h16 / 16;
  int32_t yaw_f16  = (int32_t)h16 % 16; if (yaw_f16 < 0) yaw_f16 = -yaw_f16;
  int32_t yaw_frac = yaw_f16 * 625;

  int32_t pitch_i    = (int32_t)p16 / 16;
  int32_t pitch_f16  = (int32_t)p16 % 16; if (pitch_f16 < 0) pitch_f16 = -pitch_f16;
  int32_t pitch_frac = pitch_f16 * 625;

  int32_t roll_i    = (int32_t)r16 / 16;
  int32_t roll_f16  = (int32_t)r16 % 16; if (roll_f16 < 0) roll_f16 = -roll_f16;
  int32_t roll_frac = roll_f16 * 625;

  int n = snprintf(msg, sizeof(msg),
                   "BNO055: YAW=%ld.%04ld deg, PITCH=%ld.%04ld deg, ROLL=%ld.%04ld deg\r\n",
                   (long)yaw_i,   (long)yaw_frac,
                   (long)pitch_i, (long)pitch_frac,
                   (long)roll_i,  (long)roll_frac);

  if (n > 0) APP_TxLen((const uint8_t*)msg, (uint16_t)n);
}

/* ===== Flash init + tests ===== */

/* File: app_usb.c                                                                 // HE: הדפסת קווטרניונים
   Why: Print qw,qx,qy,qz and |q|^2 as a quick health metric                         // HE: הדפסה + מדד איכות |q|^2
*/

static void BNO_PrintQuat_Once(void)                                                // HE: הדפסת קווטרניונים פעם אחת
{
  if (!g_bno_ok)                                                                    // HE: אם החיישן לא מוכן
  {
    if (!g_bno_recover_tried)                                                       // HE: ניסיון שחזור פעם אחת
    {
      g_bno_recover_tried = 1;                                                      // HE: סימון שניסינו
      if (BNO055_Begin())                                                           // HE: ניסיון init מחדש
      {
        g_bno_ok = 1;                                                               // HE: הצליח
        APP_Tx("BNO055 recovered\r\n");                                             // HE: הודעה
      }
      else                                                                          // HE: נכשל
      {
        APP_Tx("BNO055 not ready\r\n");                                             // HE: הודעה
        return;                                                                     // HE: יציאה
      }
    }
    else                                                                            // HE: כבר ניסינו
    {
      APP_Tx("BNO055 not ready\r\n");                                               // HE: הודעה
      return;                                                                       // HE: יציאה
    }
  }

  int16_t qw = 0, qx = 0, qy = 0, qz = 0;                                           // HE: רכיבי קווטרניון RAW
  char msg[220];                                                                     // HE: באפר להדפסה

  if (!BNO055_ReadQuat_raw(&qw, &qx, &qy, &qz))                                      // HE: קריאה מהדרייבר
  {
    APP_Tx("BNO055_ReadQuat_raw FAILED\r\n");                                        // HE: הודעת שגיאה
    return;                                                                          // HE: יציאה
  }

  /* BNO055 quaternion scale: 1 LSB = 1/16384                                         // HE: סקייל קווטרניון לפי BNO055 */
  const int32_t Q_SCALE = 16384;                                                    // HE: קבוע סקייל
  const int64_t Q_SCALE_SQ = (int64_t)Q_SCALE * (int64_t)Q_SCALE;                   // HE: 16384^2

  int64_t w2 = (int64_t)qw * (int64_t)qw;                                           // HE: qw^2
  int64_t x2 = (int64_t)qx * (int64_t)qx;                                           // HE: qx^2
  int64_t y2 = (int64_t)qy * (int64_t)qy;                                           // HE: qy^2
  int64_t z2 = (int64_t)qz * (int64_t)qz;                                           // HE: qz^2
  int64_t num = w2 + x2 + y2 + z2;                                                  // HE: סכום ריבועים

  /* norm2 = num / Q_SCALE_SQ, print with 6 decimals                                  // HE: חישוב |q|^2 והדפסה עם 6 ספרות */
  int64_t norm2_fp = (num * 1000000LL) / Q_SCALE_SQ;                                // HE: |q|^2 * 1e6
  int32_t norm2_i  = (int32_t)(norm2_fp / 1000000LL);                               // HE: חלק שלם
  int32_t norm2_f  = (int32_t)(norm2_fp % 1000000LL);                               // HE: חלק שברי
  if (norm2_f < 0) norm2_f = -norm2_f;                                              // HE: ביטחון

  /* Helper macro style inline: print q as +/-0.xxxx using fixed point                // HE: הדפסת q עם 4 ספרות */
  int32_t qw_i = (int32_t)qw / Q_SCALE;                                             // HE: חלק שלם qw
  int32_t qx_i = (int32_t)qx / Q_SCALE;                                             // HE: חלק שלם qx
  int32_t qy_i = (int32_t)qy / Q_SCALE;                                             // HE: חלק שלם qy
  int32_t qz_i = (int32_t)qz / Q_SCALE;                                             // HE: חלק שלם qz

  int32_t qw_r = (int32_t)qw % Q_SCALE; if (qw_r < 0) qw_r = -qw_r;                 // HE: שארית qw חיובית
  int32_t qx_r = (int32_t)qx % Q_SCALE; if (qx_r < 0) qx_r = -qx_r;                 // HE: שארית qx חיובית
  int32_t qy_r = (int32_t)qy % Q_SCALE; if (qy_r < 0) qy_r = -qy_r;                 // HE: שארית qy חיובית
  int32_t qz_r = (int32_t)qz % Q_SCALE; if (qz_r < 0) qz_r = -qz_r;                 // HE: שארית qz חיובית

  int32_t qw_frac = (qw_r * 10000) / Q_SCALE;                                       // HE: 4 ספרות אחרי נקודה
  int32_t qx_frac = (qx_r * 10000) / Q_SCALE;                                       // HE: 4 ספרות אחרי נקודה
  int32_t qy_frac = (qy_r * 10000) / Q_SCALE;                                       // HE: 4 ספרות אחרי נקודה
  int32_t qz_frac = (qz_r * 10000) / Q_SCALE;                                       // HE: 4 ספרות אחרי נקודה

  int n = snprintf(msg, sizeof(msg),                                                // HE: בניית מחרוזת
                   "BNO055: qw=%ld.%04ld qx=%ld.%04ld qy=%ld.%04ld qz=%ld.%04ld |q|^2=%ld.%06ld\r\n",
                   (long)qw_i, (long)qw_frac,                                       // HE: qw
                   (long)qx_i, (long)qx_frac,                                       // HE: qx
                   (long)qy_i, (long)qy_frac,                                       // HE: qy
                   (long)qz_i, (long)qz_frac,                                       // HE: qz
                   (long)norm2_i, (long)norm2_f);                                   // HE: |q|^2

  if (n > 0) APP_TxLen((const uint8_t*)msg, (uint16_t)n);                           // HE: שליחה ל-USB
}









static void FLASH_EnsureInit(void)
{
  if (g_spif_inited) return;
  if (g_hspi_flash == NULL || g_flash_cs_port == NULL) return;

  if (SPIF_Init(&g_spif, g_hspi_flash, g_flash_cs_port, g_flash_cs_pin))
  {
    g_spif_inited = 1;
    APP_Tx("[FLASH] SPI Flash initialized successfully\r\n");
  }
  else
  {
    g_spif_inited = 0;
    APP_Tx("[FLASH] SPI Flash initialization FAILED\r\n");
  }
}

static void FLASH_Test_JEDEC(void)
{
  uint8_t m = 0, t = 0, c = 0;
  char msg[96];

  APP_Tx("\r\n[FLASH] JEDEC TEST\r\n");
  FLASH_EnsureInit();

  if (!g_spif_inited)
  {
    APP_Tx("SPIF_Init FAILED\r\n");
    return;
  }

  if (!SPIF_ReadJedecId(&g_spif, &m, &t, &c))
  {
    APP_Tx("SPIF_ReadJedecId FAILED\r\n");
    return;
  }

  {
    int n = snprintf(msg, sizeof(msg), "JEDEC: MID=0x%02X TYPE=0x%02X CAP=0x%02X\r\n", m, t, c);
    if (n > 0) APP_TxLen((const uint8_t*)msg, (uint16_t)n);
  }
  APP_Tx("[FLASH] JEDEC DONE\r\n");
}

static void FLASH_Test_10Sentences(void)
{
  uint8_t m = 0, t = 0, c = 0;
  uint8_t rbuf[16];
  char msg[128];

  APP_Tx("\r\n[FLASH] 10 sentences MCU<->FLASH\r\n");

  APP_Tx("1) Init SPIF on SPI handle passed to APP_USB_Init\r\n");
  FLASH_EnsureInit();
  if (!g_spif_inited)
  {
    APP_Tx("   Result: FAIL init\r\n");
    return;
  }
  APP_Tx("   Result: OK init\r\n");

  APP_Tx("2) Read JEDEC ID\r\n");
  if (!SPIF_ReadJedecId(&g_spif, &m, &t, &c))
  {
    APP_Tx("   Result: FAIL JEDEC\r\n");
    return;
  }
  snprintf(msg, sizeof(msg), "   Result: OK JEDEC = %02X %02X %02X\r\n", m, t, c);
  APP_Tx(msg);

  APP_Tx("3) Read 16 bytes from 0x000000\r\n");
  memset(rbuf, 0, sizeof(rbuf));
  if (!SPIF_Read(&g_spif, 0x000000u, rbuf, sizeof(rbuf)))
  {
    APP_Tx("   Result: FAIL read\r\n");
    return;
  }
  snprintf(msg, sizeof(msg), "   First byte: 0x%02X\r\n", rbuf[0]);
  APP_Tx(msg);

  APP_Tx("4) Read 16 bytes from 0x000010\r\n");
  memset(rbuf, 0, sizeof(rbuf));
  (void)SPIF_Read(&g_spif, 0x000010u, rbuf, sizeof(rbuf));
  snprintf(msg, sizeof(msg), "   First byte: 0x%02X\r\n", rbuf[0]);
  APP_Tx(msg);

  APP_Tx("5) Read 16 bytes from 0x000100\r\n");
  memset(rbuf, 0, sizeof(rbuf));
  (void)SPIF_Read(&g_spif, 0x000100u, rbuf, sizeof(rbuf));
  snprintf(msg, sizeof(msg), "   First byte: 0x%02X\r\n", rbuf[0]);
  APP_Tx(msg);

  APP_Tx("6) Read 16 bytes from 0x001000\r\n");
  memset(rbuf, 0, sizeof(rbuf));
  (void)SPIF_Read(&g_spif, 0x001000u, rbuf, sizeof(rbuf));
  snprintf(msg, sizeof(msg), "   First byte: 0x%02X\r\n", rbuf[0]);
  APP_Tx(msg);

  APP_Tx("7) Read 16 bytes from 0x010000\r\n");
  memset(rbuf, 0, sizeof(rbuf));
  (void)SPIF_Read(&g_spif, 0x010000u, rbuf, sizeof(rbuf));
  snprintf(msg, sizeof(msg), "   First byte: 0x%02X\r\n", rbuf[0]);
  APP_Tx(msg);

  APP_Tx("8) Repeat read 0x000000 (stability)\r\n");
  memset(rbuf, 0, sizeof(rbuf));
  (void)SPIF_Read(&g_spif, 0x000000u, rbuf, sizeof(rbuf));
  snprintf(msg, sizeof(msg), "   First byte again: 0x%02X\r\n", rbuf[0]);
  APP_Tx(msg);

  APP_Tx("9) Dump 16 bytes hex from last read\r\n");
  for (int i = 0; i < 16; i++)
  {
    snprintf(msg, sizeof(msg), "%02X%s", rbuf[i], (i == 15) ? "\r\n" : " ");
    APP_Tx(msg);
  }

  APP_Tx("10) Done\r\n");
}

static void SD_Test_CDOnly(void)                                                                     // HE: בדיקת CD נכונה
{
  APP_Tx("\r\n[SD] Card Detect test\r\n");

  if (!g_sd_cd_port)                                                                                 // HE: אם לא הוצמד
  {
    APP_Tx("[SD] CD pin not attached\r\n");
    return;
  }

  GPIO_PinState st = HAL_GPIO_ReadPin(g_sd_cd_port, g_sd_cd_pin);                                    // HE: קריאה מהפין שהוצמד

  if (st == GPIO_PIN_RESET) APP_Tx("[SD] Card detected (CD=LOW)\r\n");
  else                      APP_Tx("[SD] No card (CD=HIGH)\r\n");
}

static void SD_Test_StepTick(void)
{
  uint8_t ch;

  /* אפשר לבטל בכל רגע עם כל מקש */
  if (APP_RxFifo_Pop(&ch))
  {
    APP_Tx("\r\n[SD] Test cancelled by user\r\n");
    g_state = APP_USB_STATE_MENU;
    APP_PrintMenu();
    return;
  }

  switch (g_sd_test_step)
  {
    case 0:
      APP_Tx("\r\n[SD] TEST START (press any key to cancel)\r\n");
      g_sd_test_t0 = HAL_GetTick();
      g_sd_test_step = 1;
      return;

    case 1:
      SD_Test_CDOnly();
      g_sd_test_step = 2;
      return;

    case 2:
      SD_Test_HAL_CID_CSD();   /* או SD_Test_HAL_Basic אם אתה משתמש בה */
      g_sd_test_step = 3;
      return;

    case 3:
      SD_Test_FatFs();
      g_sd_test_step = 4;
      return;

    default:
      APP_Tx("[SD] TEST END\r\n");
      g_state = APP_USB_STATE_MENU;
      APP_PrintMenu();
      return;
  }
}

static void SD_Test_HAL_Basic(void)
{
  HAL_SD_CardCIDTypeDef cid;                                                         // HE: מבנה CID של הכרטיס
  HAL_SD_CardCSDTypeDef csd;                                                         // HE: מבנה CSD של הכרטיס

  APP_Tx("\r\n[SD] HAL basic test\r\n");                                             // HE: כותרת בדיקה

  if (g_hsd == NULL)                                                                 // HE: לוודא שה-Handle הוצמד דרך APP_USB_SD_Attach
  {
    APP_Tx("[SD] SD handle not attached (call APP_USB_SD_Attach)\r\n");              // HE: הודעת שגיאה
    return;                                                                          // HE: יציאה
  }

  if (HAL_SD_Init(g_hsd) != HAL_OK)                                                  // HE: אתחול SD דרך HAL (בטוח לקרוא שוב)
  {
    APP_Tx("[SD] HAL_SD_Init FAILED\r\n");                                           // HE: אתחול נכשל
    return;                                                                          // HE: יציאה
  }

  if (HAL_SD_GetCardCID(g_hsd, &cid) != HAL_OK)                                      // HE: קריאת CID
  {
    APP_Tx("[SD] HAL_SD_GetCardCID FAILED\r\n");                                     // HE: קריאה נכשלת
    return;                                                                          // HE: יציאה
  }

  if (HAL_SD_GetCardCSD(g_hsd, &csd) != HAL_OK)                                      // HE: קריאת CSD
  {
    APP_Tx("[SD] HAL_SD_GetCardCSD FAILED\r\n");                                     // HE: קריאה נכשלת
    return;                                                                          // HE: יציאה
  }

  {
    char msg[128];                                                                   // HE: באפר להדפסה

    snprintf(msg, sizeof(msg),                                                       // HE: הדפסת Manufacturer ID
             "[SD] CID OK, Manufacturer ID: 0x%02X\r\n",
             (unsigned)cid.ManufacturerID);
    APP_Tx(msg);                                                                     // HE: שליחה ל-USB

    snprintf(msg, sizeof(msg),                                                       // HE: הדפסת פרטים שימושיים מה-Handle (יותר אמין מ-DeviceSize של CSD)
             "[SD] RCA=0x%04lX, BlockNbr=%lu, BlockSize=%lu\r\n",
             (unsigned long)g_hsd->SdCard.RelCardAdd,
             (unsigned long)g_hsd->SdCard.BlockNbr,
             (unsigned long)g_hsd->SdCard.BlockSize);
    APP_Tx(msg);                                                                     // HE: שליחה ל-USB
  }
}

static void SD_Test_FatFs(void)
{
  FRESULT fr;
  FIL fil;
  UINT bw = 0, br = 0;
  char rbuf[64];

  extern FATFS SDFatFS;
  extern char SDPath[4];

  APP_Tx("\r\n[SD] FatFs test\r\n");

  fr = f_mount(&SDFatFS, "0:", 1);

  if (fr != FR_OK)
  {
    APP_Tx("[SD] f_mount FAILED\r\n");
    return;
  }

  APP_Tx("[SD] f_mount OK\r\n");

  fr = f_open(&fil, "0:/test.txt", FA_CREATE_ALWAYS | FA_WRITE);
  if (fr != FR_OK)
  {
    APP_Tx("[SD] f_open write FAILED\r\n");
    return;
  }

  {
    const char *txt = "SD CARD TEST OK\r\n";
    f_write(&fil, txt, strlen(txt), &bw);
    f_close(&fil);
  }

  APP_Tx("[SD] write OK\r\n");

  fr = f_open(&fil, "0:/test.txt", FA_READ);
  if (fr != FR_OK)
  {
    APP_Tx("[SD] f_open read FAILED\r\n");
    return;
  }

  memset(rbuf, 0, sizeof(rbuf));
  f_read(&fil, rbuf, sizeof(rbuf) - 1, &br);
  f_close(&fil);

  APP_Tx("[SD] read content: ");
  APP_Tx(rbuf);

  f_unlink("0:/test.txt");
  APP_Tx("\r\n[SD] delete OK\r\n");

  f_mount(NULL, "0:", 0);

  APP_Tx("[SD] FatFs test DONE\r\n");
}

/* ===== Recording ===== */
static void APP_StartRecording(void)
{
  if (g_rec_state != REC_STATE_IDLE)
  {
    APP_Tx("[REC] Recording already in progress or busy\r\n");
    return;
  }

  if (!g_bno_ok)
  {
    APP_Tx("[REC] BNO055 not ready\r\n");
    return;
  }

  FLASH_EnsureInit();
  if (!g_spif_inited)
  {
    APP_Tx("[REC] SPI Flash not initialized\r\n");
    return;
  }

  uint8_t found_slot = 0xFF;
  for (uint32_t slot = 0; slot < APP_FL_SLOT_COUNT; slot++)
  {
    APP_FL_RecHeader_t hdr;
    memset(&hdr, 0, sizeof(hdr));

    uint32_t addr = APP_FL_SlotBase(slot);
    if (!SPIF_Read(&g_spif, addr, (uint8_t*)&hdr, sizeof(hdr)))
    {
      found_slot = slot;
      break;
    }

    if (!APP_FL_HeaderValid(&hdr))
    {
      found_slot = slot;
      break;
    }
  }

  if (found_slot == 0xFF)
  {
    APP_Tx("[REC] No available slots\r\n");
    return;
  }

  g_rec_slot = found_slot;

  APP_Tx("[REC] Erasing slot ");
  {
    char msg[32];
    snprintf(msg, sizeof(msg), "%lu...\r\n", (unsigned long)g_rec_slot);
    APP_Tx(msg);
  }

  uint32_t slot_base = APP_FL_SlotBase(g_rec_slot);
  uint32_t sector = SPIF_AddressToSector(slot_base);

  if (!SPIF_EraseSector(&g_spif, sector))
  {
    APP_Tx("[REC] Failed to erase sector\r\n");
    return;
  }

  g_rec_state = REC_STATE_ACTIVE;
  g_rec_start_time = HAL_GetTick();
  g_rec_sample_count = 0;
  g_rec_last_sample_time = g_rec_start_time;
  g_rec_write_addr = slot_base + sizeof(APP_FL_RecHeader_t);

  APP_Tx("[REC] Recording started (10 seconds)\r\n");
}

static void APP_StopRecording(void)
{
  if (g_rec_state != REC_STATE_ACTIVE && g_rec_state != REC_STATE_WRITING) return;

  APP_Tx("[REC] Stopping recording...\r\n");

  APP_FL_RecHeader_t hdr;
  memset(&hdr, 0, sizeof(hdr));
  hdr.magic = APP_FL_MAGIC_REC;
  hdr.index = g_rec_slot;
  hdr.sample_period_ms = BNO_RECORD_PERIOD_MS;
  hdr.sample_count = g_rec_sample_count;
  hdr.start_time_ms = g_rec_start_time;
  hdr.end_time_ms = HAL_GetTick();

  uint32_t slot_base = APP_FL_SlotBase(g_rec_slot);

  if (!SPIF_Write(&g_spif, slot_base, (const uint8_t*)&hdr, sizeof(hdr)))
  {
    APP_Tx("[REC] Failed to write header\r\n");
    g_rec_state = REC_STATE_IDLE;
    return;
  }

  {
    char msg[128];
    int n = snprintf(msg, sizeof(msg),
                     "[REC] Recording saved to slot %lu\r\n"
                     "[REC] Samples: %lu\r\n",
                     (unsigned long)g_rec_slot,
                     (unsigned long)g_rec_sample_count);
    if (n > 0) APP_TxLen((const uint8_t*)msg, (uint16_t)n);
  }

  g_rec_state = REC_STATE_IDLE;
}

static void APP_RecordingTick(void)
{
  if (g_rec_state != REC_STATE_ACTIVE) return;

  uint32_t now = HAL_GetTick();

  if ((now - g_rec_start_time) >= BNO_RECORD_DURATION_MS)
  {
    APP_StopRecording();
    return;
  }

  if ((now - g_rec_last_sample_time) >= BNO_RECORD_PERIOD_MS)
  {
    int16_t h16 = 0, r16 = 0, p16 = 0;
    if (!BNO055_ReadEuler_deg_x16(&h16, &r16, &p16))
    {
      APP_Tx("[REC] Failed to read BNO055 data\r\n");
      APP_StopRecording();
      return;
    }

    APP_FL_Sample_t sample;
    sample.yaw_x16 = h16;
    sample.pitch_x16 = p16;
    sample.roll_x16 = r16;
    sample.sample_time_ms = now - g_rec_start_time;

    if (!SPIF_Write(&g_spif, g_rec_write_addr, (const uint8_t*)&sample, sizeof(sample)))
    {
      APP_Tx("[REC] Failed to write sample to flash\r\n");
      APP_StopRecording();
      return;
    }

    g_rec_write_addr += sizeof(sample);
    g_rec_sample_count++;
    g_rec_last_sample_time = now;
  }
}

/* ===== Playback ===== */
static void APP_FL_ListRecordingsAndBuildMap(void)
{
  g_rec_count = 0;
  memset(g_rec_map, 0, sizeof(g_rec_map));

  APP_Tx("\r\n[PLAYBACK] Recordings in SPI Flash:\r\n");

  for (uint32_t slot = 0; slot < APP_FL_SLOT_COUNT; slot++)
  {
    APP_FL_RecHeader_t h;
    memset(&h, 0, sizeof(h));

    uint32_t addr = APP_FL_SlotBase(slot);

    if (!SPIF_Read(&g_spif, addr, (uint8_t*)&h, sizeof(h)))
    {
      continue;
    }

    if (APP_FL_HeaderValid(&h))
    {
      uint32_t shown = (uint32_t)g_rec_count + 1u;
      g_rec_map[g_rec_count] = (uint8_t)slot;
      g_rec_count++;

      {
        char msg[140];
        int n = snprintf(msg, sizeof(msg),
                         "%lu) Slot=%lu, Period=%lums, Samples=%lu, Duration=%lums\r\n",
                         (unsigned long)shown,
                         (unsigned long)slot,
                         (unsigned long)h.sample_period_ms,
                         (unsigned long)h.sample_count,
                         (unsigned long)(h.end_time_ms - h.start_time_ms));
        if (n > 0) APP_TxLen((const uint8_t*)msg, (uint16_t)n);
      }
    }
  }

  if (g_rec_count == 0u)
  {
    APP_Tx("[PLAYBACK] No valid recordings found. Record first with option 6.\r\n");
  }
  else
  {
    char msg[64];
    snprintf(msg, sizeof(msg), "[PLAYBACK] Found %u recordings\r\n", g_rec_count);
    APP_Tx(msg);
  }
}

static uint8_t APP_FL_MapDisplayedIndexToSlot(uint32_t displayed_index_1based, uint32_t *out_slot)
{
  if (!out_slot) return 0;
  if (displayed_index_1based == 0u) return 0;
  if (displayed_index_1based > (uint32_t)g_rec_count) return 0;

  uint32_t idx0 = displayed_index_1based - 1u;
  *out_slot = (uint32_t)g_rec_map[idx0];
  return 1;
}

static void APP_FL_PlaySlotToUSB_WithTiming(uint32_t slot)
{
  if (!g_spif_inited)
  {
    APP_Tx("[PLAYBACK] SPI Flash not initialized\r\n");
    return;
  }

  if (slot >= APP_FL_SLOT_COUNT)
  {
    APP_Tx("[PLAYBACK] Invalid slot number\r\n");
    return;
  }

  APP_FL_RecHeader_t h;
  uint32_t base = APP_FL_SlotBase(slot);

  memset(&h, 0, sizeof(h));
  if (!SPIF_Read(&g_spif, base, (uint8_t*)&h, sizeof(h)))
  {
    APP_Tx("[PLAYBACK] Failed to read recording header\r\n");
    return;
  }

  if (!APP_FL_HeaderValid(&h))
  {
    APP_Tx("[PLAYBACK] Invalid recording header\r\n");
    return;
  }

  APP_Tx("[PLAYBACK] Starting playback (press any key to stop)...\r\n");

  uint32_t addr = base + sizeof(APP_FL_RecHeader_t);
  uint32_t last_play_time = HAL_GetTick();

  for (uint32_t i = 0; i < h.sample_count; i++)
  {
    uint8_t ch;
    if (APP_RxFifo_Pop(&ch))
    {
      APP_Tx("[PLAYBACK] Playback stopped by user\r\n");
      return;
    }

    APP_FL_Sample_t s;
    if (!SPIF_Read(&g_spif, addr, (uint8_t*)&s, sizeof(s)))
    {
      APP_Tx("[PLAYBACK] Failed to read sample\r\n");
      return;
    }
    addr += sizeof(s);

    int32_t yaw_i = (int32_t)s.yaw_x16 / 16;
    int32_t yaw_f = (int32_t)s.yaw_x16 % 16; if (yaw_f < 0) yaw_f = -yaw_f;
    int32_t yaw_frac = yaw_f * 625;

    int32_t pitch_i = (int32_t)s.pitch_x16 / 16;
    int32_t pitch_f = (int32_t)s.pitch_x16 % 16; if (pitch_f < 0) pitch_f = -pitch_f;
    int32_t pitch_frac = pitch_f * 625;

    int32_t roll_i = (int32_t)s.roll_x16 / 16;
    int32_t roll_f = (int32_t)s.roll_x16 % 16; if (roll_f < 0) roll_f = -roll_f;
    int32_t roll_frac = roll_f * 625;

    {
      char msg[128];
      int n = snprintf(msg, sizeof(msg),
                       "T+%lums: YAW=%ld.%04ld, PITCH=%ld.%04ld, ROLL=%ld.%04ld\r\n",
                       (unsigned long)s.sample_time_ms,
                       (long)yaw_i, (long)yaw_frac,
                       (long)pitch_i, (long)pitch_frac,
                       (long)roll_i, (long)roll_frac);
      if (n > 0) APP_TxLen((const uint8_t*)msg, (uint16_t)n);
    }

    last_play_time += h.sample_period_ms;
    while ((int32_t)(HAL_GetTick() - last_play_time) < 0)
    {
      HAL_Delay(1);
    }
  }

  APP_Tx("[PLAYBACK] Playback completed\r\n");
}

/* File: app_usb.c
   Why: Debug SD root listing using correct CubeMX drive (SDPath like "0:")
*/
static void APP_ListSdRoot(void)                                                                    // HE: הדפסת קבצים בשורש
{
  DIR dir;                                                                                          // HE: אובייקט תיקייה
  FILINFO fno;                                                                                      // HE: מידע קובץ
  char root[16];                                                                                    // HE: נתיב שורש
  char msg[96];                                                                                     // HE: הודעות

  snprintf(msg, sizeof(msg), "[SD] SDPath='%s'\r\n", SDPath);                                       // HE: הדפסת SDPath
  APP_Tx(msg);                                                                                      // HE: הדפסה

  FRESULT fr = f_mount(&SDFatFS, SDPath, 1);                                                        // HE: mount
  snprintf(msg, sizeof(msg), "[SD] mount fr=%d\r\n", (int)fr);                                      // HE: הדפסת תוצאת mount
  APP_Tx(msg);                                                                                      // HE: הדפסה
  if (fr != FR_OK) return;                                                                          // HE: אם כשל

  snprintf(root, sizeof(root), "0:/");                                                              // HE: "0:/"
  snprintf(msg, sizeof(msg), "[SD] opendir '%s'\r\n", root);                                        // HE: הדפסת נתיב
  APP_Tx(msg);                                                                                      // HE: הדפסה

  fr = f_opendir(&dir, root);                                                                       // HE: פתיחת שורש
  snprintf(msg, sizeof(msg), "[SD] opendir fr=%d\r\n", (int)fr);                                    // HE: הדפסת סטטוס
  APP_Tx(msg);                                                                                      // HE: הדפסה
  if (fr != FR_OK) return;                                                                          // HE: אם כשל

  APP_Tx("[SD] Root list:\r\n");                                                                    // HE: כותרת
  for (;;)
  {
    fr = f_readdir(&dir, &fno);                                                                     // HE: קריאת רשומה
    if (fr != FR_OK || fno.fname[0] == 0) break;                                                    // HE: סוף או שגיאה
    if (fno.fattrib & AM_DIR) continue;                                                             // HE: דלג תיקיות

    APP_Tx("  ");                                                                                   // HE: הזחה
    APP_Tx(fno.fname);                                                                              // HE: שם
    APP_Tx("\r\n");                                                                                 // HE: שורה חדשה
  }

  (void)f_closedir(&dir);                                                                           // HE: סגירה
  (void)f_mount(NULL, SDPath, 0);                                                                   // HE: unmount נכון
}

/* File: app_usb.c                                                                                   // HE: תפריט שירים מה-SD
   Why: Print MP3 list once for state APP_USB_STATE_MP3_LIST, then wait for user selection.          // HE: הדפסה פעם אחת
*/
static void APP_PrintMp3ListMenu(void)                                                               // HE: הדפסת רשימת שירים
{
  char msg[128];                                                                                     // HE: באפר הודעה

  APP_Tx("\r\n============================\r\n");                                                    // HE: כותרת
  APP_Tx("MP3 FILES ON SD (root 0:/)\r\n");                                                          // HE: הסבר

  if (g_mp3_list.count == 0u)                                                                        // HE: אם אין קבצים
  {
    APP_Tx("No MP3 files found\r\n");                                                                // HE: הודעה
    APP_Tx("Put files like SONG1.MP3 in SD root\r\n");                                               // HE: הנחיה
  }
  else                                                                                               // HE: יש קבצים
  {
    for (uint16_t i = 0; i < g_mp3_list.count; i++)                                                  // HE: מעבר על הרשימה
    {
      snprintf(msg, sizeof(msg), "%u) %s\r\n", (unsigned)(i + 1u), g_mp3_list.names[i]);             // HE: שורה ממוספרת
      APP_Tx(msg);                                                                                   // HE: הדפסה
    }
  }

  APP_Tx("M) Back to menu\r\n");                                                                     // HE: חזרה
  APP_Tx("Choose 1..N to play\r\n");                                                                 // HE: הנחיה
  APP_Tx("============================\r\n");                                                         // HE: קו סיום
}

/* File: app_usb.c                                                                                   // HE: מכונת מצבים לקלט USB
   Why: Full APP_ProcessUsbChar with MP3 K-menu selection (APP_USB_STATE_MP3_PICK) added safely.     // HE: הוספת בחירת שיר בלי לשבור דברים קיימים
*/
static void APP_ProcessUsbChar(uint8_t ch)
{
  /* ===== VS1053 volume input state (option 9) ===== */
  if (g_state == APP_USB_STATE_VS1053_VOL)                                                             // HE: מצב קלט עוצמה ל-VS1053
  {
    if (ch == '\r' || ch == '\n')                                                                      // HE: Enter
    {
      if (g_line_len == 0)                                                                             // HE: לא הוזן כלום
      {
        APP_Tx("\r\nEnter 1..10 ואז Enter:\r\n> ");                                                    // HE: בקשה מחדש
        return;                                                                                        // HE: יציאה
      }

      g_line[g_line_len] = 0;                                                                          // HE: סיום מחרוזת
      int v = atoi((char*)g_line);                                                                     // HE: המרה למספר

      if (v < 1 || v > 10)                                                                             // HE: טווח לא תקין
      {
        g_line_len = 0;                                                                                // HE: איפוס
        APP_Tx("\r\nלא תקין. Enter 1..10:\r\n> ");                                                     // HE: בקשה מחדש
        return;                                                                                        // HE: יציאה
      }

      /* מיפוי 1..10 ל Attenuation, 0 הכי חזק, 255 הכי חלש */
      uint8_t att;                                                                                     // HE: ערך הנחתה
      switch (v)                                                                                       // HE: מיפוי
      {
        case 1:  att = 220u; break;                                                                    // HE: חלש
        case 2:  att = 190u; break;                                                                    // HE: חלש
        case 3:  att = 160u; break;                                                                    // HE: בינוני
        case 4:  att = 130u; break;                                                                    // HE: בינוני
        case 5:  att = 105u; break;                                                                    // HE: בינוני
        case 6:  att =  85u; break;                                                                    // HE: חזק
        case 7:  att =  65u; break;                                                                    // HE: חזק
        case 8:  att =  45u; break;                                                                    // HE: חזק
        case 9:  att =  30u; break;                                                                    // HE: חזק מאוד
        default: att =  20u; break;                                                                    // HE: 10 חזק מאוד
      }

      APP_Tx("\r\n[VS1053] Sine continuous start (press 9 to stop)\r\n");                              // HE: הודעה

      VS1053_Status_t st = VS1053_Test_SineContinuousStart(0x44u, att, att);                           // HE: התחלת סינוס רציף

      if (st == VS1053_OK)                                                                             // HE: הצלחה
      {
        APP_Tx("[VS1053] OK\r\n");                                                                     // HE: הודעה
        g_vs_sine_running = 1u;                                                                        // HE: סימון רץ
      }
      else if (st == VS1053_TIMEOUT)                                                                   // HE: טיימאאוט
      {
        APP_Tx("[VS1053] TIMEOUT (check DREQ)\r\n");                                                   // HE: הודעה
      }
      else                                                                                             // HE: כשל
      {
        APP_Tx("[VS1053] FAIL\r\n");                                                                   // HE: הודעה
      }

      g_line_len = 0;                                                                                  // HE: איפוס
      g_state = APP_USB_STATE_MENU;                                                                    // HE: חזרה לתפריט
      APP_PrintMenu();                                                                                 // HE: הדפסת תפריט
      return;                                                                                          // HE: יציאה
    }

    /* איסוף ספרות */
    if (ch >= '0' && ch <= '9')                                                                        // HE: תו ספרה
    {
      if (g_line_len < (sizeof(g_line) - 1u))                                                          // HE: מקום במערך
      {
        g_line[g_line_len++] = (char)ch;                                                               // HE: שמירה
        APP_TxLen(&ch, 1);                                                                             // HE: echo
      }
      return;                                                                                          // HE: יציאה
    }

    return;                                                                                            // HE: מתעלמים מתווים אחרים
  }

  /* ===== Global 'm' menu ===== */
  if (ch == 'm' || ch == 'M')                                                                          // HE: חזרה לתפריט בכל מצב
  {
    g_state = APP_USB_STATE_MENU;                                                                      // HE: תפריט
    APP_PrintMenu();                                                                                   // HE: הדפסה
    return;                                                                                            // HE: יציאה
  }

  /* ===== MP3 pick state (after K list was printed) ===== */
  if (g_state == APP_USB_STATE_MP3_PICK)                                                               // HE: בחירת שיר לפי מספר
  {
    if (ch == 'M' || ch == 'm')                                                                        // HE: חזרה לתפריט
    {
      if (MP3P_IsPlaying())                                                                            // HE: אם מנגן
      {
        MP3P_Stop();                                                                                   // HE: עצירה
      }
      g_state = APP_USB_STATE_MENU;                                                                    // HE: תפריט
      APP_PrintMenu();                                                                                 // HE: הדפסה
      return;                                                                                          // HE: יציאה
    }

    if (ch >= '1' && ch <= '9')                                                                        // HE: בחירה 1..9
    {
      uint32_t idx = (uint32_t)(ch - '1');                                                             // HE: אינדקס 0-based

      if (idx >= (uint32_t)g_mp3_list.count)                                                           // HE: מחוץ לטווח
      {
        APP_Tx("[MP3] Invalid index\r\n");                                                             // HE: הודעה
        return;                                                                                        // HE: יציאה
      }

      if (MP3P_IsPlaying())                                                                            // HE: אם כבר מנגן
      {
        MP3P_Stop();                                                                                   // HE: עצירה לפני התחלה חדשה
      }

      APP_Tx("[MP3] Playing: ");                                                                       // HE: הודעה
      APP_Tx(g_mp3_list.names[idx]);                                                                   // HE: שם קובץ
      APP_Tx("\r\n");                                                                                  // HE: שורה חדשה

      int rc = MP3P_Start(g_mp3_list.names[idx]);                                                      // HE: התחלת ניגון
      if (rc != 0)                                                                                     // HE: אם נכשל
      {
        char msg[96];                                                                                  // HE: באפר
        snprintf(msg, sizeof(msg), "[MP3] ERROR rc=%d fr=%d step=%d\r\n",
                 rc, (int)MP3P_GetLastFresult(), MP3P_GetLastErrStep());
        APP_Tx(msg);                                                                                   // HE: הדפסה
      }
      else                                                                                             // HE: הצלחה
      {
        APP_Tx("[MP3] Press M to stop and return to menu\r\n");                                        // HE: הנחיה
      }

      return;                                                                                          // HE: יציאה
    }

    return;                                                                                            // HE: תווים אחרים מתעלמים
  }

  /* ===== Flash playback select state ===== */
  if (g_state == APP_USB_STATE_FLASH_PLAY_SELECT)                                                      // HE: בחירת הקלטה להשמעה
  {
    if (ch == '\r' || ch == '\n')                                                                      // HE: Enter
    {
      if (g_line_len == 0)                                                                             // HE: לא הוזן מספר
      {
        APP_Tx("Enter a number (1..N) or 'm' for menu: ");                                             // HE: בקשה
        return;                                                                                        // HE: יציאה
      }

      g_line[g_line_len] = 0;                                                                          // HE: סיום מחרוזת
      uint32_t user_idx = (uint32_t)atoi(g_line);                                                      // HE: המרה
      g_line_len = 0;                                                                                  // HE: איפוס

      FLASH_EnsureInit();                                                                              // HE: אתחול פלאש
      if (!g_spif_inited)                                                                              // HE: אם לא מאותחל
      {
        APP_Tx("[PLAYBACK] SPI Flash initialization failed\r\n");                                      // HE: הודעה
        g_state = APP_USB_STATE_MENU;                                                                  // HE: תפריט
        APP_PrintMenu();                                                                               // HE: הדפסה
        return;                                                                                        // HE: יציאה
      }

      uint32_t slot = 0;                                                                               // HE: סלוט
      if (!APP_FL_MapDisplayedIndexToSlot(user_idx, &slot))                                            // HE: מיפוי
      {
        APP_Tx("[PLAYBACK] Invalid selection. Choose 1..");                                            // HE: הודעה
        {
          char msg[32];                                                                                // HE: באפר
          snprintf(msg, sizeof(msg), "%u\r\n", g_rec_count);                                            // HE: N
          APP_Tx(msg);                                                                                 // HE: הדפסה
        }
        APP_Tx("Type index and Enter, or press m for menu: ");                                         // HE: בקשה
        return;                                                                                        // HE: יציאה
      }

      APP_Tx("\r\n");                                                                                  // HE: ירידת שורה
      APP_FL_PlaySlotToUSB_WithTiming(slot);                                                           // HE: ניגון הקלטה
      APP_Tx("\r\nType index and Enter, or press m for menu: ");                                       // HE: בקשה
      return;                                                                                          // HE: יציאה
    }

    if (ch == '\b' || ch == 127)                                                                       // HE: Backspace
    {
      if (g_line_len > 0u) g_line_len--;                                                               // HE: מחיקת תו
      return;                                                                                          // HE: יציאה
    }

    if (ch >= '0' && ch <= '9')                                                                        // HE: ספרות
    {
      if (g_line_len < (sizeof(g_line) - 1u))                                                          // HE: מקום
      {
        g_line[g_line_len++] = (char)ch;                                                               // HE: שמירה
      }
      return;                                                                                          // HE: יציאה
    }

    return;                                                                                            // HE: התעלמות
  }

  /* ===== Ignore CR/LF in normal menu mode ===== */
  if (ch == '\r' || ch == '\n') return;                                                                // HE: להתעלם

  /* ===== Menu options 1..8 keep as-is ===== */
  if (ch == '1')                                                                                       // HE: GPS SOL
  {
    g_state = APP_USB_STATE_GPS_SOL;                                                                   // HE: מצב
    g_last_gps_sol_tick = HAL_GetTick();                                                               // HE: איפוס טיימר
    APP_Tx("Mode: GPS SOL (solution data)\r\n");                                                       // HE: הודעה
    return;                                                                                            // HE: יציאה
  }

  if (ch == '2')                                                                                       // HE: GPS RAW
  {
    g_state = APP_USB_STATE_GPS_RAW;                                                                   // HE: מצב
    APP_Tx("Mode: GPS RAW (NMEA stream)\r\n");                                                         // HE: הודעה
    return;                                                                                            // HE: יציאה
  }

  if (ch == '3')                                                                                       // HE: BNO055
  {
    g_state = APP_USB_STATE_BNO_EULER;                                                                 // HE: מצב
    g_last_bno_tick = HAL_GetTick();                                                                   // HE: איפוס טיימר
    APP_Tx("Mode: BNO055 Euler angles\r\n");                                                           // HE: הודעה
    return;                                                                                            // HE: יציאה
  }
  if (ch == 'J' || ch == 'j')                                                      // HE: BNO055 QUAT
  {
    g_state = APP_USB_STATE_BNO_QUAT;                                               // HE: מעבר למצב קווטרניונים
    g_last_bno_tick = HAL_GetTick();                                                // HE: איפוס טיימר הדפסה
    APP_Tx("Mode: BNO055 Quaternion (qw,qx,qy,qz + |q|^2)\r\n");                    // HE: הודעה
    return;                                                                         // HE: יציאה
  }
  if (ch == 'Q' || ch == 'q')                                                     // HE: World Linear Acc
  {
    g_state = APP_USB_STATE_BNO_WORLD_ACC;                                        // HE: מעבר למצב
    g_last_bno_tick = HAL_GetTick();                                              // HE: איפוס טיימר
    APP_Tx("Mode: BNO055 World Linear Acceleration (ax,ay,az)\r\n");              // HE: הודעה
    return;                                                                       // HE: יציאה
  }

  if (ch == '4')                                                                                       // HE: FLASH test
  {
    FLASH_Test_10Sentences();                                                                          // HE: בדיקה
    g_state = APP_USB_STATE_MENU;                                                                      // HE: תפריט
    APP_PrintMenu();                                                                                   // HE: הדפסה
    return;                                                                                            // HE: יציאה
  }

  if (ch == '5')                                                                                       // HE: JEDEC
  {
    FLASH_Test_JEDEC();                                                                                // HE: בדיקה
    g_state = APP_USB_STATE_MENU;                                                                      // HE: תפריט
    APP_PrintMenu();                                                                                   // HE: הדפסה
    return;                                                                                            // HE: יציאה
  }

  if (ch == '6')                                                                                       // HE: Record
  {
    if (g_rec_state != REC_STATE_IDLE)                                                                 // HE: כבר מקליט
    {
      APP_Tx("[REC] Recording already in progress\r\n");                                               // HE: הודעה
      return;                                                                                          // HE: יציאה
    }

    APP_StartRecording();                                                                              // HE: התחלה
    g_state = APP_USB_STATE_MENU;                                                                      // HE: תפריט
    APP_PrintMenu();                                                                                   // HE: הדפסה
    return;                                                                                            // HE: יציאה
  }

  if (ch == '7')                                                                                       // HE: Playback list
  {
    FLASH_EnsureInit();                                                                                // HE: אתחול
    if (!g_spif_inited)                                                                                // HE: כשל
    {
      APP_Tx("[PLAYBACK] SPI Flash initialization failed\r\n");                                        // HE: הודעה
      g_state = APP_USB_STATE_MENU;                                                                    // HE: תפריט
      APP_PrintMenu();                                                                                 // HE: הדפסה
      return;                                                                                          // HE: יציאה
    }

    APP_FL_ListRecordingsAndBuildMap();                                                                // HE: רשימה

    if (g_rec_count == 0u)                                                                             // HE: אין הקלטות
    {
      g_state = APP_USB_STATE_MENU;                                                                    // HE: תפריט
      APP_PrintMenu();                                                                                 // HE: הדפסה
      return;                                                                                          // HE: יציאה
    }

    APP_Tx("\r\nType recording number (1..");                                                          // HE: בקשה
    {
      char msg[32];                                                                                    // HE: באפר
      snprintf(msg, sizeof(msg), "%u", g_rec_count);                                                    // HE: N
      APP_Tx(msg);                                                                                     // HE: הדפסה
    }
    APP_Tx(") and Enter, or press m for menu: ");                                                      // HE: המשך
    g_line_len = 0;                                                                                    // HE: איפוס
    g_state = APP_USB_STATE_FLASH_PLAY_SELECT;                                                         // HE: מצב בחירה
    return;                                                                                            // HE: יציאה
  }

  if (ch == '8')                                                                                       // HE: Erase recordings
  {
    APP_FL_EraseAllRecordings();                                                                       // HE: מחיקה
    g_state = APP_USB_STATE_MENU;                                                                      // HE: תפריט
    APP_PrintMenu();                                                                                   // HE: הדפסה
    return;                                                                                            // HE: יציאה
  }

  /* ===== Option A: Complete SD Card Test Suite ===== */
  if (ch == 'A' || ch == 'a')                                                                          // HE: בדיקות SD
  {
    g_state = APP_USB_STATE_MENU;                                                                      // HE: תפריט
    APP_Tx("\r\n[SD] Starting Complete Test Suite...\r\n");                                            // HE: הודעה

    SD_Test_CDOnly();                                                                                  // HE: CD
    SD_Test_HAL_CID_CSD();                                                                             // HE: CID/CSD
    SD_Test_FatFs();                                                                                   // HE: FatFs

    APP_Tx("[SD] Complete Test Suite Finished\r\n");                                                   // HE: הודעה
    APP_PrintMenu();                                                                                   // HE: תפריט
    return;                                                                                            // HE: יציאה
  }

  /* ===== Option P: toggle MP3 fixed file ===== */
  if (ch == 'P' || ch == 'p')                                                                          // HE: טוגול ניגון MP3 קבוע
  {
    if (MP3P_IsPlaying())                                                                              // HE: אם מנגן
    {
      APP_Tx("[MP3] Stop\r\n");                                                                        // HE: הודעה
      MP3P_Stop();                                                                                    // HE: עצירה
    }
    else                                                                                               // HE: אם לא מנגן
    {
      APP_Tx("[MP3] Play from start\r\n");                                                             // HE: הודעה
      int rc = MP3P_Start("FILE_E~1.MP3");                                                             // HE: שם קובץ קבוע
      if (rc != 0)                                                                                     // HE: אם נכשל
      {
        char msg[96];                                                                                  // HE: באפר
        snprintf(msg, sizeof(msg), "[MP3] ERROR rc=%d fr=%d step=%d\r\n",
                 rc, (int)MP3P_GetLastFresult(), MP3P_GetLastErrStep());
        APP_Tx(msg);                                                                                   // HE: הדפסה
      }
    }

    APP_PrintMenu();                                                                                   // HE: השאר תפריט זמין
    return;                                                                                            // HE: יציאה
  }

  /* ===== Option K: scan SD and show list ===== */
  if (ch == 'K' || ch == 'k')                                                                          // HE: כניסה לתפריט שירים
  {
    FRESULT fr;                                                                                        // HE: תוצאת FatFs

    fr = SD_MP3_ListScanRoot(&g_mp3_list);                                                             // HE: סריקה של 0:/
    g_mp3_list_printed = 0u;                                                                           // HE: לאפשר הדפסה פעם אחת

    if (fr != FR_OK)                                                                                   // HE: אם נכשל
    {
      char msg[64];                                                                                    // HE: באפר
      snprintf(msg, sizeof(msg), "[MP3] Scan failed fr=%d\r\n", (int)fr);                               // HE: שגיאה
      APP_Tx(msg);                                                                                     // HE: הדפסה
      g_state = APP_USB_STATE_MENU;                                                                    // HE: חזרה לתפריט
      APP_PrintMenu();                                                                                 // HE: הדפסת תפריט
      return;                                                                                          // HE: יציאה
    }

    g_state = APP_USB_STATE_MP3_LIST;                                                                  // HE: מעבר להצגת רשימה
    return;                                                                                            // HE: יציאה
  }

  /* ===== Option R: list SD root debug ===== */
  if (ch == 'R' || ch == 'r')                                                                          // HE: רשימת קבצים בשורש
  {
    APP_ListSdRoot();                                                                                  // HE: הדפסה
    APP_PrintMenu();                                                                                   // HE: חזרה לתפריט
    return;                                                                                            // HE: יציאה
  }

  /* ===== Option 9: VS1053 sine toggle ===== */
  if (ch == '9')                                                                                       // HE: VS1053 sine
  {
    if (!g_vs1053_attached)                                                                            // HE: לא הוצמד
    {
      APP_Tx("[VS1053] Not attached. Call APP_USB_VS1053_Attach() from main.c\r\n");                   // HE: הודעה
      g_state = APP_USB_STATE_MENU;                                                                    // HE: תפריט
      APP_PrintMenu();                                                                                 // HE: הדפסה
      return;                                                                                          // HE: יציאה
    }

    VS1053_Attach(&g_vs1053);                                                                          // HE: וידוא attach

    if (g_vs_sine_running)                                                                             // HE: אם רץ
    {
      APP_Tx("\r\n[VS1053] Sine stop\r\n");                                                            // HE: הודעה
      (void)VS1053_Test_SineContinuousStop();                                                          // HE: עצירה
      g_vs_sine_running = 0u;                                                                          // HE: סימון
      g_state = APP_USB_STATE_MENU;                                                                    // HE: תפריט
      APP_PrintMenu();                                                                                 // HE: הדפסה
      return;                                                                                          // HE: יציאה
    }
    /* File: app_usb.c                                                                 // HE: טיפול בקלט USB
       Why: Add option J to enter quaternion mode                                       // HE: הוספת מצב קווטרניונים
    */


    g_line_len = 0;                                                                                    // HE: איפוס קלט
    memset(g_line, 0, sizeof(g_line));                                                                 // HE: ניקוי

    APP_Tx("\r\n[VS1053] Choose volume 1..10 (1=quiet, 10=loud).THEN Enter:\r\n> ");                   // HE: בקשה
    g_state = APP_USB_STATE_VS1053_VOL;                                                                // HE: מצב קלט
    return;                                                                                            // HE: יציאה
  }

  /* ===== Unknown command ===== */
  return;                                                                                               // HE: לא זוהה, להתעלם
}
