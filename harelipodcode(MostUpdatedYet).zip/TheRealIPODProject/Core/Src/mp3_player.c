/* File: mp3_player.c                                                                                 // HE: נגן MP3 לא חוסם מה-SD ל-VS1053
   Why: Non-blocking playback so USB menu keeps working, toggle play/stop with 'P'                    // HE: מאפשר לעבור בתפריט בזמן ניגון
*/

#include "mp3_player.h"                                                                               // HE: כותרת המודול
#include "vs1053.h"                                                                                   // HE: דרייבר VS1053
#include "fatfs.h"                                                                                    // HE: SDFatFS
#include <string.h>                                                                                   // HE: memset, strlen
#include <stdio.h>                                                                                    // HE: snprintf

#ifndef MP3P_READ_CHUNK_BYTES                                                                          // HE: גודל בלוק קריאה
#define MP3P_READ_CHUNK_BYTES  512u                                                                    // HE: 512 בייט
#endif                                                                                                 // HE: סוף הגדרה

static volatile FRESULT s_last_fr = FR_OK;                                                             // HE: קוד FatFs אחרון
static volatile int     s_last_step = 0;                                                               // HE: שלב שגיאה אחרון

static FIL     s_fil;                                                                                  // HE: קובץ פתוח לניגון
static uint8_t s_mounted = 0u;                                                                         // HE: האם עשינו mount
static uint8_t s_playing = 0u;                                                                         // HE: האם כרגע מנגן
static uint8_t s_buf[MP3P_READ_CHUNK_BYTES];                                                           // HE: באפר נתונים
static UINT    s_br = 0u;                                                                              // HE: כמות בייטים שנקראה

FRESULT MP3P_GetLastFresult(void) { return (FRESULT)s_last_fr; }                                       // HE: החזרת קוד FatFs
int MP3P_GetLastErrStep(void) { return (int)s_last_step; }                                             // HE: החזרת שלב שגיאה
uint8_t MP3P_IsPlaying(void) { return s_playing; }                                                     // HE: האם מנגן

static void mp3p_cleanup(void)                                                                         // HE: ניקוי משאבים
{
    if (s_playing)                                                                                     // HE: אם מנגן
    {
        s_playing = 0u;                                                                                // HE: עצור דגל
    }
    (void)f_close(&s_fil);                                                                             // HE: סגירת קובץ אם פתוח
    if (s_mounted)                                                                                     // HE: אם mounted
    {
        (void)f_mount(NULL, "0:", 0);                                                                  // HE: unmount
        s_mounted = 0u;                                                                                // HE: איפוס
    }
}

int MP3P_Start(const char *filename)                                                                   // HE: התחלת ניגון לא חוסם
{
    s_last_fr = FR_OK;                                                                                 // HE: איפוס
    s_last_step = 0;                                                                                   // HE: איפוס

    if (filename == NULL || filename[0] == '\0')                                                       // HE: בדיקת קלט
    {
        s_last_step = 1;                                                                               // HE: שגיאה בקלט
        return -1;                                                                                     // HE: יציאה
    }

    MP3P_Stop();                                                                                       // HE: אם היה משהו מנגן, לעצור

    s_last_fr = f_mount(&SDFatFS, "0:", 1);                                                            // HE: mount על כונן 0
    if (s_last_fr != FR_OK) { s_last_step = 2; return -2; }                                            // HE: שגיאת mount
    s_mounted = 1u;                                                                                    // HE: סמן mounted

    memset(&s_fil, 0, sizeof(s_fil));                                                                  // HE: איפוס FIL

    char full[64];                                                                                     // HE: נתיב מלא
    snprintf(full, sizeof(full), "0:/%s", filename);                                                    // HE: "0:/FILE..."
    s_last_fr = f_open(&s_fil, full, FA_READ);                                                         // HE: פתיחה
    if (s_last_fr != FR_OK)                                                                            // HE: אם נכשל
    {
        snprintf(full, sizeof(full), "0:/FILE_E~1.MP3");                                                // HE: fallback שם 8.3 לדוגמה
        s_last_fr = f_open(&s_fil, full, FA_READ);                                                     // HE: פתיחה שוב
    }
    if (s_last_fr != FR_OK) { s_last_step = 3; mp3p_cleanup(); return -3; }                            // HE: שגיאת open

    if (VS1053_Init() != VS1053_OK)                                                                    // HE: אתחול VS1053
    {
        s_last_step = 4;                                                                               // HE: שגיאת VS init
        mp3p_cleanup();                                                                                // HE: ניקוי
        return -4;                                                                                     // HE: יציאה
    }

    (void)VS1053_SetVolume(25u, 25u);                                                                  // HE: עוצמה התחלתית

    s_playing = 1u;                                                                                    // HE: עכשיו מנגן
    return 0;                                                                                          // HE: הצלחה
}

void MP3P_Stop(void)                                                                                   // HE: עצירת ניגון
{
    mp3p_cleanup();                                                                                    // HE: סגירה+unmount
}

void MP3P_Tick(void)                                                                                   // HE: לשלוח עוד נתונים בכל Tick
{
    if (!s_playing) return;                                                                            // HE: אם לא מנגן, כלום

    s_br = 0u;                                                                                          // HE: איפוס כמות קריאה
    s_last_fr = f_read(&s_fil, s_buf, (UINT)MP3P_READ_CHUNK_BYTES, &s_br);                             // HE: קריאת בלוק
    if (s_last_fr != FR_OK)                                                                            // HE: שגיאת קריאה
    {
        s_last_step = 5;                                                                               // HE: שלב read
        MP3P_Stop();                                                                                   // HE: עצור
        return;                                                                                        // HE: יציאה
    }

    if (s_br == 0u)                                                                                    // HE: EOF
    {
        MP3P_Stop();                                                                                   // HE: סיום ניגון
        return;                                                                                        // HE: יציאה
    }

    if (VS1053_SDI_Send(s_buf, (uint16_t)s_br) != VS1053_OK)                                           // HE: שליחה ל-VS1053
    {
        s_last_step = 6;                                                                               // HE: שלב send
        MP3P_Stop();                                                                                   // HE: עצור
        return;                                                                                        // HE: יציאה
    }
}
