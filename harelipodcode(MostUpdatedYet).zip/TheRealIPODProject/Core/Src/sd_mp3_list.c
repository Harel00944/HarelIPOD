/* File: sd_mp3_list.c                                                                                            // HE: מימוש סריקת רשימת קבצי MP3 מה-SD באמצעות FatFs
   Why: Fix FR_NOT_ENABLED (fr=12) by doing f_mount before f_opendir, and scan root as "0:/".                    // HE: פתרון כשל mount/opendir
*/

#include "sd_mp3_list.h"                                                                                           // HE: כותרת המודול

#include "ff.h"                                                                                                     // HE: FatFs API (DIR, FILINFO, FRESULT, f_mount, f_opendir, f_readdir)
#include "fatfs.h"                                                                                                  // HE: SDFatFS (CubeMX global), SDPath (לא חובה כאן)

#include <string.h>                                                                                                 // HE: memset, strlen, strncpy
#include <ctype.h>                                                                                                  // HE: tolower
#include <stdint.h>                                                                                                 // HE: uint16_t

#ifndef _MAX_LFN                                                                                                    // HE: אם FatFs לא הוגדר עם LFN
#define _MAX_LFN 255                                                                                                // HE: הגדרה מקומית בטוחה למקרה שאין
#endif                                                                                                              // HE: סוף הגדרה

/* ===== Local helpers ===== */

static int sdmp3_has_mp3_ext(const char* name)                                                                      // HE: בדיקת סיומת MP3 (case-insensitive)
{                                                                                                                   // HE: תחילת פונקציה
  size_t n = 0u;                                                                                                    // HE: אורך מחרוזת

  if (name == NULL)                                                                                                 // HE: בדיקת NULL
  {                                                                                                                 // HE: פתיחה
    return 0;                                                                                                       // HE: אין שם
  }                                                                                                                 // HE: סגירה

  n = strlen(name);                                                                                                 // HE: חישוב אורך
  if (n < 4u)                                                                                                       // HE: מינימום ".mp3"
  {                                                                                                                 // HE: פתיחה
    return 0;                                                                                                       // HE: קצר מדי
  }                                                                                                                 // HE: סגירה

  char c1 = (char)tolower((unsigned char)name[n - 4u]);                                                             // HE: '.'
  char c2 = (char)tolower((unsigned char)name[n - 3u]);                                                             // HE: 'm'
  char c3 = (char)tolower((unsigned char)name[n - 2u]);                                                             // HE: 'p'
  char c4 = (char)tolower((unsigned char)name[n - 1u]);                                                             // HE: '3'

  if ((c1 == '.') && (c2 == 'm') && (c3 == 'p') && (c4 == '3'))                                                     // HE: בדיקת ".mp3"
  {                                                                                                                 // HE: פתיחה
    return 1;                                                                                                       // HE: כן MP3
  }                                                                                                                 // HE: סגירה

  return 0;                                                                                                         // HE: לא MP3
}                                                                                                                   // HE: סוף פונקציה

static void sdmp3_clear_list(SdMp3List_t* out_list)                                                                 // HE: ניקוי מבנה הפלט
{                                                                                                                   // HE: תחילת פונקציה
  if (out_list == NULL)                                                                                             // HE: בדיקת NULL
  {                                                                                                                 // HE: פתיחה
    return;                                                                                                         // HE: אין מה לנקות
  }                                                                                                                 // HE: סגירה
  memset(out_list, 0, sizeof(*out_list));                                                                           // HE: איפוס כל המבנה
}                                                                                                                   // HE: סוף פונקציה

/* ===== Public API ===== */

FRESULT SD_MP3_ListScanRoot(SdMp3List_t* out_list)                                                                  // HE: סריקה של השורש בכרטיס
{                                                                                                                   // HE: תחילת פונקציה
  return SD_MP3_ListScanDir("0:/", out_list);                                                                       // HE: שורש נכון ל-FatFs
}                                                                                                                   // HE: סוף פונקציה

FRESULT SD_MP3_ListScanDir(const char* dir_path, SdMp3List_t* out_list)                                             // HE: סריקה של תיקייה והחזרת שמות MP3
{                                                                                                                   // HE: תחילת פונקציה
  DIR dir;                                                                                                          // HE: אובייקט תיקייה
  FILINFO fno;                                                                                                      // HE: מידע על קובץ
  FRESULT fr = FR_INVALID_OBJECT;                                                                                   // HE: תוצאת FatFs
  uint16_t count = 0u;                                                                                              // HE: מונה קבצים

#if (_USE_LFN == 1)                                                                                                  // HE: אם LFN פעיל ב-FatFs
  static char lfn[_MAX_LFN + 1u];                                                                                   // HE: באפר לשם ארוך
  fno.lfname = lfn;                                                                                                 // HE: הצמדת באפר ל-LFN
  fno.lfsize = (UINT)sizeof(lfn);                                                                                   // HE: גודל הבאפר
#endif                                                                                                              // HE: סוף בלוק LFN

  if ((dir_path == NULL) || (out_list == NULL))                                                                     // HE: בדיקת פרמטרים
  {                                                                                                                 // HE: פתיחה
    return FR_INVALID_OBJECT;                                                                                       // HE: פרמטרים לא תקינים
  }                                                                                                                 // HE: סגירה

  sdmp3_clear_list(out_list);                                                                                       // HE: ניקוי פלט

  /* חובה: mount לפני opendir, אחרת תקבל fr=12 (FR_NOT_ENABLED) */
  fr = f_mount(&SDFatFS, "0:", 1);                                                                                  // HE: mount לכונן 0
  if (fr != FR_OK)                                                                                                  // HE: אם נכשל
  {                                                                                                                 // HE: פתיחה
    return fr;                                                                                                      // HE: החזרת שגיאה
  }                                                                                                                 // HE: סגירה

  fr = f_opendir(&dir, dir_path);                                                                                   // HE: פתיחת תיקייה לסריקה
  if (fr != FR_OK)                                                                                                  // HE: אם נכשל
  {                                                                                                                 // HE: פתיחה
    (void)f_mount(NULL, "0:", 0);                                                                                   // HE: unmount כדי לא להשאיר מצב תלוי
    return fr;                                                                                                      // HE: החזרת שגיאה
  }                                                                                                                 // HE: סגירה

  for (;;)                                                                                                          // HE: לולאת קריאת רשומות
  {                                                                                                                 // HE: פתיחה
    fr = f_readdir(&dir, &fno);                                                                                     // HE: קריאת רשומה הבאה
    if (fr != FR_OK)                                                                                                // HE: שגיאת קריאה
    {                                                                                                               // HE: פתיחה
      break;                                                                                                        // HE: יציאה עם שגיאה
    }                                                                                                               // HE: סגירה

    if (fno.fname[0] == '\0')                                                                                       // HE: סוף התיקייה
    {                                                                                                               // HE: פתיחה
      fr = FR_OK;                                                                                                   // HE: סיום תקין
      break;                                                                                                        // HE: יציאה מהלולאה
    }                                                                                                               // HE: סגירה

    if ((fno.fattrib & AM_DIR) != 0u)                                                                               // HE: אם זו תיקייה
    {                                                                                                               // HE: פתיחה
      continue;                                                                                                     // HE: מדלגים על תיקיות
    }                                                                                                               // HE: סגירה

#if (_USE_LFN == 1)                                                                                                  // HE: אם יש LFN
    const char* name = (fno.lfname != NULL && fno.lfname[0] != '\0') ? fno.lfname : fno.fname;                     // HE: העדפה לשם ארוך אם קיים
#else                                                                                                               // HE: אם אין LFN
    const char* name = fno.fname;                                                                                   // HE: משתמשים בשם הקצר
#endif                                                                                                              // HE: סוף בחירת שם

    if (!sdmp3_has_mp3_ext(name))                                                                                   // HE: אם לא MP3
    {                                                                                                               // HE: פתיחה
      continue;                                                                                                     // HE: דילוג
    }                                                                                                               // HE: סגירה

    if (count >= (uint16_t)SD_MP3_LIST_MAX_FILES)                                                                   // HE: בדיקת חריגה ממקסימום
    {                                                                                                               // HE: פתיחה
      break;                                                                                                        // HE: עוצרים כדי לא לחרוג מהמערך
    }                                                                                                               // HE: סגירה

    strncpy(out_list->names[count], name, (size_t)SD_MP3_LIST_MAX_NAME - 1u);                                       // HE: העתקת שם לקלט
    out_list->names[count][SD_MP3_LIST_MAX_NAME - 1u] = '\0';                                                       // HE: הבטחת סיום מחרוזת

    count++;                                                                                                        // HE: העלאת מונה
  }                                                                                                                 // HE: סוף הלולאה

  (void)f_closedir(&dir);                                                                                           // HE: סגירת תיקייה
  (void)f_mount(NULL, "0:", 0);                                                                                     // HE: unmount בסוף הסריקה

  out_list->count = count;                                                                                          // HE: שמירת הכמות שנמצאה
  return fr;                                                                                                        // HE: החזרת תוצאה סופית
}                                                                                                                   // HE: סוף פונקציה
