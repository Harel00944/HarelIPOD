/* File: sd_tests.c                                                                                 // HE: מימוש מינימלי לפונקציות בדיקת SD כדי לפתור Linker errors
   Why: app_usb.c calls these functions, but project currently has no linked implementation         // HE: למה הקובץ קיים
*/
#include "sd_tests.h"                                                                               // HE: כולל את הכותרת עם הפרוטוטייפים

void SD_Test_SDIO_Registers(void)                                                                   // HE: סטאב, מימוש זמני
{                                                                                                   // HE: פתיחת פונקציה
  /* TODO: Implement real SDIO register test */                                                     // HE: בעתיד להוסיף בדיקה אמיתית
}                                                                                                   // HE: סגירת פונקציה

void SD_Test_DetailedInfo(void)                                                                     // HE: סטאב, מימוש זמני
{                                                                                                   // HE: פתיחת פונקציה
  /* TODO: Implement real SD card info print */                                                     // HE: בעתיד להדפיס CID/CSD ועוד
}                                                                                                   // HE: סגירת פונקציה

void SD_Test_FatFs_Extended(void)                                                                   // HE: סטאב, מימוש זמני
{                                                                                                   // HE: פתיחת פונקציה
  /* TODO: Implement real FatFs mount/read/write tests */                                           // HE: בעתיד לבצע Mount וקריאה/כתיבה
}                                                                                                   // HE: סגירת פונקציה
