/* File: BNO055.c                                                                 // HE: דרייבר BNO055 (I2C), קריאה בסיסית של מזהים/כיול/אאולר/קווטרניון
   Why: לאפשר אתחול וקריאה של נתונים מה-BNO055 בלי לשנות את שאר הפרויקט, משתמש ב-HAL I2C וב-main.h לפינים/handles  // HE: למה הקובץ
*/

#include "BNO055.h"                                                              // HE: כותרת דרייבר BNO055
#include "main.h"                                                                // HE: גישה ל-hi2c1 והגדרות HAL
#include <string.h>                                                              // HE: memset

/* ============================== */
/* ===== USER CONFIG AREA ======= */
/* ============================== */
/* NOTE: הקובץ הזה מניח שאתה משתמש ב-I2C1 דרך hi2c1 כמו בפרויקט שלך.            // HE: הערה
         אם ב-header שלך מוגדר handle אחר, שנה רק ב-header, לא פה.             // HE: הערה
*/

/* ============================== */
/* ===== BNO055 REGISTERS ======= */
/* ============================== */
#define BNO055_I2C_ADDR_LO            (0x28u)                                    // HE: כתובת I2C כשה-ADR נמוך
#define BNO055_I2C_ADDR_HI            (0x29u)                                    // HE: כתובת I2C כשה-ADR גבוה
#define BNO055_I2C_ADDR               (BNO055_I2C_ADDR_LO)                       // HE: ברירת מחדל 0x28

#define BNO055_REG_CHIP_ID            (0x00u)                                    // HE: מזהה שבב
#define BNO055_REG_ACC_ID             (0x01u)                                    // HE: מזהה אקסלרומטר
#define BNO055_REG_MAG_ID             (0x02u)                                    // HE: מזהה מגנטומטר
#define BNO055_REG_GYR_ID             (0x03u)                                    // HE: מזהה ג'יירו
#define BNO055_REG_SW_REV_ID_LSB      (0x04u)                                    // HE: גרסת תוכנה LSB
#define BNO055_REG_SW_REV_ID_MSB      (0x05u)                                    // HE: גרסת תוכנה MSB
#define BNO055_REG_BL_REV_ID          (0x06u)                                    // HE: גרסת Bootloader

#define BNO055_REG_PAGE_ID            (0x07u)                                    // HE: בחירת עמוד רגיסטרים

#define BNO055_REG_OPR_MODE           (0x3Du)                                    // HE: מצב פעולה
#define BNO055_REG_PWR_MODE           (0x3Eu)                                    // HE: מצב צריכת חשמל
#define BNO055_REG_SYS_TRIGGER        (0x3Fu)                                    // HE: טריגרים מערכתיים
#define BNO055_REG_TEMP_SOURCE        (0x40u)                                    // HE: מקור טמפ'
#define BNO055_REG_SYS_STAT           (0x39u)                                    // HE: סטטוס מערכת
#define BNO055_REG_SYS_ERR            (0x3Au)                                    // HE: שגיאת מערכת
#define BNO055_REG_UNIT_SEL           (0x3Bu)                                    // HE: יחידות
#define BNO055_REG_AXIS_MAP_CONFIG    (0x41u)                                    // HE: מיפוי צירים
#define BNO055_REG_AXIS_MAP_SIGN      (0x42u)                                    // HE: סימני צירים

#define BNO055_REG_CALIB_STAT         (0x35u)                                    // HE: סטטוס כיול
#define BNO055_REG_EULER_H_LSB        (0x1Au)                                    // HE: Heading LSB
#define BNO055_REG_EULER_H_MSB        (0x1Bu)                                    // HE: Heading MSB
#define BNO055_REG_EULER_R_LSB        (0x1Cu)                                    // HE: Roll LSB
#define BNO055_REG_EULER_R_MSB        (0x1Du)                                    // HE: Roll MSB
#define BNO055_REG_EULER_P_LSB        (0x1Eu)                                    // HE: Pitch LSB
#define BNO055_REG_EULER_P_MSB        (0x1Fu)                                    // HE: Pitch MSB

#define BNO055_REG_QUAT_W_LSB         (0x20u)                                    // HE: Quaternion W LSB
#define BNO055_REG_QUAT_W_MSB         (0x21u)                                    // HE: Quaternion W MSB
#define BNO055_REG_QUAT_X_LSB         (0x22u)                                    // HE: Quaternion X LSB
#define BNO055_REG_QUAT_X_MSB         (0x23u)                                    // HE: Quaternion X MSB
#define BNO055_REG_QUAT_Y_LSB         (0x24u)                                    // HE: Quaternion Y LSB
#define BNO055_REG_QUAT_Y_MSB         (0x25u)                                    // HE: Quaternion Y MSB
#define BNO055_REG_QUAT_Z_LSB         (0x26u)                                    // HE: Quaternion Z LSB
#define BNO055_REG_QUAT_Z_MSB         (0x27u)                                    // HE: Quaternion Z MSB

/* ============================== */
/* ===== BNO055 CONSTANTS ======= */
/* ============================== */
#define BNO055_CHIP_ID_VALUE          (0xA0u)                                    // HE: ערך מזהה שבב צפוי
#define BNO055_PAGE_0                 (0x00u)                                    // HE: Page 0
#define BNO055_PAGE_1                 (0x01u)                                    // HE: Page 1

#define BNO055_REG_LIA_X_LSB           (0x28u)                                     // HE: Linear Accel X LSB
#define BNO055_REG_LIA_X_MSB           (0x29u)                                     // HE: Linear Accel X MSB
#define BNO055_REG_LIA_Y_LSB           (0x2Au)                                     // HE: Linear Accel Y LSB
#define BNO055_REG_LIA_Y_MSB           (0x2Bu)                                     // HE: Linear Accel Y MSB
#define BNO055_REG_LIA_Z_LSB           (0x2Cu)                                     // HE: Linear Accel Z LSB
#define BNO055_REG_LIA_Z_MSB           (0x2Du)                                     // HE: Linear Accel Z MSB



/* Power modes */
#define BNO055_PWR_MODE_NORMAL        (0x00u)                                    // HE: Normal power

/* Operation modes */
#define BNO055_OPMODE_CONFIG          (0x00u)                                    // HE: Config mode
#define BNO055_OPMODE_NDOF            (0x0Cu)                                    // HE: NDOF fusion

/* Unit selection defaults (common) */
#define BNO055_UNIT_SEL_DEFAULT       (0x00u)                                    // HE: ברירת מחדל: deg, m/s^2, C, etc

/* ============================== */
/* ===== DRIVER STATE =========== */
/* ============================== */
static I2C_HandleTypeDef *bno_i2c = NULL;                                       // HE: מצביע ל-I2C
static uint8_t bno_addr = (BNO055_I2C_ADDR << 1);                                // HE: כתובת 8bit ל-HAL (שיפט)

/* ============================== */
/* ===== LOW LEVEL I2C ========== */
/* ============================== */
static HAL_StatusTypeDef BNO055_I2C_Write8(uint8_t reg, uint8_t val)            // HE: כתיבה רגיסטר 8bit
{
    if (bno_i2c == NULL)
    {
        return HAL_ERROR;
    }
    return HAL_I2C_Mem_Write(bno_i2c,
                             bno_addr,
                             reg,
                             I2C_MEMADD_SIZE_8BIT,
                             &val,
                             1u,
                             HAL_MAX_DELAY);
}

static HAL_StatusTypeDef BNO055_I2C_Read(uint8_t reg, uint8_t *buf, uint16_t len) // HE: קריאה רציפה מרגיסטר
{
    if (bno_i2c == NULL || buf == NULL || len == 0u)
    {
        return HAL_ERROR;
    }
    return HAL_I2C_Mem_Read(bno_i2c,
                            bno_addr,
                            reg,
                            I2C_MEMADD_SIZE_8BIT,
                            buf,
                            len,
                            HAL_MAX_DELAY);
}

static HAL_StatusTypeDef BNO055_I2C_Read8(uint8_t reg, uint8_t *val)            // HE: קריאה רגיסטר יחיד
{
    return BNO055_I2C_Read(reg, val, 1u);
}

/* ============================== */
/* ===== INTERNAL HELPERS ======= */
/* ============================== */
static void BNO055_DelayMs(uint32_t ms)                                         // HE: דיליי פשוט
{
    HAL_Delay(ms);
}

static HAL_StatusTypeDef BNO055_SetPage(uint8_t page)                           // HE: בחירת Page
{
    return BNO055_I2C_Write8(BNO055_REG_PAGE_ID, page);
}

static HAL_StatusTypeDef BNO055_SetMode(uint8_t mode)                           // HE: שינוי מצב עבודה
{
    HAL_StatusTypeDef st = BNO055_I2C_Write8(BNO055_REG_OPR_MODE, mode);
    BNO055_DelayMs(25);                                                         // HE: זמן מעבר מצב אופייני
    return st;
}

static HAL_StatusTypeDef BNO055_SoftReset(void)                                 // HE: Soft reset
{
    HAL_StatusTypeDef st;

    st = BNO055_SetPage(BNO055_PAGE_0);
    if (st != HAL_OK)
    {
        return st;
    }

    st = BNO055_I2C_Write8(BNO055_REG_SYS_TRIGGER, 0x20u);                      // HE: RST_SYS bit
    BNO055_DelayMs(700);                                                        // HE: זמן התאוששות אחרי reset
    return st;
}

static HAL_StatusTypeDef BNO055_WaitForChipId(uint32_t timeout_ms)              // HE: לחכות עד שה-CHIP_ID נכון
{
    uint32_t start = HAL_GetTick();
    uint8_t id = 0;

    while ((HAL_GetTick() - start) < timeout_ms)
    {
        if (BNO055_I2C_Read8(BNO055_REG_CHIP_ID, &id) == HAL_OK)
        {
            if (id == BNO055_CHIP_ID_VALUE)
            {
                return HAL_OK;
            }
        }
        BNO055_DelayMs(10);
    }
    return HAL_TIMEOUT;
}

/* ============================== */
/* ===== PUBLIC API ============= */
/* ============================== */
void BNO055_Init(I2C_HandleTypeDef *hi2c)                                      // HE: אתחול דרייבר
{
    bno_i2c = hi2c;                                                             // HE: שמירת handle
}

uint8_t BNO055_IsPresent(void)                                                  // HE: בדיקת זיהוי שבב
{
    uint8_t id = 0;

    if (bno_i2c == NULL)
    {
        return 0u;
    }

    if (BNO055_I2C_Read8(BNO055_REG_CHIP_ID, &id) != HAL_OK)
    {
        return 0u;
    }

    return (id == BNO055_CHIP_ID_VALUE) ? 1u : 0u;
}

uint8_t BNO055_Begin(void)                                                      // HE: אתחול מלא לשימוש NDOF
{
    if (bno_i2c == NULL)
    {
        return 0u;
    }

    if (BNO055_WaitForChipId(1000) != HAL_OK)                                   // HE: המתנה לשבב
    {
        return 0u;
    }

    if (BNO055_SetMode(BNO055_OPMODE_CONFIG) != HAL_OK)                         // HE: מעבר ל-Config
    {
        return 0u;
    }

    if (BNO055_SoftReset() != HAL_OK)                                           // HE: reset
    {
        return 0u;
    }

    if (BNO055_WaitForChipId(1000) != HAL_OK)                                   // HE: המתנה שוב
    {
        return 0u;
    }

    if (BNO055_SetPage(BNO055_PAGE_0) != HAL_OK)                                // HE: Page 0
    {
        return 0u;
    }

    if (BNO055_SetMode(BNO055_OPMODE_CONFIG) != HAL_OK)                         // HE: להבטיח Config
    {
        return 0u;
    }

    if (BNO055_I2C_Write8(BNO055_REG_PWR_MODE, BNO055_PWR_MODE_NORMAL) != HAL_OK) // HE: Power normal
    {
        return 0u;
    }
    BNO055_DelayMs(10);

    (void)BNO055_I2C_Write8(BNO055_REG_UNIT_SEL, BNO055_UNIT_SEL_DEFAULT);      // HE: יחידות ברירת מחדל
    BNO055_DelayMs(10);

    (void)BNO055_I2C_Write8(BNO055_REG_SYS_TRIGGER, 0x00u);                    // HE: Normal mode
    BNO055_DelayMs(10);

    if (BNO055_SetMode(BNO055_OPMODE_NDOF) != HAL_OK)                           // HE: NDOF
    {
        return 0u;
    }

    BNO055_DelayMs(50);                                                         // HE: זמן התייצבות קצר
    return 1u;
}

uint8_t BNO055_ReadChipId(uint8_t *out_id)                                      // HE: קריאת CHIP_ID
{
    if (out_id == NULL)
    {
        return 0u;
    }
    return (BNO055_I2C_Read8(BNO055_REG_CHIP_ID, out_id) == HAL_OK) ? 1u : 0u;
}

uint8_t BNO055_ReadSystemStatus(uint8_t *sys_stat, uint8_t *sys_err)            // HE: סטטוס מערכת ושגיאה
{
    uint8_t s = 0, e = 0;

    if (BNO055_I2C_Read8(BNO055_REG_SYS_STAT, &s) != HAL_OK)
    {
        return 0u;
    }
    if (BNO055_I2C_Read8(BNO055_REG_SYS_ERR, &e) != HAL_OK)
    {
        return 0u;
    }

    if (sys_stat) *sys_stat = s;
    if (sys_err)  *sys_err  = e;
    return 1u;
}


/* File: BNO055.c                                                                  // HE: קריאת UNIT_SEL
   Why: לדעת האם תאוצה היא mg או m/s^2 כדי להמיר נכון ל-g                         // HE: ביטול ניחוש סקייל
*/
uint8_t BNO055_ReadUnitSel(uint8_t *unit_sel)                                      // HE: קריאת רגיסטר יחידות
{
  if (!unit_sel) return 0u;                                                        // HE: בדיקת מצביע
  return (BNO055_I2C_Read8(BNO055_REG_UNIT_SEL, unit_sel) == HAL_OK) ? 1u : 0u;    // HE: קריאה
}



uint8_t BNO055_ReadCalibStatus(uint8_t *sys, uint8_t *gyro, uint8_t *accel, uint8_t *mag) // HE: סטטוס כיול
{
    uint8_t c = 0;

    if (BNO055_I2C_Read8(BNO055_REG_CALIB_STAT, &c) != HAL_OK)
    {
        return 0u;
    }

    if (sys)  *sys  = (uint8_t)((c >> 6) & 0x03u);
    if (gyro) *gyro = (uint8_t)((c >> 4) & 0x03u);
    if (accel)*accel= (uint8_t)((c >> 2) & 0x03u);
    if (mag)  *mag  = (uint8_t)((c >> 0) & 0x03u);

    return 1u;
}

static int16_t BNO055_ReadS16LE(uint8_t reg_lsb)                                 // HE: קריאת signed 16 little-endian
{
    uint8_t b[2] = {0, 0};

    if (BNO055_I2C_Read(reg_lsb, b, 2u) != HAL_OK)
    {
        return 0;
    }

    return (int16_t)((int16_t)b[0] | ((int16_t)b[1] << 8));
}

uint8_t BNO055_ReadEuler_deg_x16(int16_t *heading, int16_t *roll, int16_t *pitch) // HE: Euler ביחידות 1/16 deg
{
    if (heading == NULL || roll == NULL || pitch == NULL)
    {
        return 0u;
    }

    *heading = BNO055_ReadS16LE(BNO055_REG_EULER_H_LSB);
    *roll    = BNO055_ReadS16LE(BNO055_REG_EULER_R_LSB);
    *pitch   = BNO055_ReadS16LE(BNO055_REG_EULER_P_LSB);

    return 1u;
}

uint8_t BNO055_ReadQuat_raw(int16_t *w, int16_t *x, int16_t *y, int16_t *z)      // HE: Quaternion raw
{
    if (w == NULL || x == NULL || y == NULL || z == NULL)
    {
        return 0u;
    }

    *w = BNO055_ReadS16LE(BNO055_REG_QUAT_W_LSB);
    *x = BNO055_ReadS16LE(BNO055_REG_QUAT_X_LSB);
    *y = BNO055_ReadS16LE(BNO055_REG_QUAT_Y_LSB);
    *z = BNO055_ReadS16LE(BNO055_REG_QUAT_Z_LSB);

    return 1u;
}

uint8_t BNO055_SetExternalCrystal(uint8_t enable)                               // HE: בחירת XTAL חיצוני אם מחובר
{
    if (BNO055_SetMode(BNO055_OPMODE_CONFIG) != HAL_OK)                         // HE: חייבים Config
    {
        return 0u;
    }

    uint8_t trig = (enable != 0u) ? 0x80u : 0x00u;                              // HE: CLK_SEL bit
    if (BNO055_I2C_Write8(BNO055_REG_SYS_TRIGGER, trig) != HAL_OK)
    {
        return 0u;
    }

    BNO055_DelayMs(10);

    if (BNO055_SetMode(BNO055_OPMODE_NDOF) != HAL_OK)                           // HE: חזרה ל-NDOF
    {
        return 0u;
    }

    BNO055_DelayMs(10);
    return 1u;
}

uint8_t BNO055_SetAxisMap(uint8_t map_config, uint8_t map_sign)                 // HE: מיפוי צירים
{
    if (BNO055_SetMode(BNO055_OPMODE_CONFIG) != HAL_OK)                         // HE: Config
    {
        return 0u;
    }

    if (BNO055_I2C_Write8(BNO055_REG_AXIS_MAP_CONFIG, map_config) != HAL_OK)
    {
        return 0u;
    }
    if (BNO055_I2C_Write8(BNO055_REG_AXIS_MAP_SIGN, map_sign) != HAL_OK)
    {
        return 0u;
    }

    BNO055_DelayMs(10);

    if (BNO055_SetMode(BNO055_OPMODE_NDOF) != HAL_OK)                           // HE: חזרה
    {
        return 0u;
    }

    BNO055_DelayMs(10);
    return 1u;
}

uint8_t BNO055_Reset(void)                                                      // HE: איפוס דרייבר
{
    if (BNO055_SetMode(BNO055_OPMODE_CONFIG) != HAL_OK)
    {
        return 0u;
    }

    if (BNO055_SoftReset() != HAL_OK)
    {
        return 0u;
    }

    if (BNO055_WaitForChipId(1000) != HAL_OK)
    {
        return 0u;
    }

    return 1u;
}


/* File: BNO055.c */                                                                 // HE: דרייבר BNO055
int bno055_readData(uint8_t reg, uint8_t *data, uint8_t len)                         // HE: קריאה מרגיסטרים, 0=OK
{
  if (data == NULL || len == 0u)                                                     // HE: בדיקת קלט
  {
    return -1;                                                                       // HE: קלט לא תקין
  }

  if (BNO055_I2C_Read(reg, data, (uint16_t)len) != HAL_OK)                           // HE: שימוש בפונקציה הפנימית שכבר קיימת
  {
    return -2;                                                                       // HE: כשל I2C
  }

  return 0;                                                                          // HE: הצלחה
}

/* File: BNO055.c                                                                  // HE: קריאת Linear Acceleration RAW
   Why: קריאת 0x28..0x2D לפי הדאטה שיט                                            // HE: LIA בלי כבידה
*/
uint8_t BNO055_ReadLinAcc_raw(int16_t *ax, int16_t *ay, int16_t *az)                // HE: קריאת LIA RAW
{
  if (!ax || !ay || !az) return 0u;                                                // HE: בדיקת מצביעים

  uint8_t buf[6];                                                                  // HE: 6 בתים
  if (BNO055_I2C_Read(BNO055_REG_LIA_X_LSB, buf, 6u) != HAL_OK)                    // HE: קריאה רציפה
  {
    return 0u;                                                                     // HE: כשל
  }

  *ax = (int16_t)((uint16_t)buf[0] | ((uint16_t)buf[1] << 8));                     // HE: X
  *ay = (int16_t)((uint16_t)buf[2] | ((uint16_t)buf[3] << 8));                     // HE: Y
  *az = (int16_t)((uint16_t)buf[4] | ((uint16_t)buf[5] << 8));                     // HE: Z

  return 1u;                                                                       // HE: הצלחה
}


/* File: BNO055.c                                                                  // HE: תאוצה לינארית בעולם ביחידות g
   Why: לקרוא LIA RAW, לקבוע סקייל לפי UNIT_SEL, ואז לסובב לעולם עם קווטרניון     // HE: Q עובד נכון
*/
uint8_t BNO055_ReadWorldLinAcc_g(float *ax_w, float *ay_w, float *az_w)             // HE: תאוצה בעולם (g)
{
  if (!ax_w || !ay_w || !az_w) return 0u;                                          // HE: בדיקת מצביעים

  int16_t ax_raw = 0, ay_raw = 0, az_raw = 0;                                      // HE: LIA RAW
  if (!BNO055_ReadLinAcc_raw(&ax_raw, &ay_raw, &az_raw))                           // HE: קריאה
  {
    return 0u;                                                                     // HE: כשל
  }

  int16_t qw_raw = 0, qx_raw = 0, qy_raw = 0, qz_raw = 0;                          // HE: קווטרניון RAW
  if (!BNO055_ReadQuat_raw(&qw_raw, &qx_raw, &qy_raw, &qz_raw))                    // HE: קריאה
  {
    return 0u;                                                                     // HE: כשל
  }

  /* ===== Quaternion scale (datasheet): 1 LSB = 1/16384 ===== */                  // HE: סקייל קווטרניון
  const float Q_SCALE = 16384.0f;                                                  // HE: קבוע
  float qw = ((float)qw_raw) / Q_SCALE;                                            // HE: נרמול
  float qx = ((float)qx_raw) / Q_SCALE;                                            // HE: נרמול
  float qy = ((float)qy_raw) / Q_SCALE;                                            // HE: נרמול
  float qz = ((float)qz_raw) / Q_SCALE;                                            // HE: נרמול

  /* ===== Determine LIA units from UNIT_SEL ===== */                              // HE: קביעת סקייל לפי UNIT_SEL
  uint8_t unit_sel = 0;                                                            // HE: רגיסטר יחידות
  if (!BNO055_ReadUnitSel(&unit_sel))                                              // HE: קריאה
  {
    return 0u;                                                                     // HE: כשל
  }

  /* HE: ביט 0 קובע יחידות תאוצה:
     0 = m/s^2, 1 = mg.
     אם mg: 1 LSB = 1 mg -> g = raw * 0.001
     אם m/s^2: לפי הדאטה שיט הרזולוציה היא 0.01 m/s^2 per LSB -> g = raw * 0.01 / 9.80665
  */
  float lsb_to_g = 0.001f;                                                         // HE: mg->g
  if ((unit_sel & 0x01u) == 0u)                                                    // HE: m/s^2
  {
    lsb_to_g = (0.01f / 9.80665f);                                                 // HE: m/s^2->g
  }

  float vx = ((float)ax_raw) * lsb_to_g;                                           // HE: v_body x (g)
  float vy = ((float)ay_raw) * lsb_to_g;                                           // HE: v_body y (g)
  float vz = ((float)az_raw) * lsb_to_g;                                           // HE: v_body z (g)

  /* ===== Rotate vector to world frame: v_world = q * v_body * q_conj ===== */    // HE: סיבוב לעולם
  float t0 = 2.0f * (qy * vz - qz * vy);                                           // HE: עזר
  float t1 = 2.0f * (qz * vx - qx * vz);                                           // HE: עזר
  float t2 = 2.0f * (qx * vy - qy * vx);                                           // HE: עזר

  *ax_w = vx + qw * t0 + (qy * t2 - qz * t1);                                      // HE: world x
  *ay_w = vy + qw * t1 + (qz * t0 - qx * t2);                                      // HE: world y
  *az_w = vz + qw * t2 + (qx * t1 - qy * t0);                                      // HE: world z

  return 1u;                                                                       // HE: הצלחה
}



