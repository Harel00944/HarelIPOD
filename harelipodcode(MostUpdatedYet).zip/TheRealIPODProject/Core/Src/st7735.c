/* File: st7735.c                                                                               // HE: קובץ מימוש דרייבר ST7735
   Purpose: minimal functions to initialize the display and write text centered                  // HE: מטרת הקובץ
*/

#include "st7735.h"                                                                             // HE: כותרת דרייבר
#include <string.h>                                                                             // HE: strlen, memset
#include <ctype.h>                                                                              // HE: tolower

/* ===== Forward declarations (MUST appear before first use) ===== */                            // HE: הצהרות קדמיות כדי למנוע implicit decl
static void ST7735_BeginRAMWrite(void);                                                         // HE: התחלת כתיבת RAMWR
static void ST7735_Select(void);                                                                // HE: CS=0
static void ST7735_Unselect(void);                                                              // HE: CS=1
static void ST7735_DC_Command(void);                                                            // HE: DC=0
static void ST7735_DC_Data(void);                                                               // HE: DC=1
static void ST7735_Reset(void);                                                                 // HE: פולס Reset
static void ST7735_BacklightOn(void);                                                           // HE: הדלקת תאורה אחורית
static void ST7735_WriteCommand(uint8_t cmd);                                                   // HE: שליחת פקודה
static void ST7735_WriteData(uint8_t *data, uint16_t size);                                     // HE: שליחת דאטה
static void ST7735_SetAddressWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1);        // HE: חלון כתיבה
static void ST7735_DrawPixel(uint16_t x, uint16_t y, uint16_t color);                           // HE: פיקסל יחיד

/* ===== Font types (MUST appear before scaled font functions) ===== */                         // HE: טיפוס פונט
typedef struct
{
    uint8_t rows[7];                                                                            // HE: 7 שורות, כל שורה 5 ביטים בשימוש
} Letter5x7;                                                                                     // HE: אות 5x7

static const Letter5x7* ST7735_GetLetter5x7(char c);                                            // HE: מיפוי תו לביטמאפ

/* ===== Globals ===== */                                                                       // HE: משתנים גלובליים לקובץ
static uint8_t g_st7735_madctl_bgr = 0x08u;                                                     // HE: BGR bit

/* ===== Rotation ===== */                                                                      // HE: סיבוב תצוגה
void ST7735_SetRotation(uint8_t rot)                                                            // HE: קביעת סיבוב תצוגה
{
    uint8_t madctl = g_st7735_madctl_bgr;                                                       // HE: מתחילים מ-BGR
    rot &= 3u;                                                                                  // HE: רק 0..3

    switch (rot)                                                                                // HE: בחירת סיבוב
    {
        case 0:                                                                                 // HE: 0 מעלות
            madctl |= 0x00u;                                                                    // HE: ללא MX/MY/MV
            break;                                                                              // HE: יציאה

        case 1:                                                                                 // HE: 90 מעלות
            madctl |= 0x60u;                                                                    // HE: MV|MX
            break;                                                                              // HE: יציאה

        case 2:                                                                                 // HE: 180 מעלות
            madctl |= 0xC0u;                                                                    // HE: MY|MX
            break;                                                                              // HE: יציאה

        default:                                                                                // HE: 270 מעלות
            madctl |= 0xA0u;                                                                    // HE: MV|MY
            break;                                                                              // HE: יציאה
    }

    ST7735_WriteCommand(0x36);                                                                  // HE: MADCTL
    ST7735_WriteData(&madctl, 1);                                                               // HE: כתיבת הערך
}

/* ===== GPIO helpers ===== */                                                                  // HE: עזרי GPIO
static void ST7735_Select(void)                                                                 // HE: CS=0
{
    HAL_GPIO_WritePin(ST7735_CS_GPIO, ST7735_CS_PIN, GPIO_PIN_RESET);                           // HE: בחירה במסך
}

static void ST7735_Unselect(void)                                                               // HE: CS=1
{
    HAL_GPIO_WritePin(ST7735_CS_GPIO, ST7735_CS_PIN, GPIO_PIN_SET);                             // HE: שחרור מסך
}

static void ST7735_DC_Command(void)                                                             // HE: DC=0
{
    HAL_GPIO_WritePin(ST7735_DC_GPIO, ST7735_DC_PIN, GPIO_PIN_RESET);                           // HE: מצב פקודה
}

static void ST7735_DC_Data(void)                                                                // HE: DC=1
{
    HAL_GPIO_WritePin(ST7735_DC_GPIO, ST7735_DC_PIN, GPIO_PIN_SET);                             // HE: מצב דאטה
}

/* ===== Reset and backlight ===== */                                                           // HE: Reset ותאורה
static void ST7735_Reset(void)                                                                  // HE: פולס Reset
{
    HAL_GPIO_WritePin(ST7735_RES_GPIO, ST7735_RES_PIN, GPIO_PIN_RESET);                         // HE: RES=0
    HAL_Delay(10);                                                                              // HE: השהייה
    HAL_GPIO_WritePin(ST7735_RES_GPIO, ST7735_RES_PIN, GPIO_PIN_SET);                           // HE: RES=1
    HAL_Delay(120);                                                                             // HE: זמן התייצבות
}

static void ST7735_BacklightOn(void)                                                            // HE: תאורה אחורית
{
    HAL_GPIO_WritePin(ST7735_BL_GPIO, ST7735_BL_PIN, GPIO_PIN_SET);                             // HE: BL=1
}

/* ===== SPI send helpers ===== */                                                              // HE: עזרי SPI
static void ST7735_WriteCommand(uint8_t cmd)                                                    // HE: שליחת פקודה
{
    ST7735_Select();                                                                            // HE: CS=0
    ST7735_DC_Command();                                                                        // HE: DC=0
    HAL_SPI_Transmit(&hspi2, &cmd, 1, HAL_MAX_DELAY);                                           // HE: שליחת 1 בייט
    ST7735_Unselect();                                                                          // HE: CS=1
}

static void ST7735_WriteData(uint8_t *data, uint16_t size)                                      // HE: שליחת דאטה
{
    ST7735_Select();                                                                            // HE: CS=0
    ST7735_DC_Data();                                                                           // HE: DC=1
    HAL_SPI_Transmit(&hspi2, data, size, HAL_MAX_DELAY);                                        // HE: שליחת באפר
    ST7735_Unselect();                                                                          // HE: CS=1
}

/* ===== Address window and pixel ===== */                                                      // HE: חלון כתיבה ופיקסל
/* File: st7735.c                                                                                 // HE: דרייבר ST7735
   Why: Add offsets and avoid sending RAMWR here, we start RAMWR in BeginRAMWrite.                // HE: offsets + מניעת כפילות RAMWR
*/

static void ST7735_SetAddressWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1)            // HE: חלון ציור
{
    uint8_t data[4];                                                                              // HE: 4 בייטים

    x0 = (uint16_t)(x0 + ST7735_XSTART);                                                          // HE: offset X start
    x1 = (uint16_t)(x1 + ST7735_XSTART);                                                          // HE: offset X end
    y0 = (uint16_t)(y0 + ST7735_YSTART);                                                          // HE: offset Y start
    y1 = (uint16_t)(y1 + ST7735_YSTART);                                                          // HE: offset Y end

    ST7735_WriteCommand(0x2A);                                                                    // HE: CASET
    data[0] = 0x00;                                                                               // HE: MSB start
    data[1] = (uint8_t)(x0 & 0xFF);                                                               // HE: LSB start
    data[2] = 0x00;                                                                               // HE: MSB end
    data[3] = (uint8_t)(x1 & 0xFF);                                                               // HE: LSB end
    ST7735_WriteData(data, 4);                                                                    // HE: שליחה

    ST7735_WriteCommand(0x2B);                                                                    // HE: RASET
    data[0] = 0x00;                                                                               // HE: MSB start
    data[1] = (uint8_t)(y0 & 0xFF);                                                               // HE: LSB start
    data[2] = 0x00;                                                                               // HE: MSB end
    data[3] = (uint8_t)(y1 & 0xFF);                                                               // HE: LSB end
    ST7735_WriteData(data, 4);                                                                    // HE: שליחה
}


/* File: st7735.c                                                                               // HE: דרייבר ST7735
   Why: Fix DrawPixel after removing RAMWR from SetAddressWindow.                                // HE: חייבים RAMWR לפני דאטה
*/

static void ST7735_DrawPixel(uint16_t x, uint16_t y, uint16_t color)                              // HE: ציור פיקסל
{
    if (x >= ST7735_WIDTH || y >= ST7735_HEIGHT)                                                  // HE: גבולות
    {
        return;                                                                                   // HE: יציאה
    }

    ST7735_SetAddressWindow(x, y, x, y);                                                          // HE: חלון פיקסל
    ST7735_BeginRAMWrite();                                                                       // HE: שולח RAMWR ומשאיר CS=0, DC=DATA

    uint8_t data[2];                                                                              // HE: RGB565
    data[0] = (uint8_t)(color >> 8);                                                              // HE: byte עליון
    data[1] = (uint8_t)(color & 0xFF);                                                            // HE: byte תחתון

    HAL_SPI_Transmit(&hspi2, data, 2, HAL_MAX_DELAY);                                             // HE: שליחת הפיקסל
    ST7735_Unselect();                                                                            // HE: CS=1
}

/* ===== Scaled font helpers ===== */                                                            // HE: פונקציות פונט מוגדל
static void ST7735_DrawPixelBlock(uint16_t x, uint16_t y, uint16_t color, uint8_t s)             // HE: בלוק sxs
{
    if (s == 0u) return;                                                                         // HE: הגנה
    for (uint8_t dy = 0; dy < s; dy++)                                                           // HE: גובה
    {
        for (uint8_t dx = 0; dx < s; dx++)                                                       // HE: רוחב
        {
            ST7735_DrawPixel((uint16_t)(x + dx), (uint16_t)(y + dy), color);                     // HE: פיקסל
        }
    }
}

static void ST7735_DrawLetterScaled(const Letter5x7 *letter, uint16_t x, uint16_t y,             // HE: ציור אות מוגדלת
                                    uint16_t fg, uint16_t bg, uint8_t scale)                    // HE: צבעים ו-scale
{
    if (scale == 0u) scale = 1u;                                                                 // HE: הגנה
    for (uint8_t row = 0; row < 7; row++)                                                        // HE: 7 שורות
    {
        uint8_t bits = letter->rows[row];                                                        // HE: ביטים
        for (uint8_t col = 0; col < 5; col++)                                                    // HE: 5 עמודות
        {
            uint16_t c = (bits & (1U << (4 - col))) ? fg : bg;                                   // HE: בחירת צבע
            ST7735_DrawPixelBlock((uint16_t)(x + (uint16_t)col * scale),
                                  (uint16_t)(y + (uint16_t)row * scale),
                                  c,
                                  scale);
        }
    }
}

static void ST7735_DrawChar5x7_Scaled(char c, uint16_t x, uint16_t y,                             // HE: תו מוגדל
                                     uint16_t fg, uint16_t bg, uint8_t scale)                   // HE: צבעים ו-scale
{
    if (c >= 'A' && c <= 'Z')                                                                    // HE: ל-lower
    {
        c = (char)(c + ('a' - 'A'));                                                             // HE: המרה
    }
    const Letter5x7 *letter = ST7735_GetLetter5x7(c);                                            // HE: ביטמאפ
    ST7735_DrawLetterScaled(letter, x, y, fg, bg, scale);                                        // HE: ציור
}

static void ST7735_DrawText5x7_Scaled(const char *text, uint16_t x, uint16_t y,                   // HE: מחרוזת מוגדלת
                                     uint16_t fg, uint16_t bg, uint8_t scale)                   // HE: צבעים ו-scale
{
    uint16_t cursor_x = x;                                                                        // HE: סמן
    uint16_t step = (uint16_t)(6u * (uint16_t)scale);                                            // HE: 5 + רווח

    while (*text != '\0')                                                                         // HE: עד סוף
    {
        ST7735_DrawChar5x7_Scaled(*text, cursor_x, y, fg, bg, scale);                            // HE: ציור תו
        cursor_x = (uint16_t)(cursor_x + step);                                                  // HE: תו הבא
        text++;                                                                                  // HE: תו הבא
    }
}

void ST7735_ShowSentenceCenterScaled(const char *text, uint8_t scale)                             // HE: מרכז עם scale
{
    char buffer[32];                                                                              // HE: באפר
    uint16_t maxChars = (uint16_t)(sizeof(buffer) - 1u);                                         // HE: מקס
    uint16_t len = (uint16_t)strlen(text);                                                       // HE: אורך

    if (len > maxChars) len = maxChars;                                                          // HE: חיתוך

    for (uint16_t i = 0; i < len; i++)                                                           // HE: העתקה
    {
        char c = text[i];                                                                        // HE: תו
        if (c >= 'A' && c <= 'Z') c = (char)(c + ('a' - 'A'));                                   // HE: ל-lower
        buffer[i] = c;                                                                           // HE: כתיבה
    }
    buffer[len] = '\0';                                                                          // HE: סיום

    if (scale == 0u) scale = 1u;                                                                 // HE: הגנה

    uint16_t textWidth  = (uint16_t)(len * (uint16_t)(6u * scale));                              // HE: רוחב
    uint16_t textHeight = (uint16_t)(7u * scale);                                                // HE: גובה

    uint16_t startX = 0u;                                                                        // HE: X
    if (textWidth < ST7735_WIDTH) startX = (uint16_t)((ST7735_WIDTH - textWidth) / 2u);          // HE: מרכז

    uint16_t startY = 0u;                                                                        // HE: Y
    if (textHeight < ST7735_HEIGHT) startY = (uint16_t)((ST7735_HEIGHT - textHeight) / 2u);      // HE: מרכז

    ST7735_FillScreen(ST7735_COLOR_BLACK);                                                       // HE: ניקוי
    ST7735_DrawText5x7_Scaled(buffer, startX, startY, ST7735_COLOR_WHITE, ST7735_COLOR_BLACK, scale); // HE: ציור
}

/* ===== Init ===== */                                                                           // HE: אתחול מסך
void ST7735_Init(void)                                                                           // HE: אתחול
{

	ST7735_FillScreen(ST7735_COLOR_BLACK);

    ST7735_Unselect();                                                                           // HE: CS=1
    ST7735_BacklightOn();                                                                        // HE: תאורה
    ST7735_Reset();                                                                              // HE: Reset

    ST7735_WriteCommand(0x11);                                                                   // HE: Sleep Out
    HAL_Delay(120);                                                                              // HE: השהייה

    uint8_t data1[] = {0x01, 0x2C, 0x2D};                                                        // HE: FRMCTR1
    uint8_t data2[] = {0x01, 0x2C, 0x2D};                                                        // HE: FRMCTR2
    uint8_t data3[] = {0x01, 0x2C, 0x2D, 0x01, 0x2C, 0x2D};                                      // HE: FRMCTR3

    ST7735_WriteCommand(0xB1); ST7735_WriteData(data1, (uint16_t)sizeof(data1));                 // HE: FRMCTR1
    ST7735_WriteCommand(0xB2); ST7735_WriteData(data2, (uint16_t)sizeof(data2));                 // HE: FRMCTR2
    ST7735_WriteCommand(0xB3); ST7735_WriteData(data3, (uint16_t)sizeof(data3));                 // HE: FRMCTR3

    uint8_t data_inv[] = {0x07};                                                                 // HE: INVCTR
    ST7735_WriteCommand(0xB4); ST7735_WriteData(data_inv, (uint16_t)sizeof(data_inv));           // HE: INVCTR

    uint8_t data_c0[] = {0xA2, 0x02, 0x84};                                                      // HE: PWCTR1
    ST7735_WriteCommand(0xC0); ST7735_WriteData(data_c0, (uint16_t)sizeof(data_c0));             // HE: PWCTR1

    uint8_t data_c1[] = {0xC5};                                                                  // HE: PWCTR2
    ST7735_WriteCommand(0xC1); ST7735_WriteData(data_c1, (uint16_t)sizeof(data_c1));             // HE: PWCTR2

    uint8_t data_c2[] = {0x0A, 0x00};                                                            // HE: PWCTR3
    ST7735_WriteCommand(0xC2); ST7735_WriteData(data_c2, (uint16_t)sizeof(data_c2));             // HE: PWCTR3

    uint8_t data_c3[] = {0x8A, 0x2A};                                                            // HE: PWCTR4
    ST7735_WriteCommand(0xC3); ST7735_WriteData(data_c3, (uint16_t)sizeof(data_c3));             // HE: PWCTR4

    uint8_t data_c4[] = {0x8A, 0xEE};                                                            // HE: PWCTR5
    ST7735_WriteCommand(0xC4); ST7735_WriteData(data_c4, (uint16_t)sizeof(data_c4));             // HE: PWCTR5

    uint8_t data_vcom[] = {0x0E};                                                                // HE: VMCTR1
    ST7735_WriteCommand(0xC5); ST7735_WriteData(data_vcom, (uint16_t)sizeof(data_vcom));         // HE: VMCTR1

    ST7735_SetRotation(3);                                                                       // HE: 270 מעלות

    uint8_t data_colmod[] = {0x05};                                                              // HE: 16-bit color
    ST7735_WriteCommand(0x3A); ST7735_WriteData(data_colmod, (uint16_t)sizeof(data_colmod));     // HE: COLMOD

    ST7735_WriteCommand(0x13);                                                                   // HE: NORON
    HAL_Delay(10);                                                                               // HE: השהייה

    ST7735_WriteCommand(0x29);                                                                   // HE: DISPON
    HAL_Delay(100);                                                                              // HE: השהייה
}




/* File: st7735.c                                                                                 // HE: דרייבר ST7735
   Why: Fast rectangle fill using burst writes, avoids per-pixel HAL_SPI_Transmit calls.          // HE: מילוי מהיר כדי לא לחסום אודיו
*/

void ST7735_FillRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color)               // HE: מילוי מלבן
{
    if (w == 0u || h == 0u) return;                                                                // HE: הגנה
    if (x >= ST7735_WIDTH || y >= ST7735_HEIGHT) return;                                           // HE: מחוץ למסך

    if ((uint16_t)(x + w) > ST7735_WIDTH)  w = (uint16_t)(ST7735_WIDTH  - x);                      // HE: חיתוך רוחב
    if ((uint16_t)(y + h) > ST7735_HEIGHT) h = (uint16_t)(ST7735_HEIGHT - y);                      // HE: חיתוך גובה

    uint8_t hi = (uint8_t)(color >> 8);                                                            // HE: byte עליון
    uint8_t lo = (uint8_t)(color & 0xFF);                                                          // HE: byte תחתון

    ST7735_SetAddressWindow(x, y, (uint16_t)(x + w - 1u), (uint16_t)(y + h - 1u));                  // HE: חלון
    ST7735_BeginRAMWrite();                                                                         // HE: RAMWR + DC=DATA + CS=0

    /* באפר קטן לבורסט, 64 פיקסלים בכל שליחה = 128 בייט */
    uint8_t buf[128];                                                                              // HE: באפר שידור
    for (uint32_t i = 0; i < 64u; i++)                                                             // HE: מילוי באפר
    {
        buf[2u*i + 0u] = hi;                                                                       // HE: hi
        buf[2u*i + 1u] = lo;                                                                       // HE: lo
    }

    uint32_t total = (uint32_t)w * (uint32_t)h;                                                    // HE: כמה פיקסלים
    while (total > 0u)                                                                             // HE: כל עוד נשאר
    {
        uint32_t chunk = (total > 64u) ? 64u : total;                                              // HE: גודל בורסט
        HAL_SPI_Transmit(&hspi2, buf, (uint16_t)(chunk * 2u), HAL_MAX_DELAY);                      // HE: שליחת בורסט
        total -= chunk;                                                                            // HE: הפחתה
    }

    ST7735_Unselect();                                                                             // HE: CS=1 בסיום
}



/* File: st7735.c
   Why: Draw scaled text at a given position without clearing the whole screen
*/
void ST7735_ShowTextScaled_At(const char *text, uint16_t x, uint16_t y, uint8_t scale) // HE: ציור טקסט במיקום בלי ניקוי מסך
{
    char buffer[32];                                                                   // HE: באפר
    uint16_t maxChars = (uint16_t)(sizeof(buffer) - 1u);                               // HE: מקס
    uint16_t len = (uint16_t)strlen(text);                                             // HE: אורך
    if (len > maxChars) len = maxChars;                                                // HE: חיתוך

    for (uint16_t i = 0; i < len; i++)                                                 // HE: העתקה
    {
        char c = text[i];                                                              // HE: תו
        if (c >= 'A' && c <= 'Z') c = (char)(c + ('a' - 'A'));                         // HE: lower
        buffer[i] = c;                                                                 // HE: כתיבה
    }
    buffer[len] = '\0';                                                                // HE: סיום

    if (scale == 0u) scale = 1u;                                                       // HE: הגנה

    ST7735_DrawText5x7_Scaled(buffer, x, y, ST7735_COLOR_WHITE, ST7735_COLOR_BLACK, scale); // HE: ציור בלבד
}

/* ===== Fill screen ===== */                                                                    // HE: מילוי מסך
/* File: st7735.c                                                                                 // HE: דרייבר ST7735
   Why: Implement FillScreen via FillRect fast path.                                               // HE: מסך מלא מהר
*/

void ST7735_FillScreen(uint16_t color)                                                             // HE: מילוי מסך
{
    ST7735_FillRect(0u, 0u, ST7735_WIDTH, ST7735_HEIGHT, color);                                   // HE: שימוש במילוי מלבן מהיר
}


/* ===== Font bitmaps ===== */                                                                   // HE: פונט 5x7
static const Letter5x7 LETTER_a = {{0x0E, 0x01, 0x0F, 0x11, 0x0F, 0x00, 0x00}};
static const Letter5x7 LETTER_b = {{0x10, 0x10, 0x1E, 0x11, 0x1E, 0x00, 0x00}};
static const Letter5x7 LETTER_c = {{0x0E, 0x11, 0x10, 0x10, 0x0E, 0x00, 0x00}};
static const Letter5x7 LETTER_d = {{0x01, 0x01, 0x0F, 0x11, 0x0F, 0x00, 0x00}};
static const Letter5x7 LETTER_e = {{0x0E, 0x11, 0x1F, 0x10, 0x0E, 0x00, 0x00}};
static const Letter5x7 LETTER_f = {{0x07, 0x08, 0x1E, 0x08, 0x08, 0x00, 0x00}};
static const Letter5x7 LETTER_g = {{0x0F, 0x11, 0x11, 0x0F, 0x01, 0x0E, 0x00}};
static const Letter5x7 LETTER_h = {{0x10, 0x10, 0x1E, 0x11, 0x11, 0x11, 0x00}};
static const Letter5x7 LETTER_i = {{0x04, 0x00, 0x0C, 0x04, 0x0E, 0x00, 0x00}};
static const Letter5x7 LETTER_j = {{0x02, 0x00, 0x06, 0x02, 0x12, 0x0C, 0x00}};
static const Letter5x7 LETTER_k = {{0x10, 0x10, 0x14, 0x18, 0x14, 0x00, 0x00}};
static const Letter5x7 LETTER_l = {{0x0C, 0x04, 0x04, 0x04, 0x0E, 0x00, 0x00}};
static const Letter5x7 LETTER_m = {{0x00, 0x00, 0x1A, 0x15, 0x15, 0x00, 0x00}};
static const Letter5x7 LETTER_n = {{0x00, 0x00, 0x1E, 0x11, 0x11, 0x00, 0x00}};
static const Letter5x7 LETTER_o = {{0x00, 0x00, 0x0E, 0x11, 0x0E, 0x00, 0x00}};
static const Letter5x7 LETTER_p = {{0x00, 0x00, 0x1E, 0x11, 0x1E, 0x10, 0x10}};
static const Letter5x7 LETTER_q = {{0x00, 0x00, 0x0F, 0x11, 0x0F, 0x01, 0x01}};
static const Letter5x7 LETTER_r = {{0x00, 0x1E, 0x11, 0x10, 0x10, 0x00, 0x00}};
static const Letter5x7 LETTER_s = {{0x00, 0x00, 0x0F, 0x10, 0x1E, 0x00, 0x00}};
static const Letter5x7 LETTER_t = {{0x08, 0x08, 0x1E, 0x08, 0x06, 0x00, 0x00}};
static const Letter5x7 LETTER_u = {{0x00, 0x00, 0x11, 0x11, 0x0F, 0x00, 0x00}};
static const Letter5x7 LETTER_v = {{0x00, 0x00, 0x11, 0x0A, 0x04, 0x00, 0x00}};
static const Letter5x7 LETTER_w = {{0x00, 0x00, 0x11, 0x15, 0x0A, 0x00, 0x00}};
static const Letter5x7 LETTER_x = {{0x00, 0x00, 0x11, 0x0A, 0x11, 0x00, 0x00}};
static const Letter5x7 LETTER_y = {{0x00, 0x00, 0x11, 0x11, 0x0F, 0x01, 0x0E}};
static const Letter5x7 LETTER_z = {{0x00, 0x00, 0x1F, 0x02, 0x1F, 0x00, 0x00}};
static const Letter5x7 LETTER_space = {{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}};

static const Letter5x7* ST7735_GetLetter5x7(char c)                                              // HE: מיפוי תו
{
    switch (c)
    {
        case 'a': return &LETTER_a; case 'b': return &LETTER_b; case 'c': return &LETTER_c;
        case 'd': return &LETTER_d; case 'e': return &LETTER_e; case 'f': return &LETTER_f;
        case 'g': return &LETTER_g; case 'h': return &LETTER_h; case 'i': return &LETTER_i;
        case 'j': return &LETTER_j; case 'k': return &LETTER_k; case 'l': return &LETTER_l;
        case 'm': return &LETTER_m; case 'n': return &LETTER_n; case 'o': return &LETTER_o;
        case 'p': return &LETTER_p; case 'q': return &LETTER_q; case 'r': return &LETTER_r;
        case 's': return &LETTER_s; case 't': return &LETTER_t; case 'u': return &LETTER_u;
        case 'v': return &LETTER_v; case 'w': return &LETTER_w; case 'x': return &LETTER_x;
        case 'y': return &LETTER_y; case 'z': return &LETTER_z;
        case ' ': return &LETTER_space;
        default:  return &LETTER_space;
    }
}

/* ===== Public simple text APIs (your originals can stay) ===== */                               // HE: API טקסט פשוט
void ST7735_ShowSentenceCenter(const char *text)                                                  // HE: מרכז ללא scale
{
    ST7735_ShowSentenceCenterScaled(text, 1u);                                                    // HE: reuse
}

/* ===== Begin RAM write ===== */                                                                 // HE: התחלת RAMWR
static void ST7735_BeginRAMWrite(void)
{
    ST7735_Select();                                                                              // HE: CS=0
    ST7735_DC_Command();                                                                          // HE: DC=0
    uint8_t cmd = 0x2C;                                                                           // HE: RAMWR
    HAL_SPI_Transmit(&hspi2, &cmd, 1, HAL_MAX_DELAY);                                             // HE: פקודה
    ST7735_DC_Data();                                                                             // HE: DC=1
}
