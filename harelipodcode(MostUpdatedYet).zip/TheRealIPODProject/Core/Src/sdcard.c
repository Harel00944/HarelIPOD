/* File: Core/Src/sdcard.c                                                                                   // HE: קוד SD Card + FatFs test כולל debug ו-mkfs
   Why: לזהות למה f_mount נכשל, ואם אין מערכת קבצים לבצע f_mkfs ואז mount מחדש                             // HE: למה הקובץ קיים
*/

#include "sdcard.h"                                                                                           // HE: כותרת SDCard
#include "main.h"                                                                                             // HE: hsd, GPIO
#include "fatfs.h"                                                                                            // HE: MX_FATFS_Init, SDFatFS, SDPath
#include "ff.h"                                                                                               // HE: FatFs API: f_mount, f_mkfs, f_open
#include <string.h>                                                                                            // HE: memset, memcmp, strlen, strstr
#include <stdio.h>                                                                                             // HE: snprintf

/* ===== External objects (CubeMX / FatFs) ===== */                                                           // HE: אובייקטים חיצוניים
extern FATFS SDFatFS;                                                                                          // HE: מוגדר ב-FATFS/App/fatfs.c
extern char SDPath[4];                                                                                         // HE: מוגדר ב-FATFS/App/fatfs.c
extern SD_HandleTypeDef hsd;                                                                                   // HE: ידית SDIO

/* אם יש לך פונקציית הדפסה ל-USB APP, נשתמש בה */                                                             // HE: הדפסה לטרמינל
extern void APP_Tx(const char *s);                                                                              // HE: שליחה ל-USB CDC

#ifndef SD_TIMEOUT                                                                                              // HE: timeout
#define SD_TIMEOUT (30u * 1000u)                                                                                // HE: 30 שניות
#endif                                                                                                          // HE: סוף ifndef

__ALIGN_BEGIN static uint8_t s_tx[512] __ALIGN_END;                                                             // HE: בלוק שידור RAW
__ALIGN_BEGIN static uint8_t s_rx[512] __ALIGN_END;                                                             // HE: בלוק קליטה RAW

__ALIGN_BEGIN static uint8_t s_mkfs_work[4096] __ALIGN_END;                                                     // HE: work buffer ל-f_mkfs (מינימום כמה KB)

static HAL_StatusTypeDef SD_WaitTransfer(SD_HandleTypeDef *phsd, uint32_t timeout_ms);                          // HE: המתנה למצב TRANSFER
static uint32_t SD_LbaToAddr(uint32_t lba);                                                                      // HE: LBA->addr
static void fill_test_pattern(uint8_t *buf, uint8_t seed);                                                      // HE: דפוס בדיקה
static bool raw_rw_compare_test(uint32_t test_block);                                                           // HE: RAW test
static bool fatfs_file_test(void);                                                                               // HE: File test

static void SD_PrintFr(const char *prefix, FRESULT fr)                                                          // HE: הדפסת קוד FRESULT
{
  char msg[96];                                                                                                  // HE: באפר הודעה
  snprintf(msg, sizeof(msg), "%s%d\r\n", prefix, (int)fr);                                                       // HE: פורמט
  APP_Tx(msg);                                                                                                   // HE: שליחה ל-USB
}

bool SDCard_IsInserted(void)                                                                                    // HE: בדיקת CD
{
  GPIO_PinState st = HAL_GPIO_ReadPin(SD_CARD_CD1_GPIO_INPUT_GPIO_Port, SD_CARD_CD1_GPIO_INPUT_Pin);            // HE: קריאת פין CD
  return (st == GPIO_PIN_RESET);                                                                                // HE: CD אקטיבי נמוך
}

HAL_StatusTypeDef SDCard_Init(void)                                                                             // HE: Init SDIO
{
  if (!SDCard_IsInserted())                                                                                     // HE: אם אין כרטיס
  {
    APP_Tx("[SD] No card (CD=HIGH)\r\n");                                                                        // HE: הדפסה
    return HAL_ERROR;                                                                                            // HE: כשל
  }

  (void)HAL_SD_DeInit(&hsd);                                                                                    // HE: ניקוי
  HAL_Delay(5);                                                                                                 // HE: השהייה

  if (HAL_SD_Init(&hsd) != HAL_OK)                                                                              // HE: Init
  {
    APP_Tx("[SD] HAL_SD_Init FAILED\r\n");                                                                       // HE: הדפסה
    return HAL_ERROR;                                                                                            // HE: כשל
  }

  (void)HAL_SD_ConfigWideBusOperation(&hsd, SDIO_BUS_WIDE_4B);                                                   // HE: 4-bit

  if (SD_WaitTransfer(&hsd, SD_TIMEOUT) != HAL_OK)                                                              // HE: לוודא TRANSFER
  {
    APP_Tx("[SD] Wait TRANSFER TIMEOUT\r\n");                                                                    // HE: הדפסה
    return HAL_TIMEOUT;                                                                                          // HE: timeout
  }

  return HAL_OK;                                                                                                 // HE: הצלחה
}

FRESULT SDCard_Mount(void)                                                                                      // HE: Mount ל-FatFs
{
  static uint8_t fatfs_inited = 0;                                                                               // HE: init פעם אחת

  if (!SDCard_IsInserted())                                                                                     // HE: אין כרטיס
  {
    return FR_NOT_READY;                                                                                         // HE: לא מוכן
  }

  if (!fatfs_inited)                                                                                             // HE: init פעם ראשונה
  {
    MX_FATFS_Init();                                                                                             // HE: LinkDriver ל-"0:"
    fatfs_inited = 1;                                                                                            // HE: סימון
  }

  return f_mount(&SDFatFS, "0:", 1);                                                                             // HE: mount מיידי
}

FRESULT SDCard_Unmount(void)                                                                                    // HE: Unmount
{
  return f_mount(NULL, "0:", 1);                                                                                 // HE: unmount
}

/* File: Core/Src/sdcard.c                                                                                   // HE: mkfs לפי חתימת FatFs הישנה
   Why: בפרויקט הזה f_mkfs מקבלת BYTE opt ו-DWORD au, אין MKFS_PARM                                            // HE: למה הקובץ קיים
*/

static bool SDCard_TryMkfsAndMount(void)                                                                       // HE: ניסיון mkfs ואז mount
{
  FRESULT fr;                                                                                                  // HE: תוצאה

  APP_Tx("[SD] Trying f_mkfs (legacy API)...\r\n");                                                             // HE: הדפסה

  BYTE opt = FM_FAT32;                                                                                          // HE: FAT32 (חייב להיכלל ב-ffconf עם _USE_MKFS=1)
  DWORD au = 0;                                                                                                 // HE: cluster auto

  fr = f_mkfs("0:", opt, au, s_mkfs_work, (UINT)sizeof(s_mkfs_work));                                           // HE: פורמט כונן 0:
  SD_PrintFr("[SD] f_mkfs result=", fr);                                                                        // HE: הדפסה

  if (fr != FR_OK)                                                                                              // HE: אם נכשל
  {
    return false;                                                                                               // HE: כשל
  }

  (void)SDCard_Unmount();                                                                                       // HE: unmount כדי לרענן
  fr = SDCard_Mount();                                                                                          // HE: mount מחדש
  SD_PrintFr("[SD] f_mount after mkfs result=", fr);                                                            // HE: הדפסה

  return (fr == FR_OK);                                                                                         // HE: הצלחה
}


bool SDCard_Test_All(void)                                                                                        // HE: RAW + FatFs test עם mkfs
{
  APP_Tx("[SD] Card Detect test\r\n");                                                                             // HE: הדפסה

  if (!SDCard_IsInserted())                                                                                        // HE: אין כרטיס
  {
    APP_Tx("[SD] Card NOT detected (CD=HIGH)\r\n");                                                                // HE: הדפסה
    return false;                                                                                                  // HE: כשל
  }

  APP_Tx("[SD] Card detected (CD=LOW)\r\n");                                                                       // HE: הדפסה

  if (SDCard_Init() != HAL_OK)                                                                                     // HE: init
  {
    APP_Tx("[SD] SDCard_Init FAILED\r\n");                                                                         // HE: הדפסה
    return false;                                                                                                  // HE: כשל
  }

  HAL_SD_CardInfoTypeDef info;                                                                                     // HE: מידע
  if (HAL_SD_GetCardInfo(&hsd, &info) != HAL_OK)                                                                   // HE: קריאת מידע
  {
    APP_Tx("[SD] HAL_SD_GetCardInfo FAILED\r\n");                                                                   // HE: הדפסה
    return false;                                                                                                  // HE: כשל
  }

  {                                                                                                                // HE: בלוק הדפסה
    char msg[96];                                                                                                  // HE: באפר
    snprintf(msg, sizeof(msg), "[SD] RCA=0x%04lX, BlockNbr=%lu, BlockSize=%lu\r\n",                                // HE: פורמט
             (unsigned long)hsd.SdCard.RelCardAdd,                                                                  // HE: RCA
             (unsigned long)info.LogBlockNbr,                                                                      // HE: מספר בלוקים
             (unsigned long)info.LogBlockSize);                                                                    // HE: גודל בלוק
    APP_Tx(msg);                                                                                                   // HE: הדפסה
  }

  uint32_t safe_block = 8192u;                                                                                     // HE: בלוק בדיקה
  if (info.LogBlockNbr <= (safe_block + 2u))                                                                       // HE: הגנה
  {
    APP_Tx("[SD] Card too small for safe RAW test\r\n");                                                           // HE: הדפסה
    return false;                                                                                                  // HE: כשל
  }

  APP_Tx("[SD] RAW R/W test...\r\n");                                                                               // HE: הדפסה
  if (!raw_rw_compare_test(safe_block))                                                                            // HE: RAW test
  {
    APP_Tx("[SD] RAW test FAILED\r\n");                                                                             // HE: הדפסה
    return false;                                                                                                  // HE: כשל
  }
  APP_Tx("[SD] RAW test OK\r\n");                                                                                   // HE: הדפסה

  APP_Tx("[SD] FatFs test...\r\n");                                                                                 // HE: הדפסה
  FRESULT fr = SDCard_Mount();                                                                                      // HE: mount
  if (fr != FR_OK)                                                                                                  // HE: אם נכשל
  {
    SD_PrintFr("[SD] f_mount result=", fr);                                                                          // HE: הדפסה

    if (fr == FR_NO_FILESYSTEM)                                                                                      // HE: אין מערכת קבצים
    {
      APP_Tx("[SD] No filesystem, will mkfs FAT32\r\n");                                                             // HE: הדפסה
      if (!SDCard_TryMkfsAndMount())                                                                                  // HE: mkfs + mount
      {
        APP_Tx("[SD] mkfs/mount FAILED\r\n");                                                                         // HE: הדפסה
        return false;                                                                                                  // HE: כשל
      }
    }
    else
    {
      APP_Tx("[SD] mount FAILED (not NO_FILESYSTEM)\r\n");                                                           // HE: הדפסה
      return false;                                                                                                  // HE: כשל
    }
  }

  bool ok = fatfs_file_test();                                                                                       // HE: בדיקת קובץ
  (void)SDCard_Unmount();                                                                                            // HE: unmount

  if (!ok)                                                                                                           // HE: אם נכשל
  {
    APP_Tx("[SD] FatFs file test FAILED\r\n");                                                                        // HE: הדפסה
    return false;                                                                                                    // HE: כשל
  }

  APP_Tx("[SD] FatFs file test OK\r\n");                                                                              // HE: הדפסה
  return true;                                                                                                       // HE: הצלחה
}

/* ===== Local helpers ===== */

static HAL_StatusTypeDef SD_WaitTransfer(SD_HandleTypeDef *phsd, uint32_t timeout_ms)                              // HE: המתנה ל-TRANSFER
{
  uint32_t t0 = HAL_GetTick();                                                                                      // HE: זמן התחלה
  while ((HAL_GetTick() - t0) < timeout_ms)                                                                         // HE: עד timeout
  {
    if (HAL_SD_GetCardState(phsd) == HAL_SD_CARD_TRANSFER)                                                          // HE: מוכן
    {
      return HAL_OK;                                                                                                // HE: הצלחה
    }
    HAL_Delay(1);                                                                                                   // HE: השהייה
  }
  return HAL_TIMEOUT;                                                                                               // HE: timeout
}

static uint32_t SD_LbaToAddr(uint32_t lba)                                                                           // HE: LBA->addr
{
  if (hsd.SdCard.CardType == CARD_SDSC)                                                                              // HE: SDSC
  {
    return lba * 512u;                                                                                               // HE: בייטים
  }
  return lba;                                                                                                        // HE: בלוקים
}

static void fill_test_pattern(uint8_t *buf, uint8_t seed)                                                            // HE: דפוס
{
  for (uint32_t i = 0; i < 512u; i++)                                                                                // HE: לולאה
  {
    buf[i] = (uint8_t)(seed + (uint8_t)i);                                                                           // HE: דפוס עולה
  }
}

static bool raw_rw_compare_test(uint32_t test_block)                                                                 // HE: RAW R/W
{
  fill_test_pattern(s_tx, 0x3Au);                                                                                    // HE: דפוס
  memset(s_rx, 0, sizeof(s_rx));                                                                                     // HE: איפוס

  uint32_t addr = SD_LbaToAddr(test_block);                                                                           // HE: כתובת

  if (HAL_SD_WriteBlocks(&hsd, s_tx, addr, 1u, 5000u) != HAL_OK)                                                     // HE: כתיבה
  {
    return false;                                                                                                    // HE: כשל
  }
  if (SD_WaitTransfer(&hsd, 5000u) != HAL_OK)                                                                        // HE: המתנה
  {
    return false;                                                                                                    // HE: כשל
  }

  if (HAL_SD_ReadBlocks(&hsd, s_rx, addr, 1u, 5000u) != HAL_OK)                                                      // HE: קריאה
  {
    return false;                                                                                                    // HE: כשל
  }
  if (SD_WaitTransfer(&hsd, 5000u) != HAL_OK)                                                                        // HE: המתנה
  {
    return false;                                                                                                    // HE: כשל
  }

  if (memcmp(s_tx, s_rx, 512u) != 0)                                                                                 // HE: השוואה
  {
    return false;                                                                                                    // HE: mismatch
  }
  return true;                                                                                                       // HE: עבר
}

static bool fatfs_file_test(void)                                                                                    // HE: בדיקת קובץ
{
  FRESULT fr;                                                                                                        // HE: תוצאה
  FIL fil;                                                                                                           // HE: קובץ
  UINT bw = 0;                                                                                                       // HE: bytes written
  UINT br = 0;                                                                                                       // HE: bytes read

  const char *fname = "0:sd_test.txt";                                                                               // HE: שם קובץ

  fr = f_open(&fil, fname, FA_CREATE_ALWAYS | FA_WRITE);                                                             // HE: פתיחה לכתיבה
  if (fr != FR_OK)                                                                                                   // HE: בדיקה
  {
    SD_PrintFr("[SD] f_open(W) fr=", fr);                                                                             // HE: הדפסה
    return false;                                                                                                    // HE: כשל
  }

  const char *msg = "SDCARD OK\r\n";                                                                                 // HE: תוכן
  fr = f_write(&fil, msg, (UINT)strlen(msg), &bw);                                                                   // HE: כתיבה
  (void)f_close(&fil);                                                                                               // HE: סגירה

  if (fr != FR_OK || bw != (UINT)strlen(msg))                                                                        // HE: בדיקה
  {
    SD_PrintFr("[SD] f_write fr=", fr);                                                                               // HE: הדפסה
    return false;                                                                                                    // HE: כשל
  }

  memset(s_rx, 0, sizeof(s_rx));                                                                                     // HE: איפוס
  fr = f_open(&fil, fname, FA_READ);                                                                                 // HE: פתיחה לקריאה
  if (fr != FR_OK)                                                                                                   // HE: בדיקה
  {
    SD_PrintFr("[SD] f_open(R) fr=", fr);                                                                             // HE: הדפסה
    return false;                                                                                                    // HE: כשל
  }

  fr = f_read(&fil, s_rx, 512u, &br);                                                                                // HE: קריאה
  (void)f_close(&fil);                                                                                               // HE: סגירה

  if (fr != FR_OK || br == 0u)                                                                                       // HE: בדיקה
  {
    SD_PrintFr("[SD] f_read fr=", fr);                                                                                // HE: הדפסה
    return false;                                                                                                    // HE: כשל
  }

  if (strstr((char*)s_rx, "SDCARD OK") == NULL)                                                                      // HE: בדיקת תוכן
  {
    return false;                                                                                                    // HE: כשל
  }

  return true;                                                                                                       // HE: עבר
}
