/* File: vs1053.c
   Why: VS1053 driver, FIX: force safe slow SPI during SCI/SDI accesses to get clean sine on option 9.
*/

#include "vs1053.h"
#include <string.h>

/* -------- VS1053 SCI registers -------- */
#define VS1053_REG_MODE            0x00u
#define VS1053_REG_STATUS          0x01u
#define VS1053_REG_BASS            0x02u
#define VS1053_REG_CLOCKF          0x03u
#define VS1053_REG_DECODE_TIME     0x04u
#define VS1053_REG_AUDATA          0x05u
#define VS1053_REG_WRAM            0x06u
#define VS1053_REG_WRAMADDR        0x07u
#define VS1053_REG_HDAT0           0x08u
#define VS1053_REG_HDAT1           0x09u
#define VS1053_REG_AIADDR          0x0Au
#define VS1053_REG_VOL             0x0Bu

/* -------- SCI opcodes -------- */
#define VS1053_SCI_READ            0x03u
#define VS1053_SCI_WRITE           0x02u

/* -------- SCI_MODE bits -------- */
#define VS1053_SM_SDINEW           (1u << 11)
#define VS1053_SM_RESET            (1u << 2)
#define VS1053_SM_TESTS            (1u << 5)

/* -------- Timing -------- */
#define VS1053_DREQ_TIMEOUT_MS     200u
#define VS1053_SPI_TIMEOUT_MS      50u
#define VS1053_RESET_HOLD_MS       5u
#define VS1053_RESET_RELEASE_MS    20u
#define VS1053_SCI_GAP_US          2u

/* FIX: force safe SPI speed for VS1053 (prevents noisy sine due to too-fast SCI/SDI) */
#define VS1053_SPI_SAFE_PRESCALER  SPI_BAUDRATEPRESCALER_256

static VS1053_Handle_t *g_dev = NULL;
static uint32_t g_spi_saved_prescaler = 0u;
static uint8_t  g_spi_prescaler_saved = 0u;

/* ---------- Local helpers ---------- */
static inline void PIN_HIGH(GPIO_TypeDef *p, uint16_t pin)
{
    HAL_GPIO_WritePin(p, pin, GPIO_PIN_SET);
}

static inline void PIN_LOW(GPIO_TypeDef *p, uint16_t pin)
{
    HAL_GPIO_WritePin(p, pin, GPIO_PIN_RESET);
}

static inline void VS1053_DelayGap(void)
{
    for (volatile uint32_t i = 0; i < (uint32_t)(VS1053_SCI_GAP_US * 30u); i++) { __NOP(); }
}

static VS1053_Status_t VS1053_WaitDREQ(uint32_t timeout_ms)
{
    if (!g_dev) return VS1053_ERR;
    uint32_t t0 = HAL_GetTick();
    while (HAL_GPIO_ReadPin(g_dev->dreq_port, g_dev->dreq_pin) == GPIO_PIN_RESET)
    {
        if ((HAL_GetTick() - t0) > timeout_ms)
        {
            return VS1053_TIMEOUT;
        }
    }
    return VS1053_OK;
}

/* FIX: temporarily slow down SPI for VS1053 transactions */
static VS1053_Status_t VS1053_SPI_EnterSafeSpeed(void)
{
    if (!g_dev || !g_dev->hspi) return VS1053_ERR;

    if (!g_spi_prescaler_saved)
    {
        g_spi_saved_prescaler = (uint32_t)g_dev->hspi->Init.BaudRatePrescaler;
        g_spi_prescaler_saved = 1u;
    }

    if (g_dev->hspi->Init.BaudRatePrescaler != VS1053_SPI_SAFE_PRESCALER)
    {
        (void)HAL_SPI_DeInit(g_dev->hspi);
        g_dev->hspi->Init.BaudRatePrescaler = VS1053_SPI_SAFE_PRESCALER;
        if (HAL_SPI_Init(g_dev->hspi) != HAL_OK) return VS1053_ERR;
    }

    return VS1053_OK;
}

static VS1053_Status_t VS1053_SPI_ExitSafeSpeed(void)
{
    if (!g_dev || !g_dev->hspi) return VS1053_ERR;
    if (!g_spi_prescaler_saved) return VS1053_OK;

    if (g_dev->hspi->Init.BaudRatePrescaler != g_spi_saved_prescaler)
    {
        (void)HAL_SPI_DeInit(g_dev->hspi);
        g_dev->hspi->Init.BaudRatePrescaler = (uint32_t)g_spi_saved_prescaler;
        if (HAL_SPI_Init(g_dev->hspi) != HAL_OK) return VS1053_ERR;
    }

    return VS1053_OK;
}

static VS1053_Status_t SPI_TxRx(const uint8_t *tx, uint8_t *rx, uint16_t n)
{
    if (!g_dev || !g_dev->hspi) return VS1053_ERR;

    if (VS1053_SPI_EnterSafeSpeed() != VS1053_OK) return VS1053_ERR;

    if (HAL_SPI_TransmitReceive(g_dev->hspi, (uint8_t*)tx, rx, n, VS1053_SPI_TIMEOUT_MS) != HAL_OK)
    {
        (void)VS1053_SPI_ExitSafeSpeed();
        return VS1053_ERR;
    }

    (void)VS1053_SPI_ExitSafeSpeed();
    return VS1053_OK;
}

static VS1053_Status_t SPI_Tx(const uint8_t *tx, uint16_t n)
{
    if (!g_dev || !g_dev->hspi) return VS1053_ERR;

    if (VS1053_SPI_EnterSafeSpeed() != VS1053_OK) return VS1053_ERR;

    if (HAL_SPI_Transmit(g_dev->hspi, (uint8_t*)tx, n, VS1053_SPI_TIMEOUT_MS) != HAL_OK)
    {
        (void)VS1053_SPI_ExitSafeSpeed();
        return VS1053_ERR;
    }

    (void)VS1053_SPI_ExitSafeSpeed();
    return VS1053_OK;
}

/* ---------- Public API ---------- */
void VS1053_Attach(VS1053_Handle_t *dev)
{
    g_dev = dev;
    g_spi_saved_prescaler = 0u;
    g_spi_prescaler_saved = 0u;
}

VS1053_Status_t VS1053_ResetHard(void)
{
    if (!g_dev || !g_dev->hspi) return VS1053_ERR;

    PIN_HIGH(g_dev->xcs_port, g_dev->xcs_pin);
    PIN_HIGH(g_dev->xdcs_port, g_dev->xdcs_pin);
    VS1053_DelayGap();

    PIN_LOW(g_dev->rst_port, g_dev->rst_pin);
    HAL_Delay(VS1053_RESET_HOLD_MS);
    PIN_HIGH(g_dev->rst_port, g_dev->rst_pin);
    HAL_Delay(VS1053_RESET_RELEASE_MS);

    return VS1053_WaitDREQ(VS1053_DREQ_TIMEOUT_MS);
}

uint16_t VS1053_SCI_Read(uint8_t addr)
{
    uint8_t tx[4];
    uint8_t rx[4];
    uint16_t out = 0;

    if (!g_dev) return 0;

    if (VS1053_WaitDREQ(VS1053_DREQ_TIMEOUT_MS) != VS1053_OK)
    {
        return 0;
    }

    tx[0] = VS1053_SCI_READ;
    tx[1] = addr;
    tx[2] = 0xFFu;
    tx[3] = 0xFFu;

    PIN_LOW(g_dev->xcs_port, g_dev->xcs_pin);
    if (SPI_TxRx(tx, rx, 4) != VS1053_OK)
    {
        PIN_HIGH(g_dev->xcs_port, g_dev->xcs_pin);
        return 0;
    }
    PIN_HIGH(g_dev->xcs_port, g_dev->xcs_pin);
    VS1053_DelayGap();

    out = ((uint16_t)rx[2] << 8) | (uint16_t)rx[3];
    return out;
}

VS1053_Status_t VS1053_SCI_Write(uint8_t addr, uint16_t value)
{
    uint8_t tx[4];

    if (!g_dev) return VS1053_ERR;

    if (VS1053_WaitDREQ(VS1053_DREQ_TIMEOUT_MS) != VS1053_OK)
    {
        return VS1053_TIMEOUT;
    }

    tx[0] = VS1053_SCI_WRITE;
    tx[1] = addr;
    tx[2] = (uint8_t)(value >> 8);
    tx[3] = (uint8_t)(value & 0xFFu);

    PIN_LOW(g_dev->xcs_port, g_dev->xcs_pin);
    if (SPI_Tx(tx, 4) != VS1053_OK)
    {
        PIN_HIGH(g_dev->xcs_port, g_dev->xcs_pin);
        return VS1053_ERR;
    }
    PIN_HIGH(g_dev->xcs_port, g_dev->xcs_pin);
    VS1053_DelayGap();

    return VS1053_OK;
}

VS1053_Status_t VS1053_ResetSoft(void)
{
    uint16_t mode = VS1053_SCI_Read(VS1053_REG_MODE);
    mode |= VS1053_SM_SDINEW;
    mode |= VS1053_SM_RESET;
    if (VS1053_SCI_Write(VS1053_REG_MODE, mode) != VS1053_OK)
    {
        return VS1053_ERR;
    }
    HAL_Delay(2);
    return VS1053_WaitDREQ(VS1053_DREQ_TIMEOUT_MS);
}

VS1053_Status_t VS1053_SetClockF(uint16_t clockf)
{
    return VS1053_SCI_Write(VS1053_REG_CLOCKF, clockf);
}

VS1053_Status_t VS1053_SetVolume(uint8_t left, uint8_t right)
{
    uint16_t v = ((uint16_t)left << 8) | (uint16_t)right;
    return VS1053_SCI_Write(VS1053_REG_VOL, v);
}

VS1053_Status_t VS1053_SetBassTreble(uint8_t bass, uint8_t treble)
{
    uint16_t v = ((uint16_t)treble << 8) | (uint16_t)bass;
    return VS1053_SCI_Write(VS1053_REG_BASS, v);
}

VS1053_Status_t VS1053_SDI_Send(const uint8_t *data, size_t len)
{
    if (!g_dev || !data) return VS1053_ERR;

    size_t off = 0;
    while (off < len)
    {
        if (VS1053_WaitDREQ(VS1053_DREQ_TIMEOUT_MS) != VS1053_OK)
        {
            return VS1053_TIMEOUT;
        }

        size_t chunk = len - off;
        if (chunk > 32u) chunk = 32u;

        PIN_LOW(g_dev->xdcs_port, g_dev->xdcs_pin);
        if (SPI_Tx(&data[off], (uint16_t)chunk) != VS1053_OK)
        {
            PIN_HIGH(g_dev->xdcs_port, g_dev->xdcs_pin);
            return VS1053_ERR;
        }
        PIN_HIGH(g_dev->xdcs_port, g_dev->xdcs_pin);

        off += chunk;
    }

    return VS1053_OK;
}

VS1053_Status_t VS1053_Init(void)
{
    if (!g_dev) return VS1053_ERR;

    if (VS1053_ResetHard() != VS1053_OK)
    {
        return VS1053_ERR;
    }

    if (VS1053_ResetSoft() != VS1053_OK)
    {
        return VS1053_ERR;
    }

    (void)VS1053_SetClockF(0x6000u);
    HAL_Delay(2);

    (void)VS1053_SetVolume(40u, 40u);
    (void)VS1053_SetBassTreble(0x00u, 0x00u);

    return VS1053_OK;
}

/* -------- Sine test sequence -------- */
VS1053_Status_t VS1053_SineTest_Start(uint8_t freq_code)
{
    uint8_t seq[8];
    uint16_t mode = VS1053_SCI_Read(VS1053_REG_MODE);

    mode |= VS1053_SM_TESTS;
    mode |= VS1053_SM_SDINEW;
    if (VS1053_SCI_Write(VS1053_REG_MODE, mode) != VS1053_OK)
    {
        return VS1053_ERR;
    }
    HAL_Delay(2);

    memset(seq, 0, sizeof(seq));
    seq[0] = 0x53u;
    seq[1] = 0xEFu;
    seq[2] = 0x6Eu;
    seq[3] = freq_code;
    seq[4] = 0x00u;
    seq[5] = 0x00u;
    seq[6] = 0x00u;
    seq[7] = 0x00u;

    return VS1053_SDI_Send(seq, sizeof(seq));
}

VS1053_Status_t VS1053_SineTest_Stop(void)
{
    uint8_t seq[8];

    memset(seq, 0, sizeof(seq));
    seq[0] = 0x45u;
    seq[1] = 0x78u;
    seq[2] = 0x69u;
    seq[3] = 0x74u;
    seq[4] = 0x00u;
    seq[5] = 0x00u;
    seq[6] = 0x00u;
    seq[7] = 0x00u;

    VS1053_Status_t st = VS1053_SDI_Send(seq, sizeof(seq));
    HAL_Delay(2);

    uint16_t mode = VS1053_SCI_Read(VS1053_REG_MODE);
    mode &= (uint16_t)~VS1053_SM_TESTS;
    (void)VS1053_SCI_Write(VS1053_REG_MODE, mode);
    HAL_Delay(2);

    return st;
}

/* New: start continuous sine (no delay), user stops later */
VS1053_Status_t VS1053_Test_SineContinuousStart(uint8_t freq_code, uint8_t volL, uint8_t volR)
{
    if (VS1053_Init() != VS1053_OK)
    {
        return VS1053_ERR;
    }

    (void)VS1053_SetVolume(volL, volR);

    if (VS1053_SineTest_Start(freq_code) != VS1053_OK)
    {
        return VS1053_ERR;
    }

    return VS1053_OK;
}

/* New: stop continuous sine */
VS1053_Status_t VS1053_Test_SineContinuousStop(void)
{
    return VS1053_SineTest_Stop();
}

/* Keep existing (optional) timed test, ms_play can be used by other code */
VS1053_Status_t VS1053_Test_Option8(uint32_t ms_play)
{
    if (VS1053_Init() != VS1053_OK)
    {
        return VS1053_ERR;
    }

    (void)VS1053_SetVolume(30u, 30u);

    if (VS1053_SineTest_Start(0x44u) != VS1053_OK)
    {
        return VS1053_ERR;
    }

    if (ms_play != 0u)
    {
        HAL_Delay(ms_play);
        (void)VS1053_SineTest_Stop();
        HAL_Delay(50u);
    }

    return VS1053_OK;
}
