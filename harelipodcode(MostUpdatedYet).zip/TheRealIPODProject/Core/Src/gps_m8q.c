/* File: gps_m8q.c */                                               // HE: דרייבר GPS MAX-M8Q, קליטת UART, פרסור NMEA, וסטרים RAW ל-USB
/* Why: אם אין שורות NMEA, עדיין נראה תווים ב-USB וכך נדע שה-UART עובד */ // HE: למה הקובץ קיים

#include "gps_m8q.h"
#include "usbd_cdc_if.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#define GPS_LINE_BUFFER_SIZE 180
#define GPS_RAW_RING_SIZE    512                                    // HE: טבעת RAW כדי לא לאבד נתונים

static UART_HandleTypeDef *gps_huart = NULL;
static uint8_t gps_rx_byte = 0;

static char gps_line_buffer[GPS_LINE_BUFFER_SIZE];
static uint16_t gps_line_index = 0;

static volatile uint8_t gps_new_nmea_flag = 0;
static char gps_last_nmea_line[GPS_LINE_BUFFER_SIZE + 4];

static GPS_Data_t gps_last_data;
static volatile uint8_t gps_new_solution_flag = 0;

/* Debug counters */
static volatile uint32_t gps_uart_rx_byte_count = 0;
static volatile uint32_t gps_nmea_line_count = 0;

/* RAW ring buffer */
static volatile uint8_t  gps_raw_ring[GPS_RAW_RING_SIZE];
static volatile uint16_t gps_raw_wr = 0;
static volatile uint16_t gps_raw_rd = 0;

static void USB_CDC_SendRetryBuf(const uint8_t *buf, uint16_t len)   // HE: שליחת באפר ל-USB
{
    uint8_t tries = 0;
    while (tries < 80)
    {
        if (CDC_Transmit_FS((uint8_t*)buf, len) == USBD_OK)
        {
            return;
        }
        HAL_Delay(5);
        tries++;
    }
}

static void GPS_UART_StartRxIT(void)
{
    if (gps_huart == NULL)
    {
        return;
    }
    HAL_UART_Receive_IT(gps_huart, &gps_rx_byte, 1);
}

static uint8_t NMEA_SplitFields(char *line, char *fields[], uint8_t max_fields)
{
    uint8_t count = 0;
    char *p = line;
    fields[count++] = p;

    while (*p != '\0' && count < max_fields)
    {
        if (*p == ',')
        {
            *p = '\0';
            fields[count++] = (p + 1);
        }
        p++;
    }
    return count;
}

static double NMEA_ToDegrees(const char *ddmm, char hemi, uint8_t is_lon)
{
    (void)is_lon;
    if (ddmm == NULL || ddmm[0] == '\0')
    {
        return 0.0;
    }

    double v = strtod(ddmm, NULL);
    int deg_part = (int)(v / 100.0);
    double min_part = v - ((double)deg_part * 100.0);
    double deg = (double)deg_part + (min_part / 60.0);

    if (hemi == 'S' || hemi == 'W')
    {
        deg = -deg;
    }
    return deg;
}

static void NMEA_ParseTime_hhmmss(const char *t, uint8_t *hh, uint8_t *mm, uint8_t *ss)
{
    if (t == NULL || t[0] == '\0')
    {
        return;
    }
    if (strlen(t) < 6)
    {
        return;
    }

    *hh = (uint8_t)((t[0]-'0')*10 + (t[1]-'0'));
    *mm = (uint8_t)((t[2]-'0')*10 + (t[3]-'0'));
    *ss = (uint8_t)((t[4]-'0')*10 + (t[5]-'0'));
}

static uint8_t NMEA_IsGGA(const char *s)
{
    if (s == NULL) return 0;
    return (strstr(s, "GGA") != NULL) ? 1u : 0u;
}

static uint8_t NMEA_IsRMC(const char *s)
{
    if (s == NULL) return 0;
    return (strstr(s, "RMC") != NULL) ? 1u : 0u;
}

static void GPS_ParseNmeaLine_UpdateSolution(const char *line_in)
{
    char line[GPS_LINE_BUFFER_SIZE];
    char *f[20];
    uint8_t n = 0;

    memset(line, 0, sizeof(line));
    strncpy(line, line_in, sizeof(line) - 1);

    n = NMEA_SplitFields(line, f, 20);
    if (n < 2)
    {
        return;
    }

    if (f[0] == NULL || f[0][0] != '$')
    {
        return;
    }

    if (NMEA_IsGGA(f[0]))
    {
        if (n < 10)
        {
            return;
        }

        NMEA_ParseTime_hhmmss(f[1], &gps_last_data.hour, &gps_last_data.minute, &gps_last_data.second);

        if (f[2][0] != '\0' && f[3][0] != '\0')
        {
            gps_last_data.lat_deg = NMEA_ToDegrees(f[2], f[3][0], 0);
        }

        if (f[4][0] != '\0' && f[5][0] != '\0')
        {
            gps_last_data.lon_deg = NMEA_ToDegrees(f[4], f[5][0], 1);
        }

        int fixq = 0;
        if (f[6][0] != '\0')
        {
            fixq = atoi(f[6]);
        }
        gps_last_data.fix = (fixq > 0) ? 1u : 0u;

        if (f[9][0] != '\0')
        {
            gps_last_data.altitude_m = strtod(f[9], NULL);
        }

        gps_new_solution_flag = 1;
    }
    else if (NMEA_IsRMC(f[0]))
    {
        if (n < 7)
        {
            return;
        }

        NMEA_ParseTime_hhmmss(f[1], &gps_last_data.hour, &gps_last_data.minute, &gps_last_data.second);

        char status = (f[2] && f[2][0]) ? f[2][0] : 'V';
        gps_last_data.fix = (status == 'A') ? 1u : 0u;

        if (f[3][0] != '\0' && f[4][0] != '\0')
        {
            gps_last_data.lat_deg = NMEA_ToDegrees(f[3], f[4][0], 0);
        }

        if (f[5][0] != '\0' && f[6][0] != '\0')
        {
            gps_last_data.lon_deg = NMEA_ToDegrees(f[5], f[6][0], 1);
        }

        gps_new_solution_flag = 1;
    }
}

void GPS_M8Q_Init(UART_HandleTypeDef *huart)
{
    gps_huart = huart;

    gps_line_index = 0;
    gps_new_nmea_flag = 0;
    gps_new_solution_flag = 0;

    memset(&gps_last_data, 0, sizeof(gps_last_data));
    memset(gps_last_nmea_line, 0, sizeof(gps_last_nmea_line));
    memset((void*)gps_raw_ring, 0, sizeof(gps_raw_ring));

    gps_raw_wr = 0;
    gps_raw_rd = 0;

    gps_uart_rx_byte_count = 0;
    gps_nmea_line_count = 0;

    GPS_UART_StartRxIT();
}

void GPS_M8Q_RxCpltCallback(void)
{
    uint8_t b = gps_rx_byte;

    gps_uart_rx_byte_count++;

    /* Push RAW byte to ring buffer */
    uint16_t next_wr = (uint16_t)((gps_raw_wr + 1u) % GPS_RAW_RING_SIZE);
    if (next_wr != gps_raw_rd)
    {
        gps_raw_ring[gps_raw_wr] = b;
        gps_raw_wr = next_wr;
    }

    /* Build NMEA line for solution parsing (optional) */
    if (b == '\r')
    {
        /* ignore */
    }
    else if (b == '\n')
    {
        if (gps_line_index > 0 && gps_line_index < GPS_LINE_BUFFER_SIZE)
        {
            gps_line_buffer[gps_line_index] = '\0';

            if (gps_line_buffer[0] == '$')
            {
                size_t n = strlen(gps_line_buffer);
                if (n > (GPS_LINE_BUFFER_SIZE - 2))
                {
                    n = (GPS_LINE_BUFFER_SIZE - 2);
                }

                memcpy(gps_last_nmea_line, gps_line_buffer, n);
                gps_last_nmea_line[n + 0] = '\r';
                gps_last_nmea_line[n + 1] = '\n';
                gps_last_nmea_line[n + 2] = '\0';

                gps_new_nmea_flag = 1;
                gps_nmea_line_count++;

                GPS_ParseNmeaLine_UpdateSolution(gps_line_buffer);
            }
        }
        gps_line_index = 0;
    }
    else
    {
        if (gps_line_index < (GPS_LINE_BUFFER_SIZE - 1))
        {
            gps_line_buffer[gps_line_index++] = (char)b;
        }
        else
        {
            gps_line_index = 0;
        }
    }

    GPS_UART_StartRxIT();
}
/* File: gps_m8q.c */                                        // HE: דרייבר GPS
/* Why: 1PPS לא צריך לשלוט על PC13 כי PC13 נשלט לפי FIX */   // HE: סיבת השינוי

void GPS_M8Q_TimepulseExtiCallback(uint16_t gpio_pin)
{
    if (gpio_pin == GNSS_TIMEPULSE_GPIO_EXTI1_Pin)
    {
        gps_last_data.timepulse_count++;                      // HE: רק לספור פולסים
        // HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);            // HE: לבטל כדי לא להתנגש עם הבהוב לפי FIX
    }
}



const GPS_Data_t* GPS_M8Q_GetLastData(void)
{
    return &gps_last_data;
}

void GPS_M8Q_ResetPulse(uint32_t low_ms)
{
    HAL_GPIO_WritePin(GNSSRESET_GPIO_OUTPUT_GPIO_Port,
                      GNSSRESET_GPIO_OUTPUT_Pin,
                      GPIO_PIN_RESET);
    HAL_Delay(low_ms);
    HAL_GPIO_WritePin(GNSSRESET_GPIO_OUTPUT_GPIO_Port,
                      GNSSRESET_GPIO_OUTPUT_Pin,
                      GPIO_PIN_SET);
    HAL_Delay(10);
}

void GPS_M8Q_ExtintPulse(uint32_t high_ms)
{
    HAL_GPIO_WritePin(GNSS_EXTINT_GPIO_OUTPUT_GPIO_Port,
                      GNSS_EXTINT_GPIO_OUTPUT_Pin,
                      GPIO_PIN_SET);
    HAL_Delay(high_ms);
    HAL_GPIO_WritePin(GNSS_EXTINT_GPIO_OUTPUT_GPIO_Port,
                      GNSS_EXTINT_GPIO_OUTPUT_Pin,
                      GPIO_PIN_RESET);
}

uint8_t GPS_M8Q_HasNewNmeaLine(void)
{
    return (gps_new_nmea_flag != 0u) ? 1u : 0u;
}

void GPS_M8Q_PrintNmeaLine_USB(void)
{
    if (!gps_new_nmea_flag)
    {
        return;
    }
    gps_new_nmea_flag = 0;

    USB_CDC_SendRetryBuf((const uint8_t*)gps_last_nmea_line, (uint16_t)strlen(gps_last_nmea_line));
}

void GPS_M8Q_UsbStreamRawBytes(void)                                 // HE: מדפיס כל בייט שמגיע
{
    uint8_t out[64];
    uint16_t cnt = 0;

    while (gps_raw_rd != gps_raw_wr && cnt < sizeof(out))
    {
        out[cnt++] = gps_raw_ring[gps_raw_rd];
        gps_raw_rd = (uint16_t)((gps_raw_rd + 1u) % GPS_RAW_RING_SIZE);
    }

    if (cnt > 0)
    {
        USB_CDC_SendRetryBuf(out, cnt);
    }
}

uint8_t GPS_M8Q_HasNewSolution(void)
{
    return (gps_new_solution_flag != 0u) ? 1u : 0u;
}

void GPS_M8Q_ClearNewSolutionFlag(void)
{
    gps_new_solution_flag = 0;
}

uint32_t GPS_M8Q_GetUartRxByteCount(void)
{
    return gps_uart_rx_byte_count;
}

uint32_t GPS_M8Q_GetNmeaLineCount(void)
{
    return gps_nmea_line_count;
}


/* File: gps_m8q.c */                                               // HE: דרייבר GPS, תיקון LED 1PPS
/* Why: להשתמש בפינים מה-main.h ולא ב-GPIO_PIN_13 קשיח */            // HE: למה השינוי


