/* File: spif.c                                                                          // HE: מימוש דרייבר SPI FLASH
   Why: קריאה, כתיבה, מחיקה, JEDEC ID, וטסט תקינות מלא                                 // HE: למה הקובץ קיים
*/

#include "spif.h"                                                                        // HE: כולל כותרת דרייבר

#if SPIF_DEBUG == SPIF_DEBUG_DISABLE                                                     // HE: אם Debug כבוי
#define dprintf(...)                                                                     // HE: בטל הדפסות
#else                                                                                    // HE: אחרת
#include <stdio.h>                                                                       // HE: printf
#define dprintf(...) printf(__VA_ARGS__)                                                 // HE: מאקרו הדפסה
#endif                                                                                   // HE: סוף Debug

/* פקודות SPI NOR נפוצות */                                                              // HE: הערה כללית
#define SPIF_CMD_WREN               0x06U                                                // HE: Write Enable
#define SPIF_CMD_WRDI               0x04U                                                // HE: Write Disable
#define SPIF_CMD_RDSR1              0x05U                                                // HE: Read Status Reg-1
#define SPIF_CMD_READ               0x03U                                                // HE: Read Data (slow)
#define SPIF_CMD_PP                 0x02U                                                // HE: Page Program
#define SPIF_CMD_SE                 0x20U                                                // HE: Sector Erase 4KB
#define SPIF_CMD_JEDECID            0x9FU                                                // HE: Read JEDEC ID
#define SPIF_CMD_RSTEN              0x66U                                                // HE: Enable Reset (W25Q128JV)
#define SPIF_CMD_RST                0x99U                                                // HE: Reset Device (W25Q128JV)

#define SPIF_STATUS1_BUSY           (1U << 0)                                            // HE: BUSY/WIP bit (S0)
#define SPIF_STATUS1_WEL            (1U << 1)                                            // HE: WEL bit (S1)

#define SPIF_TIMEOUT_SHORT_MS       200U                                                 // HE: טיים אאוט קצר (הוגדל)
#define SPIF_TIMEOUT_PROG_MS        800U                                                 // HE: טיים אאוט כתיבה (הוגדל)
#define SPIF_TIMEOUT_ERASE_MS       4000U                                                // HE: טיים אאוט מחיקה (הוגדל)

static void SPIF_DelayMs(uint32_t ms)                                                    // HE: השהיה במילישניות
{
  HAL_Delay(ms);                                                                         // HE: שימוש ב-HAL_Delay
}

static void SPIF_Lock(SPIF_HandleTypeDef *h)                                             // HE: נעילה פשוטה
{
  while (h->Lock)                                                                        // HE: כל עוד נעול
  {
    SPIF_DelayMs(1);                                                                     // HE: המתן 1ms
  }
  h->Lock = 1;                                                                           // HE: נעל
}

static void SPIF_Unlock(SPIF_HandleTypeDef *h)                                           // HE: שחרור נעילה
{
  h->Lock = 0;                                                                           // HE: שחרר
}

static void SPIF_CS(SPIF_HandleTypeDef *h, bool levelHigh)                               // HE: שליטה ב-CS
{
  HAL_GPIO_WritePin(h->CsGpio, h->CsPin, levelHigh ? GPIO_PIN_SET : GPIO_PIN_RESET);     // HE: קבע רמה
  for (volatile int i = 0; i < 80; i++) {;}                                              // HE: דיליי קצר ליציבות (הוגדל מעט)
}

static bool SPIF_TxRx(SPIF_HandleTypeDef *h, const uint8_t *tx, uint8_t *rx, uint16_t n, uint32_t to) // HE: TXRX
{
  if (HAL_SPI_TransmitReceive(h->HSpi, (uint8_t*)tx, rx, n, to) == HAL_OK)               // HE: HAL TXRX
  {
    return true;                                                                         // HE: הצלחה
  }
  dprintf("SPIF: TXRX timeout or error\r\n");                                            // HE: הודעת שגיאה
  return false;                                                                          // HE: כישלון
}

static bool SPIF_Tx(SPIF_HandleTypeDef *h, const uint8_t *tx, uint16_t n, uint32_t to)   // HE: TX בלבד
{
  if (HAL_SPI_Transmit(h->HSpi, (uint8_t*)tx, n, to) == HAL_OK)                          // HE: HAL TX
  {
    return true;                                                                         // HE: הצלחה
  }
  dprintf("SPIF: TX timeout or error\r\n");                                              // HE: הודעת שגיאה
  return false;                                                                          // HE: כישלון
}

static bool SPIF_Rx(SPIF_HandleTypeDef *h, uint8_t *rx, uint16_t n, uint32_t to)         // HE: RX בלבד
{
  if (HAL_SPI_Receive(h->HSpi, rx, n, to) == HAL_OK)                                     // HE: HAL RX
  {
    return true;                                                                         // HE: הצלחה
  }
  dprintf("SPIF: RX timeout or error\r\n");                                              // HE: הודעת שגיאה
  return false;                                                                          // HE: כישלון
}

static uint8_t SPIF_ReadStatus1(SPIF_HandleTypeDef *h)                                   // HE: קריאת סטטוס 1
{
  uint8_t tx[2] = { SPIF_CMD_RDSR1, 0xFFU };                                             // HE: פקודה + דמה
  uint8_t rx[2] = { 0 };                                                                 // HE: באפר RX
  SPIF_CS(h, false);                                                                     // HE: CS נמוך, בחירה
  (void)SPIF_TxRx(h, tx, rx, 2, SPIF_TIMEOUT_SHORT_MS);                                  // HE: TXRX
  SPIF_CS(h, true);                                                                      // HE: CS גבוה, שחרור
  return rx[1];                                                                          // HE: החזר סטטוס
}

static bool SPIF_WaitReady(SPIF_HandleTypeDef *h, uint32_t timeoutMs)                     // HE: המתנה עד לא BUSY
{
  uint32_t t0 = HAL_GetTick();                                                           // HE: זמן התחלה
  while ((HAL_GetTick() - t0) < timeoutMs)                                               // HE: לולאה עד טיים אאוט
  {
    if ((SPIF_ReadStatus1(h) & SPIF_STATUS1_BUSY) == 0U)                                 // HE: אם לא עסוק
    {
      return true;                                                                       // HE: מוכן
    }
    SPIF_DelayMs(1);                                                                     // HE: המתנה קצרה
  }
  dprintf("SPIF: WaitReady timeout\r\n");                                                // HE: שגיאת טיים אאוט
  return false;                                                                          // HE: כישלון
}

static bool SPIF_WriteEnable(SPIF_HandleTypeDef *h)                                      // HE: WREN + בדיקת WEL
{
  uint8_t cmd = SPIF_CMD_WREN;                                                           // HE: פקודת WREN

  if (!SPIF_WaitReady(h, SPIF_TIMEOUT_SHORT_MS))                                         // HE: ודא שלא BUSY לפני WREN
  {
    return false;                                                                        // HE: כישלון
  }

  SPIF_CS(h, false);                                                                     // HE: בחר שבב
  bool ok = SPIF_Tx(h, &cmd, 1, SPIF_TIMEOUT_SHORT_MS);                                  // HE: שלח פקודה
  SPIF_CS(h, true);                                                                      // HE: שחרר שבב

  if (!ok)                                                                               // HE: אם לא נשלח
  {
    return false;                                                                        // HE: כישלון
  }

  uint8_t sr1 = SPIF_ReadStatus1(h);                                                     // HE: קרא סטטוס כדי לוודא WEL
  if ((sr1 & SPIF_STATUS1_WEL) == 0U)                                                    // HE: אם WEL לא נדלק
  {
    dprintf("SPIF: WEL not set (SR1=0x%02X)\r\n", sr1);                                  // HE: דיבאג
    return false;                                                                        // HE: כישלון
  }

  return true;                                                                           // HE: הצלחה
}

static void SPIF_WriteDisable(SPIF_HandleTypeDef *h)                                     // HE: WRDI
{
  uint8_t cmd = SPIF_CMD_WRDI;                                                           // HE: פקודת WRDI
  SPIF_CS(h, false);                                                                     // HE: בחר שבב
  (void)SPIF_Tx(h, &cmd, 1, SPIF_TIMEOUT_SHORT_MS);                                      // HE: שלח פקודה
  SPIF_CS(h, true);                                                                      // HE: שחרר שבב
}

static void SPIF_ResetDevice(SPIF_HandleTypeDef *h)                                      // HE: Reset תוכנתי 66h,99h
{
  uint8_t cmd = 0;                                                                       // HE: משתנה פקודה

  SPIF_CS(h, true);                                                                      // HE: ודא CS במצב idle
  (void)SPIF_WaitReady(h, 50U);                                                          // HE: ניסיון קצר לוודא לא BUSY

  cmd = SPIF_CMD_RSTEN;                                                                  // HE: Enable Reset
  SPIF_CS(h, false);                                                                     // HE: CS נמוך
  (void)SPIF_Tx(h, &cmd, 1, SPIF_TIMEOUT_SHORT_MS);                                      // HE: שלח 66h
  SPIF_CS(h, true);                                                                      // HE: CS גבוה

  cmd = SPIF_CMD_RST;                                                                    // HE: Reset Device
  SPIF_CS(h, false);                                                                     // HE: CS נמוך
  (void)SPIF_Tx(h, &cmd, 1, SPIF_TIMEOUT_SHORT_MS);                                      // HE: שלח 99h
  SPIF_CS(h, true);                                                                      // HE: CS גבוה

  SPIF_DelayMs(2);                                                                       // HE: המתן מעט אחרי reset
  (void)SPIF_WaitReady(h, 50U);                                                          // HE: ודא חזרה למצב מוכן
}

bool SPIF_ReadJedecId(SPIF_HandleTypeDef *h, uint8_t *mfg, uint8_t *memType, uint8_t *capacity) // HE: קריאת JEDEC
{
  uint8_t cmd = SPIF_CMD_JEDECID;                                                        // HE: פקודה
  uint8_t rx[3] = {0};                                                                   // HE: 3 בתים חזרה

  SPIF_CS(h, false);                                                                     // HE: בחר שבב
  if (!SPIF_Tx(h, &cmd, 1, SPIF_TIMEOUT_SHORT_MS))                                       // HE: שלח פקודה
  {
    SPIF_CS(h, true);                                                                    // HE: שחרר
    return false;                                                                        // HE: כישלון
  }
  if (!SPIF_Rx(h, rx, 3, SPIF_TIMEOUT_SHORT_MS))                                         // HE: קבל 3 בתים
  {
    SPIF_CS(h, true);                                                                    // HE: שחרר
    return false;                                                                        // HE: כישלון
  }
  SPIF_CS(h, true);                                                                      // HE: שחרר שבב

  if (mfg) { *mfg = rx[0]; }                                                             // HE: החזר Manufacturer
  if (memType) { *memType = rx[1]; }                                                     // HE: החזר MemType
  if (capacity) { *capacity = rx[2]; }                                                   // HE: החזר Capacity

  h->Manufactor = (SPIF_ManufactorTypeDef)rx[0];                                         // HE: שמור ב-handle
  h->MemType = rx[1];                                                                    // HE: שמור ב-handle
  h->SizeCode = rx[2];                                                                   // HE: שמור ב-handle
  h->JedecId = ((uint32_t)rx[0] << 16) | ((uint32_t)rx[1] << 8) | (uint32_t)rx[2];      // HE: JEDEC 24bit

  return true;                                                                           // HE: הצלחה
}

bool SPIF_Init(SPIF_HandleTypeDef *h, SPI_HandleTypeDef *hspi, GPIO_TypeDef *csPort, uint16_t csPin) // HE: Init
{
  if (!h || !hspi || !csPort)                                                            // HE: בדיקת פרמטרים
  {
    return false;                                                                        // HE: כישלון
  }

  memset(h, 0, sizeof(*h));                                                              // HE: איפוס handle
  h->HSpi = hspi;                                                                        // HE: שמור מצביע SPI
  h->CsGpio = csPort;                                                                    // HE: שמור פורט CS
  h->CsPin = csPin;                                                                      // HE: שמור פין CS

  SPIF_CS(h, true);                                                                      // HE: CS במצב idle גבוה
  SPIF_DelayMs(60);                                                                      // HE: השהייה ארוכה יותר ל-tPUW אחרי Power-Up

  SPIF_ResetDevice(h);                                                                   // HE: החזר לברירת מחדל (66h,99h)

  SPIF_WriteDisable(h);                                                                  // HE: נטרל כתיבה בהתחלה

  uint8_t a=0,b=0,c=0;                                                                   // HE: משתנים ל-JEDEC
  if (!SPIF_ReadJedecId(h, &a, &b, &c))                                                  // HE: נסה לקרוא JEDEC
  {
    return false;                                                                        // HE: כישלון
  }

  h->Inited = 1;                                                                         // HE: סמן אתחול
  dprintf("SPIF: JEDEC %02X %02X %02X\r\n", a, b, c);                                    // HE: הדפס JEDEC
  return true;                                                                           // HE: הצלחה
}

bool SPIF_Read(SPIF_HandleTypeDef *h, uint32_t addr, uint8_t *data, uint32_t len)        // HE: קריאה רציפה (עם חלוקה)
{
  if (!h || !h->Inited || !data || (len == 0U))                                          // HE: בדיקת קלט
  {
    return false;                                                                        // HE: כישלון
  }

  uint32_t remaining = len;                                                              // HE: כמה נשאר
  uint32_t offset = 0;                                                                   // HE: אופסט

  while (remaining > 0U)                                                                 // HE: לולאה לכל הקריאה
  {
    uint16_t chunk = (remaining > 65535U) ? 65535U : (uint16_t)remaining;                // HE: HAL מוגבל ל-uint16_t

    uint32_t a = addr + offset;                                                          // HE: כתובת נוכחית
    uint8_t hdr[4];                                                                      // HE: כותרת פקודה+כתובת
    hdr[0] = SPIF_CMD_READ;                                                              // HE: פקודת READ
    hdr[1] = (uint8_t)((a >> 16) & 0xFFU);                                               // HE: A23..A16
    hdr[2] = (uint8_t)((a >> 8) & 0xFFU);                                                // HE: A15..A8
    hdr[3] = (uint8_t)(a & 0xFFU);                                                       // HE: A7..A0

    SPIF_CS(h, false);                                                                   // HE: בחר שבב
    if (!SPIF_Tx(h, hdr, 4, SPIF_TIMEOUT_SHORT_MS))                                      // HE: שלח כותרת
    {
      SPIF_CS(h, true);                                                                  // HE: שחרר
      return false;                                                                      // HE: כישלון
    }

    bool ok = SPIF_Rx(h, &data[offset], chunk, 2000U);                                   // HE: קבל נתונים
    SPIF_CS(h, true);                                                                    // HE: שחרר שבב

    if (!ok)                                                                             // HE: אם נכשל
    {
      return false;                                                                      // HE: כישלון
    }

    offset += (uint32_t)chunk;                                                           // HE: עדכן אופסט
    remaining -= (uint32_t)chunk;                                                        // HE: עדכן נשאר
  }

  return true;                                                                           // HE: הצלחה
}

bool SPIF_EraseSector(SPIF_HandleTypeDef *h, uint32_t sectorNumber)                      // HE: מחיקת סקטור
{
  if (!h || !h->Inited)                                                                  // HE: בדיקה
  {
    return false;                                                                        // HE: כישלון
  }

  uint32_t addr = SPIF_SectorToAddress(sectorNumber);                                    // HE: כתובת סקטור

  if (!SPIF_WriteEnable(h))                                                              // HE: אפשר כתיבה + בדיקת WEL
  {
    return false;                                                                        // HE: כישלון
  }

  uint8_t hdr[4];                                                                        // HE: פקודה+כתובת
  hdr[0] = SPIF_CMD_SE;                                                                  // HE: Sector Erase
  hdr[1] = (uint8_t)((addr >> 16) & 0xFFU);                                              // HE: A23..A16
  hdr[2] = (uint8_t)((addr >> 8) & 0xFFU);                                               // HE: A15..A8
  hdr[3] = (uint8_t)(addr & 0xFFU);                                                      // HE: A7..A0

  SPIF_CS(h, false);                                                                     // HE: בחר שבב
  if (!SPIF_Tx(h, hdr, 4, SPIF_TIMEOUT_SHORT_MS))                                        // HE: שלח פקודה
  {
    SPIF_CS(h, true);                                                                    // HE: שחרר
    SPIF_WriteDisable(h);                                                                // HE: נטרל כתיבה
    return false;                                                                        // HE: כישלון
  }
  SPIF_CS(h, true);                                                                      // HE: שחרר שבב

  bool ok = SPIF_WaitReady(h, SPIF_TIMEOUT_ERASE_MS);                                    // HE: המתן למחיקה
  SPIF_WriteDisable(h);                                                                  // HE: נטרל כתיבה
  return ok;                                                                             // HE: החזר תוצאה
}

bool SPIF_Write(SPIF_HandleTypeDef *h, uint32_t addr, const uint8_t *data, uint32_t len) // HE: כתיבה עם חלוקה לעמודים
{
  if (!h || !h->Inited || !data || (len == 0U))                                          // HE: בדיקת קלט
  {
    return false;                                                                        // HE: כישלון
  }

  uint32_t remaining = len;                                                              // HE: כמה נשאר
  uint32_t offset = 0;                                                                   // HE: אופסט במערך

  while (remaining > 0U)                                                                 // HE: כל עוד יש נתונים
  {
    uint32_t pageOffset = (addr + offset) % SPIF_PAGE_SIZE;                              // HE: אופסט בתוך עמוד
    uint32_t space = SPIF_PAGE_SIZE - pageOffset;                                        // HE: מקום בעמוד
    uint32_t chunk = (remaining < space) ? remaining : space;                            // HE: כמה לכתוב עכשיו

    if (!SPIF_WriteEnable(h))                                                            // HE: אפשר כתיבה + בדיקת WEL
    {
      return false;                                                                      // HE: כישלון
    }

    uint32_t a = addr + offset;                                                          // HE: כתובת נוכחית
    uint8_t hdr[4];                                                                      // HE: פקודה+כתובת
    hdr[0] = SPIF_CMD_PP;                                                                // HE: Page Program
    hdr[1] = (uint8_t)((a >> 16) & 0xFFU);                                               // HE: A23..A16
    hdr[2] = (uint8_t)((a >> 8) & 0xFFU);                                                // HE: A15..A8
    hdr[3] = (uint8_t)(a & 0xFFU);                                                       // HE: A7..A0

    SPIF_CS(h, false);                                                                   // HE: בחר שבב
    if (!SPIF_Tx(h, hdr, 4, SPIF_TIMEOUT_SHORT_MS))                                      // HE: שלח כותרת
    {
      SPIF_CS(h, true);                                                                  // HE: שחרר
      SPIF_WriteDisable(h);                                                              // HE: נטרל כתיבה
      return false;                                                                      // HE: כישלון
    }

    if (!SPIF_Tx(h, &data[offset], (uint16_t)chunk, 2000U))                              // HE: שלח נתונים
    {
      SPIF_CS(h, true);                                                                  // HE: שחרר
      SPIF_WriteDisable(h);                                                              // HE: נטרל כתיבה
      return false;                                                                      // HE: כישלון
    }

    SPIF_CS(h, true);                                                                    // HE: שחרר שבב

    if (!SPIF_WaitReady(h, SPIF_TIMEOUT_PROG_MS))                                        // HE: המתן לסיום כתיבה
    {
      SPIF_WriteDisable(h);                                                              // HE: נטרל כתיבה
      return false;                                                                      // HE: כישלון
    }

    SPIF_WriteDisable(h);                                                                // HE: נטרל כתיבה

    offset += chunk;                                                                     // HE: עדכן אופסט
    remaining -= chunk;                                                                  // HE: עדכן נשאר
  }

  return true;                                                                           // HE: הצלחה
}

bool SPIF_Test(SPIF_HandleTypeDef *h, uint32_t testAddr)                                 // HE: טסט תקינות ל-FLASH
{
  if (!h || !h->Inited)                                                                  // HE: בדיקה
  {
    return false;                                                                        // HE: כישלון
  }

  SPIF_Lock(h);                                                                          // HE: נעל
  bool ok = false;                                                                       // HE: דגל תוצאה

  uint8_t m=0,t=0,c=0;                                                                   // HE: JEDEC bytes
  if (!SPIF_ReadJedecId(h, &m, &t, &c))                                                  // HE: בדיקת תקשורת בסיסית
  {
    dprintf("SPIF_TEST: JEDEC read failed\r\n");                                         // HE: הודעה
    SPIF_Unlock(h);                                                                      // HE: שחרר
    return false;                                                                        // HE: כישלון
  }

  dprintf("SPIF_TEST: JEDEC %02X %02X %02X\r\n", m, t, c);                               // HE: הדפס JEDEC

  uint32_t sector = SPIF_AddressToSector(testAddr);                                      // HE: סקטור של כתובת הטסט
  uint32_t base = SPIF_SectorToAddress(sector);                                          // HE: כתובת תחילת סקטור
  dprintf("SPIF_TEST: erase sector %lu (addr 0x%08lX)\r\n", (unsigned long)sector, (unsigned long)base); // HE: הודעה

  if (!SPIF_EraseSector(h, sector))                                                      // HE: מחיקת סקטור
  {
    dprintf("SPIF_TEST: erase failed\r\n");                                              // HE: הודעה
    SPIF_Unlock(h);                                                                      // HE: שחרר
    return false;                                                                        // HE: כישלון
  }

  uint8_t tx[256];                                                                       // HE: באפר כתיבה עמוד
  uint8_t rx[256];                                                                       // HE: באפר קריאה עמוד

  for (uint32_t i = 0; i < sizeof(tx); i++)                                              // HE: מלא תבנית
  {
    tx[i] = (uint8_t)(0xA5U ^ (uint8_t)i);                                               // HE: תבנית דטרמיניסטית
  }

  if (!SPIF_Write(h, base, tx, sizeof(tx)))                                              // HE: כתוב עמוד ראשון בסקטור
  {
    dprintf("SPIF_TEST: write failed\r\n");                                              // HE: הודעה
    SPIF_Unlock(h);                                                                      // HE: שחרר
    return false;                                                                        // HE: כישלון
  }

  memset(rx, 0, sizeof(rx));                                                             // HE: אפס RX
  if (!SPIF_Read(h, base, rx, sizeof(rx)))                                               // HE: קרא חזרה
  {
    dprintf("SPIF_TEST: read failed\r\n");                                               // HE: הודעה
    SPIF_Unlock(h);                                                                      // HE: שחרר
    return false;                                                                        // HE: כישלון
  }

  if (memcmp(tx, rx, sizeof(tx)) != 0)                                                   // HE: השוואה
  {
    dprintf("SPIF_TEST: compare FAILED\r\n");                                            // HE: הודעה
    dprintf("SPIF_TEST: first bytes TX=%02X RX=%02X\r\n", tx[0], rx[0]);                 // HE: עוזר לדיבאג מהיר
    ok = false;                                                                          // HE: נכשל
  }
  else
  {
    dprintf("SPIF_TEST: compare OK\r\n");                                                // HE: הודעה
    ok = true;                                                                           // HE: הצליח
  }

  (void)SPIF_EraseSector(h, sector);                                                     // HE: אופציונלי, נקה אחרי טסט
  SPIF_Unlock(h);                                                                        // HE: שחרר נעילה
  return ok;                                                                             // HE: החזר תוצאה
}
