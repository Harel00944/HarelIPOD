#include "flash_logger.h"

#include <string.h>
#include <stdio.h>
#include <stdarg.h>

/* USER CODE BEGIN Includes */
#include "BNO055.h"
/* USER CODE END Includes */

/* USER CODE BEGIN Defines */
/* מיפוי: אצלך בדרייבר יש SPIF_EraseSector, לא SPIF_EraseSector4K */
#ifndef SPIF_EraseSector4K
#define SPIF_EraseSector4K SPIF_EraseSector
#endif
/* USER CODE END Defines */

/* ===== Config ===== */
#define FL_MAGIC_META      0x4D455441u
#define FL_MAGIC_REC       0x52454331u
#define FL_VERSION         1u

#define FL_BASE_ADDR       0x00200000u
#define FL_META_SIZE       0x00001000u
#define FL_SLOT_SIZE       0x00010000u
#define FL_SLOT_COUNT      16u

typedef struct __attribute__((packed))
{
  int16_t yaw_x16;
  int16_t pitch_x16;
  int16_t roll_x16;
  uint32_t tick_ms;
} FL_Sample_t;

typedef struct __attribute__((packed))
{
  uint32_t magic;
  uint32_t index;
  uint32_t sample_period_ms;
  uint32_t sample_count;
  uint32_t reserved0;
  uint32_t reserved1;
} FL_RecHeader_t;

typedef struct __attribute__((packed))
{
  uint32_t magic;
  uint32_t version;
  uint32_t slot_count;
  uint32_t slot_size;
  uint32_t next_slot;
  uint32_t formatted;
  uint32_t reserved0;
  uint32_t reserved1;
} FL_Meta_t;

/* ===== Module state ===== */
static SPIF_HandleTypeDef *s_spif = NULL;
static FL_TxFunc s_tx = NULL;
static FL_Meta_t s_meta;

static uint8_t  s_rec_active = 0;
static uint32_t s_rec_slot = 0;
static uint32_t s_rec_write_addr = 0;
static uint32_t s_rec_sample_period_ms = 50;
static uint32_t s_rec_last_tick = 0;
static uint32_t s_rec_sample_count = 0;
static uint32_t s_rec_target_samples = 0;

/* USER CODE BEGIN PFP */
/* אם משום מה BNO055.h אצלך לא מצהיר את זה, ההצהרה כאן מונעת implicit */
extern uint8_t BNO055_ReadEuler_deg_x16(int16_t *h, int16_t *r, int16_t *p);
/* USER CODE END PFP */

static void FL_TxStr(const char *s)
{
  if (!s_tx || !s) return;
  s_tx((const uint8_t*)s, (uint16_t)strlen(s));
}

static void FL_TxPrintf(const char *fmt, ...)
{
  if (!s_tx || !fmt) return;

  char buf[192];
  va_list ap;
  va_start(ap, fmt);
  int n = vsnprintf(buf, sizeof(buf), fmt, ap);
  va_end(ap);

  if (n > 0)
  {
    if (n > (int)sizeof(buf)) n = (int)sizeof(buf);
    s_tx((const uint8_t*)buf, (uint16_t)n);
  }
}

static uint32_t FL_SlotBase(uint32_t slot)
{
  return (FL_BASE_ADDR + FL_META_SIZE + (slot * FL_SLOT_SIZE));
}

static uint8_t FL_ReadMeta(FL_Meta_t *out)
{
  if (!s_spif || !out) return 0;
  memset(out, 0, sizeof(*out));
  return SPIF_Read(s_spif, FL_BASE_ADDR, (uint8_t*)out, sizeof(*out)) ? 1u : 0u;
}

static uint8_t FL_WriteMeta(const FL_Meta_t *m)
{
  if (!s_spif || !m) return 0;
  if (!SPIF_EraseSector4K(s_spif, FL_BASE_ADDR)) return 0;
  return SPIF_Write(s_spif, FL_BASE_ADDR, (const uint8_t*)m, sizeof(*m)) ? 1u : 0u;
}

static uint8_t FL_ReadRecHeader(uint32_t slot, FL_RecHeader_t *hdr)
{
  if (!s_spif || !hdr) return 0;
  uint32_t addr = FL_SlotBase(slot);
  memset(hdr, 0, sizeof(*hdr));
  return SPIF_Read(s_spif, addr, (uint8_t*)hdr, sizeof(*hdr)) ? 1u : 0u;
}

static uint8_t FL_WriteRecHeader(uint32_t slot, const FL_RecHeader_t *hdr)
{
  if (!s_spif || !hdr) return 0;
  uint32_t addr = FL_SlotBase(slot);
  return SPIF_Write(s_spif, addr, (const uint8_t*)hdr, sizeof(*hdr)) ? 1u : 0u;
}

static uint8_t FL_EraseSlot(uint32_t slot)
{
  if (!s_spif) return 0;

  uint32_t base = FL_SlotBase(slot);
  uint32_t end  = base + FL_SLOT_SIZE;

  for (uint32_t a = base; a < end; a += 0x1000u)
  {
    if (!SPIF_EraseSector4K(s_spif, a)) return 0;
  }
  return 1;
}

static uint8_t FL_MetaValid(const FL_Meta_t *m)
{
  if (!m) return 0;
  if (m->magic != FL_MAGIC_META) return 0;
  if (m->version != FL_VERSION) return 0;
  if (m->slot_count != FL_SLOT_COUNT) return 0;
  if (m->slot_size != FL_SLOT_SIZE) return 0;
  if (m->formatted != 1u) return 0;
  if (m->next_slot >= FL_SLOT_COUNT) return 0;
  return 1;
}

static uint8_t FL_HeaderValid(const FL_RecHeader_t *h)
{
  if (!h) return 0;
  if (h->magic != FL_MAGIC_REC) return 0;
  if (h->index >= FL_SLOT_COUNT) return 0;
  if (h->sample_count == 0) return 0;
  if (h->sample_period_ms == 0) return 0;
  return 1;
}

void FL_Init(SPIF_HandleTypeDef *spif, FL_TxFunc tx)
{
  s_spif = spif;
  s_tx = tx;

  memset(&s_meta, 0, sizeof(s_meta));

  FL_Meta_t m;
  uint8_t ok = FL_ReadMeta(&m);

  if (!ok || !FL_MetaValid(&m))
  {
    FL_TxStr("[FLASH] Logger meta invalid, run FORMAT (option 8)\r\n");
    return;
  }

  s_meta = m;
}

void FL_FormatStorage(void)
{
  if (!s_spif) return;

  FL_TxStr("[FLASH] FORMAT start\r\n");

  (void)SPIF_EraseSector4K(s_spif, FL_BASE_ADDR);

  for (uint32_t i = 0; i < FL_SLOT_COUNT; i++)
  {
    if (!FL_EraseSlot(i))
    {
      FL_TxPrintf("[FLASH] FORMAT failed at slot %lu\r\n", (unsigned long)i);
      return;
    }
  }

  FL_Meta_t m;
  memset(&m, 0, sizeof(m));
  m.magic = FL_MAGIC_META;
  m.version = FL_VERSION;
  m.slot_count = FL_SLOT_COUNT;
  m.slot_size = FL_SLOT_SIZE;
  m.next_slot = 0;
  m.formatted = 1u;

  if (!FL_WriteMeta(&m))
  {
    FL_TxStr("[FLASH] FORMAT failed: meta write\r\n");
    return;
  }

  s_meta = m;
  FL_TxStr("[FLASH] FORMAT done\r\n");
}

void FL_StartRecording_10s(uint32_t sample_period_ms)
{
  if (!s_spif) return;

  FL_Meta_t m;
  if (!FL_ReadMeta(&m) || !FL_MetaValid(&m))
  {
    FL_TxStr("[FLASH] Logger meta exists but headers invalid, run FORMAT (option 8)\r\n");
    return;
  }
  s_meta = m;

  s_rec_slot = s_meta.next_slot;
  if (s_rec_slot >= FL_SLOT_COUNT) s_rec_slot = 0;

  if (!FL_EraseSlot(s_rec_slot))
  {
    FL_TxStr("[FLASH] REC failed: erase slot\r\n");
    return;
  }

  FL_RecHeader_t hdr;
  memset(&hdr, 0, sizeof(hdr));
  hdr.magic = FL_MAGIC_REC;
  hdr.index = s_rec_slot;
  hdr.sample_period_ms = sample_period_ms;
  hdr.sample_count = 0;

  if (!FL_WriteRecHeader(s_rec_slot, &hdr))
  {
    FL_TxStr("[FLASH] REC failed: header write\r\n");
    return;
  }

  s_rec_sample_period_ms = sample_period_ms;
  s_rec_target_samples = (10000u / (sample_period_ms ? sample_period_ms : 1u));
  if (s_rec_target_samples == 0) s_rec_target_samples = 1;

  s_rec_active = 1;
  s_rec_sample_count = 0;
  s_rec_last_tick = HAL_GetTick();
  s_rec_write_addr = FL_SlotBase(s_rec_slot) + sizeof(FL_RecHeader_t);

  FL_TxPrintf("[FLASH] REC start: 10s, period=%lums, samples=%lu\r\n",
              (unsigned long)s_rec_sample_period_ms,
              (unsigned long)s_rec_target_samples);
}

void FL_Tick(void)
{
  if (!s_rec_active || !s_spif) return;

  uint32_t now = HAL_GetTick();
  if ((now - s_rec_last_tick) < s_rec_sample_period_ms) return;
  s_rec_last_tick = now;

  int16_t h16 = 0, r16 = 0, p16 = 0;
  if (!BNO055_ReadEuler_deg_x16(&h16, &r16, &p16))
  {
    return;
  }

  FL_Sample_t s;
  s.yaw_x16 = h16;
  s.pitch_x16 = p16;
  s.roll_x16 = r16;
  s.tick_ms = now;

  if (!SPIF_Write(s_spif, s_rec_write_addr, (const uint8_t*)&s, sizeof(s)))
  {
    s_rec_active = 0;
    FL_TxStr("[FLASH] REC failed: sample write\r\n");
    return;
  }

  s_rec_write_addr += sizeof(s);
  s_rec_sample_count++;

  if (s_rec_sample_count >= s_rec_target_samples)
  {
    FL_RecHeader_t hdr;
    memset(&hdr, 0, sizeof(hdr));
    hdr.magic = FL_MAGIC_REC;
    hdr.index = s_rec_slot;
    hdr.sample_period_ms = s_rec_sample_period_ms;
    hdr.sample_count = s_rec_sample_count;

    (void)FL_WriteRecHeader(s_rec_slot, &hdr);

    s_meta.next_slot = (s_rec_slot + 1u) % FL_SLOT_COUNT;
    (void)FL_WriteMeta(&s_meta);

    s_rec_active = 0;
    FL_TxStr("[FLASH] REC done\r\n");
  }
}

void FL_ListRecordingsToUSB(void)
{
  if (!s_spif) return;

  FL_Meta_t m;
  if (!FL_ReadMeta(&m) || !FL_MetaValid(&m))
  {
    FL_TxStr("[FLASH] Logger meta exists but headers invalid, run FORMAT (option 8)\r\n");
    return;
  }
  s_meta = m;

  uint32_t count = 0;
  FL_TxStr("\r\n[FLASH] Recordings:\r\n");

  for (uint32_t i = 0; i < FL_SLOT_COUNT; i++)
  {
    FL_RecHeader_t h;
    if (!FL_ReadRecHeader(i, &h))
    {
      continue;
    }

    if (FL_HeaderValid(&h))
    {
      FL_TxPrintf("%lu) slot=%lu, period=%lums, samples=%lu\r\n",
                  (unsigned long)(count + 1u),
                  (unsigned long)h.index,
                  (unsigned long)h.sample_period_ms,
                  (unsigned long)h.sample_count);
      count++;
    }
  }

  if (count == 0)
  {
    FL_TxStr("[FLASH] No valid recordings found, run FORMAT (option 8)\r\n");
  }
}

void FL_PlayRecordingToUSB(uint32_t index)
{
  if (!s_spif) return;

  if (index >= FL_SLOT_COUNT)
  {
    FL_TxStr("[FLASH] Invalid slot index\r\n");
    return;
  }

  FL_RecHeader_t h;
  if (!FL_ReadRecHeader(index, &h))
  {
    FL_TxStr("[FLASH] Read header failed\r\n");
    return;
  }

  if (!FL_HeaderValid(&h))
  {
    FL_TxStr("[FLASH] Header invalid for this slot\r\n");
    return;
  }

  FL_TxPrintf("[FLASH] PLAY slot=%lu, period=%lums, samples=%lu\r\n",
              (unsigned long)h.index,
              (unsigned long)h.sample_period_ms,
              (unsigned long)h.sample_count);

  uint32_t addr = FL_SlotBase(index) + sizeof(FL_RecHeader_t);

  for (uint32_t i = 0; i < h.sample_count; i++)
  {
    FL_Sample_t s;
    if (!SPIF_Read(s_spif, addr, (uint8_t*)&s, sizeof(s)))
    {
      FL_TxStr("[FLASH] Read sample failed\r\n");
      return;
    }
    addr += sizeof(s);

    int32_t yaw_i = (int32_t)s.yaw_x16 / 16;
    int32_t yaw_f = (int32_t)s.yaw_x16 % 16; if (yaw_f < 0) yaw_f = -yaw_f;
    int32_t yaw_frac = yaw_f * 625;

    int32_t pitch_i = (int32_t)s.pitch_x16 / 16;
    int32_t pitch_f = (int32_t)s.pitch_x16 % 16; if (pitch_f < 0) pitch_f = -pitch_f;
    int32_t pitch_frac = pitch_f * 625;

    int32_t roll_i = (int32_t)s.roll_x16 / 16;
    int32_t roll_f = (int32_t)s.roll_x16 % 16; if (roll_f < 0) roll_f = -roll_f;
    int32_t roll_frac = roll_f * 625;

    FL_TxPrintf("t=%lu ms, YAW=%ld.%04ld, PITCH=%ld.%04ld, ROLL=%ld.%04ld\r\n",
                (unsigned long)s.tick_ms,
                (long)yaw_i, (long)yaw_frac,
                (long)pitch_i, (long)pitch_frac,
                (long)roll_i, (long)roll_frac);
  }

  FL_TxStr("[FLASH] PLAY done\r\n");
}
