/* File: NimaLTD.I-CUBE-SPIF_conf.h                                                     // HE: קובץ קונפיגורציה לדרייבר SPIF
   Why: בחירת מצב Debug, בחירת HAL או HAL+DMA, ובחירת RTOS או ללא RTOS                 // HE: למה הקובץ קיים
*/

#ifndef _NIMALTD_I_CUBE_SPIF_CONF_H_                                                     // HE: מניעת הכללה כפולה
#define _NIMALTD_I_CUBE_SPIF_CONF_H_                                                     // HE: סימון guard

#ifdef __cplusplus                                                                       // HE: אם קומפילציה ב-C++
extern "C" {                                                                              // HE: התאמה ל-C
#endif                                                                                    // HE: סוף התאמה

#define SPIF_DEBUG_DISABLE                    0                                          // HE: מצב Debug כבוי
#define SPIF_DEBUG_MIN                        1                                          // HE: מצב Debug מינימלי
#define SPIF_DEBUG_FULL                       2                                          // HE: מצב Debug מלא

#define SPIF_PLATFORM_HAL                     0                                          // HE: שימוש ב-HAL ללא DMA
#define SPIF_PLATFORM_HAL_DMA                 1                                          // HE: שימוש ב-HAL עם DMA

#define SPIF_RTOS_DISABLE                     0                                          // HE: ללא RTOS
#define SPIF_RTOS_CMSIS_V1                    1                                          // HE: CMSIS V1
#define SPIF_RTOS_CMSIS_V2                    2                                          // HE: CMSIS V2
#define SPIF_RTOS_THREADX                     3                                          // HE: ThreadX

#define SPIF_DEBUG      SPIF_DEBUG_DISABLE                                           // HE: בחר Debug כבוי
#define SPIF_PLATFORM   SPIF_PLATFORM_HAL                                             // HE: בחר HAL רגיל
#define SPIF_RTOS       SPIF_RTOS_DISABLE                                             // HE: בחר ללא RTOS

#ifdef __cplusplus                                                                       // HE: אם קומפילציה ב-C++
}                                                                                        // HE: סוף extern "C"
#endif                                                                                    // HE: סוף התאמה

#endif /* _NIMALTD_I_CUBE_SPIF_CONF_H_ */                                                // HE: סוף guard
