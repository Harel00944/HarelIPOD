/* File: sd_mp3_list.h                                                                                          // HE: כותרת מודול לסריקת רשימת קבצי MP3 מה-SD
   Why: Provide a small, isolated API to scan the SD card (FatFs) and return MP3 filenames for the menu (option K). // HE: למה הקובץ קיים, כדי להפריד סריקה מהתפריט
*/

#ifndef SD_MP3_LIST_H                                                                                             // HE: מניעת הכללה כפולה
#define SD_MP3_LIST_H                                                                                             // HE: סוף הגדרת include guard

#ifdef __cplusplus                                                                                               // HE: תאימות C++
extern "C" {                                                                                                      // HE: פתיחת בלוק extern "C"
#endif                                                                                                            // HE: סוף תאימות C++

#include "ff.h"                                                                                                   // HE: FatFs types, FRESULT, FILINFO

#ifndef SD_MP3_LIST_MAX_FILES                                                                                     // HE: אם לא הוגדר מבחוץ
#define SD_MP3_LIST_MAX_FILES          16u                                                                         // HE: מקסימום קבצים שנחזיר לרשימה
#endif                                                                                                            // HE: סוף הגדרה

#ifndef SD_MP3_LIST_MAX_NAME                                                                                      // HE: אם לא הוגדר מבחוץ
#define SD_MP3_LIST_MAX_NAME           64u                                                                         // HE: מקסימום אורך שם קובץ (כולל '\0')
#endif                                                                                                            // HE: סוף הגדרה

typedef struct                                                                                                    // HE: מבנה לפלט סריקה
{                                                                                                                 // HE: פתיחת struct
  uint16_t count;                                                                                                 // HE: כמה קבצי MP3 נמצאו
  char     names[SD_MP3_LIST_MAX_FILES][SD_MP3_LIST_MAX_NAME];                                                    // HE: מערך שמות קבצים
} SdMp3List_t;                                                                                                    // HE: שם הטיפוס

FRESULT SD_MP3_ListScanRoot(SdMp3List_t* out_list);                                                               // HE: סריקה של root (0:/) והחזרת רשימת MP3

FRESULT SD_MP3_ListScanDir(const char* dir_path, SdMp3List_t* out_list);                                          // HE: סריקה של תיקייה נתונה (למשל "0:/MUSIC")

#ifdef __cplusplus                                                                                               // HE: תאימות C++
}                                                                                                                 // HE: סגירת extern "C"
#endif                                                                                                            // HE: סוף תאימות C++

#endif                                                                                                            // HE: סוף include guard
