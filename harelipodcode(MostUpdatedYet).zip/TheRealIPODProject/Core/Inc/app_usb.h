/* File: app_usb.h
   Why: USB CDC application module, handles menu, RX FIFO, GPS/BNO modes, SPI Flash tests, and BNO055 record/playback via SPI Flash.
*/

#ifndef APP_USB_H
#define APP_USB_H

#include <stdint.h>
#include "main.h"          /* HAL handles */
#include "spif.h"          /* SPIF_HandleTypeDef */

/* Called from main after peripherals init */
void APP_USB_Init(SPI_HandleTypeDef *hspi_flash,
                  GPIO_TypeDef *flash_cs_port,
                  uint16_t flash_cs_pin,
                  uint8_t bno_ready);

/* Called periodically from main loop */
void APP_USB_Tick(void);

/* Called from USBD CDC receive (from usbd_cdc_if.c) */
void APP_USB_CDC_RxCallback(uint8_t *Buf, uint32_t Len);


/* File: app_usb.h  // HE: הצהרות לפונקציות של app_usb כדי לבטל implicit declaration */

void APP_USB_SD_Attach(SD_HandleTypeDef *hsd,
                       GPIO_TypeDef *cd_port,
                       uint16_t cd_pin);

void APP_USB_VS1053_Attach(SPI_HandleTypeDef *hspi_vs1053,
                           GPIO_TypeDef *xcs_port,  uint16_t xcs_pin,
                           GPIO_TypeDef *xdcs_port, uint16_t xdcs_pin,
                           GPIO_TypeDef *dreq_port, uint16_t dreq_pin,
                           GPIO_TypeDef *rst_port,  uint16_t rst_pin);



void APP_USB_SD_Attach(SD_HandleTypeDef *hsd,
                       GPIO_TypeDef *cd_port,
                       uint16_t cd_pin);
#endif
