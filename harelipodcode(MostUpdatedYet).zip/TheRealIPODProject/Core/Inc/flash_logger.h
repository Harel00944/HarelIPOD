#ifndef FLASH_LOGGER_H
#define FLASH_LOGGER_H

#include <stdint.h>
#include "spif.h"

/* USER CODE BEGIN Includes */
/* USER CODE END Includes */

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*FL_TxFunc)(const uint8_t *buf, uint16_t len);

void FL_Init(SPIF_HandleTypeDef *spif, FL_TxFunc tx);
void FL_Tick(void);

void FL_ListRecordingsToUSB(void);
void FL_PlayRecordingToUSB(uint32_t index);

void FL_StartRecording_10s(uint32_t sample_period_ms);
void FL_FormatStorage(void);

#ifdef __cplusplus
}
#endif

#endif
