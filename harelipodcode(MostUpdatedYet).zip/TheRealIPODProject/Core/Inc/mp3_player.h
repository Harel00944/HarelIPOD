/* File: mp3_player.h                                                                         // HE: כותרת מודול ניגון MP3 מה-SD ל-VS1053
   Why: API לניגון קובץ מה-SD בצורה פשוטה, כולל שמירת קודי שגיאה לאבחון.                      // HE: למה הקובץ קיים
*/
#ifndef MP3_PLAYER_H                                                                           // HE: include guard
#define MP3_PLAYER_H                                                                           // HE: include guard

#include <stdint.h>                                                                            // HE: טיפוסים סטנדרטיים
#include "ff.h"                                                                                // HE: FatFs types (FRESULT)

#ifdef __cplusplus                                                                             // HE: תאימות C++
extern "C" {                                                                                   // HE: תאימות C++
#endif
// HE: תאימות C++

int     MP3P_Start(const char *filename);                                             // HE: התחלת ניגון (לא חוסם)
void    MP3P_Stop(void);                                                              // HE: עצירת ניגון
void    MP3P_Tick(void);                                                              // HE: לשלוח עוד נתונים בכל Tick
uint8_t MP3P_IsPlaying(void);


int     MP3P_PlayFile_Blocking(const char *filename);                                          // HE: ניגון חוסם של קובץ
FRESULT MP3P_GetLastFresult(void);                                                             // HE: קבלת קוד השגיאה האחרון של FatFs
int     MP3P_GetLastErrStep(void);                                                             // HE: קבלת שלב השגיאה האחרון (למי שרוצה דיבוג)

#ifdef __cplusplus                                                                             // HE: תאימות C++
}                                                                                               // HE: תאימות C++
#endif                                                                                         // HE: תאימות C++

#endif                                                                                         // HE: סוף include guard
