/* File: gps_m8q.h */                                               // HE: כותרת דרייבר GPS ל u-blox MAX-M8Q עם UART + RESET + EXTINT + TIMEPULSE
/* Why: מאפשר סטרים RAW של כל בייט כדי לוודא שמגיע מידע מה-GPS */     // HE: למה הקובץ קיים

#ifndef GPS_M8Q_H
#define GPS_M8Q_H

#include "main.h"
#include <stdint.h>

typedef struct {
    double  lat_deg;
    double  lon_deg;
    double  altitude_m;
    uint8_t used_gps;
    uint8_t hour;
    uint8_t minute;
    uint8_t second;
    uint8_t fix;
    uint32_t timepulse_count;
} GPS_Data_t;

void GPS_M8Q_Init(UART_HandleTypeDef *huart);
void GPS_M8Q_RxCpltCallback(void);
void GPS_M8Q_TimepulseExtiCallback(uint16_t gpio_pin);

void GPS_M8Q_ResetPulse(uint32_t low_ms);
void GPS_M8Q_ExtintPulse(uint32_t high_ms);

const GPS_Data_t* GPS_M8Q_GetLastData(void);

/* NMEA line API (אם תרצה עדיין) */
uint8_t GPS_M8Q_HasNewNmeaLine(void);
void GPS_M8Q_PrintNmeaLine_USB(void);

/* RAW stream API (חדש) */
void GPS_M8Q_UsbStreamRawBytes(void);                                // HE: הדפס כל בייט שמתקבל

uint8_t GPS_M8Q_HasNewSolution(void);
void GPS_M8Q_ClearNewSolutionFlag(void);

/* Debug counters */
uint32_t GPS_M8Q_GetUartRxByteCount(void);
uint32_t GPS_M8Q_GetNmeaLineCount(void);

#endif
