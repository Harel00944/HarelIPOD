/* File: st7735.h                                      // Header file that declares ST7735 driver API
   This header is included by main.c so that the TFT functions can be used */

#ifndef ST7735_H_                                      // Open include guard to prevent multiple inclusion of this file
#define ST7735_H_                                      // Define the include guard macro so the compiler knows it's active

#include "stm32f4xx_hal.h"                             // Include STM32 HAL header for GPIO and SPI structures and HAL functions
#include <stdint.h>                                    // Include standard integer type definitions such as uint8_t and uint16_t
#ifndef ST7735_XSTART                                                                               // HE: offset אופקי לפי וריאנט
#define ST7735_XSTART  0u                                                                          // HE: נסה 0, ואם יש רעש נסה 2
#endif

#ifndef ST7735_YSTART                                                                               // HE: offset אנכי לפי וריאנט
#define ST7735_YSTART  0u                                                                          // HE: נסה 0, ואם יש רעש נסה 1 או 2
#endif

#define ST7735_WIDTH   160                             // Logical width of the ST7735 display in pixels, used by drawing functions
#define ST7735_HEIGHT  128                             // Logical height of the ST7735 display in pixels, used for bounds checking

/* Pin mapping for control lines used by ST7735 (YOUR PINS) */
#define ST7735_CS_GPIO    GPIOB                        // Chip Select GPIO port
#define ST7735_CS_PIN     GPIO_PIN_7                   // CS = PB7

#define ST7735_DC_GPIO    GPIOB                        // Data/Command GPIO port
#define ST7735_DC_PIN     GPIO_PIN_12                  // DC = PB12

#define ST7735_RES_GPIO   GPIOB                        // Reset GPIO port
#define ST7735_RES_PIN    GPIO_PIN_14                  // RES = PB14

#define ST7735_BL_GPIO    GPIOB                        // Backlight GPIO port
#define ST7735_BL_PIN     GPIO_PIN_6                   // BL = PB6

/* SPI handle used for communication with display controller */
extern SPI_HandleTypeDef hspi2;                        // Use SPI2 handle (PB13=SCK, PB15=MOSI)

/* Color definitions in RGB565 format */
#define ST7735_COLOR_BLACK  0x0000                     // RGB565 code for black, used as background color
#define ST7735_COLOR_WHITE  0xFFFF                     // RGB565 code for white, used as foreground color

/* Public API function prototypes used by the main program */
void ST7735_Init(void);                                // Initialize display controller registers and exit sleep mode
void ST7735_FillScreen(uint16_t color);                // Fill entire screen area with the specified RGB565 color
void ST7735_ShowHarel(void);                           // Draw the word “HAREL” centered using a built-in mini font
void ST7735_ShowSentenceAt(const char *text,           // Draw a sentence at position (x, y)
                           uint16_t x,
                           uint16_t y,
                           uint16_t fg,
                           uint16_t bg);

/* New public functions for 5x7 text rendering */
void ST7735_DrawChar5x7(char c,                        // Draws a single 5x7 character
                        uint16_t x,                    // X coordinate on screen
                        uint16_t y,                    // Y coordinate on screen
                        uint16_t fg,                   // Foreground color
                        uint16_t bg);                  // Background color behind pixels

void ST7735_DrawText5x7(const char *text,              // Draws a null-terminated string
                        uint16_t x,                    // Starting X position
                        uint16_t y,                    // Starting Y position
                        uint16_t fg,                   // Foreground color
                        uint16_t bg);                  // Background color
/* File: st7735.h
   Why: Add small-area text drawing API for MP3 playback mode
*/
void ST7735_ShowTextScaled_At(const char *text, uint16_t x, uint16_t y, uint8_t scale); // HE: טקסט במיקום בלי FillScreen

void ST7735_ShowSentenceCenter(const char *text);      // Draw a sentence centered (helper)
/* File: st7735.h */                                                    // HE: קובץ כותרת ל-ST7735
void ST7735_SetRotation(uint8_t rot);                                   // HE: קביעת סיבוב 0..3
void ST7735_ShowSentenceCenterScaled(const char *text, uint8_t scale);  // HE: טקסט מרכזי עם הגדלה
void ST7735_FillRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color);             // HE: מילוי מלבן מהיר
#endif /* ST7735_H_ */                                 // Close the include guard to finish file protection
