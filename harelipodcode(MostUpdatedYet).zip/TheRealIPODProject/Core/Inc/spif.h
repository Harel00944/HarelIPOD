/* File: spif.h                                                                          // HE: קובץ כותרת לדרייבר SPI FLASH
   Why: הצהרות API ומבנים כדי להשתמש בדרייבר בכל הפרויקט                                // HE: למה הקובץ קיים
*/

#ifndef _SPIF_H_                                                                         // HE: מניעת הכללה כפולה
#define _SPIF_H_                                                                         // HE: סימון guard

#ifdef __cplusplus                                                                       // HE: אם קומפילציה ב-C++
extern "C" {                                                                             // HE: התאמה ל-C
#endif                                                                                    // HE: סוף התאמה

#include <stdbool.h>                                                                     // HE: טיפוס bool
#include <stdint.h>                                                                      // HE: טיפוסי uint32_t וכו'
#include <string.h>                                                                      // HE: memset, memcpy
#include "main.h"                                                                        // HE: הגדרות פרויקט ו-HAL (כולל GPIO typedef)
#include "stm32f4xx_hal.h"                                                               // HE: HAL בסיסי כולל SPI_HandleTypeDef
#include "NimaLTD.I-CUBE-SPIF_conf.h"                                                    // HE: קונפיגורציה לדרייבר

/* הגדרות נפוצות של זיכרון SPI NOR */                                                   // HE: הערה כללית
#define SPIF_PAGE_SIZE                      0x100U                                      // HE: גודל עמוד 256B
#define SPIF_SECTOR_SIZE                    0x1000U                                     // HE: גודל סקטור 4KB
#define SPIF_BLOCK_SIZE                     0x10000U                                    // HE: גודל בלוק 64KB

#define SPIF_PageToAddress(PageNumber)     ((uint32_t)(PageNumber) * SPIF_PAGE_SIZE)    // HE: המרה עמוד לכתובת
#define SPIF_SectorToAddress(SectorNumber) ((uint32_t)(SectorNumber) * SPIF_SECTOR_SIZE)// HE: המרה סקטור לכתובת
#define SPIF_BlockToAddress(BlockNumber)   ((uint32_t)(BlockNumber) * SPIF_BLOCK_SIZE)  // HE: המרה בלוק לכתובת
#define SPIF_AddressToPage(Address)        ((uint32_t)(Address) / SPIF_PAGE_SIZE)       // HE: המרה כתובת לעמוד
#define SPIF_AddressToSector(Address)      ((uint32_t)(Address) / SPIF_SECTOR_SIZE)     // HE: המרה כתובת לסקטור
#define SPIF_AddressToBlock(Address)       ((uint32_t)(Address) / SPIF_BLOCK_SIZE)      // HE: המרה כתובת לבלוק

typedef enum                                                                             // HE: מזהי יצרן JEDEC נפוצים
{
  SPIF_MANUFACTOR_ERROR      = 0x00,                                                     // HE: לא ידוע
  SPIF_MANUFACTOR_WINBOND    = 0xEF,                                                     // HE: Winbond
  SPIF_MANUFACTOR_ISSI       = 0x9D,                                                     // HE: ISSI
  SPIF_MANUFACTOR_MICRON     = 0x20,                                                     // HE: Micron
  SPIF_MANUFACTOR_GIGADEVICE = 0xC8,                                                     // HE: GigaDevice
  SPIF_MANUFACTOR_MACRONIX   = 0xC2                                                      // HE: Macronix
} SPIF_ManufactorTypeDef;                                                                // HE: שם הטיפוס

typedef struct                                                                           // HE: Handle של הדרייבר
{
  SPI_HandleTypeDef      *HSpi;                                                          // HE: מצביע ל-HAL SPI
  GPIO_TypeDef           *CsGpio;                                                        // HE: פורט של CS
  uint16_t                CsPin;                                                         // HE: פין של CS
  uint8_t                 Inited;                                                        // HE: האם אתחלנו
  uint8_t                 Lock;                                                          // HE: מנעול פשוט
  uint8_t                 MemType;                                                       // HE: Byte 2 מ-JEDEC
  uint8_t                 SizeCode;                                                      // HE: Byte 3 מ-JEDEC
  SPIF_ManufactorTypeDef  Manufactor;                                                    // HE: יצרן
  uint32_t                JedecId;                                                       // HE: JEDEC ID מלא 24bit
} SPIF_HandleTypeDef;                                                                    // HE: שם הטיפוס

bool SPIF_Init(SPIF_HandleTypeDef *h, SPI_HandleTypeDef *hspi, GPIO_TypeDef *csPort, uint16_t csPin); // HE: אתחול דרייבר
bool SPIF_ReadJedecId(SPIF_HandleTypeDef *h, uint8_t *mfg, uint8_t *memType, uint8_t *capacity);      // HE: קריאת JEDEC

bool SPIF_Read(SPIF_HandleTypeDef *h, uint32_t addr, uint8_t *data, uint32_t len);       // HE: קריאה מהזיכרון
bool SPIF_Write(SPIF_HandleTypeDef *h, uint32_t addr, const uint8_t *data, uint32_t len);// HE: כתיבה (Page Program)
bool SPIF_EraseSector(SPIF_HandleTypeDef *h, uint32_t sectorNumber);                     // HE: מחיקת סקטור 4KB

bool SPIF_Test(SPIF_HandleTypeDef *h, uint32_t testAddr);                                // HE: טסט תקינות בסיסי

#ifdef __cplusplus                                                                       // HE: אם קומפילציה ב-C++
}                                                                                        // HE: סוף extern "C"
#endif                                                                                    // HE: סוף התאמה

#endif /* _SPIF_H_ */                                                                     // HE: סוף guard
