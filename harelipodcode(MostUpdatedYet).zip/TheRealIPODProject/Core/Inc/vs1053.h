/* File: vs1053.h
   Why: Header update to expose continuous sine start/stop API.
*/

#pragma once

#include "stm32f4xx_hal.h"
#include <stddef.h>
#include <stdint.h>

typedef enum
{
    VS1053_OK = 0,
    VS1053_ERR,
    VS1053_TIMEOUT
} VS1053_Status_t;

typedef struct
{
    SPI_HandleTypeDef *hspi;

    GPIO_TypeDef *xcs_port;
    uint16_t xcs_pin;

    GPIO_TypeDef *xdcs_port;
    uint16_t xdcs_pin;

    GPIO_TypeDef *dreq_port;
    uint16_t dreq_pin;

    GPIO_TypeDef *rst_port;
    uint16_t rst_pin;
} VS1053_Handle_t;

void VS1053_Attach(VS1053_Handle_t *dev);

VS1053_Status_t VS1053_ResetHard(void);
VS1053_Status_t VS1053_ResetSoft(void);

uint16_t VS1053_SCI_Read(uint8_t addr);
VS1053_Status_t VS1053_SCI_Write(uint8_t addr, uint16_t value);

VS1053_Status_t VS1053_SetClockF(uint16_t clockf);
VS1053_Status_t VS1053_SetVolume(uint8_t left, uint8_t right);
VS1053_Status_t VS1053_SetBassTreble(uint8_t bass, uint8_t treble);

VS1053_Status_t VS1053_SDI_Send(const uint8_t *data, size_t len);

VS1053_Status_t VS1053_Init(void);

VS1053_Status_t VS1053_SineTest_Start(uint8_t freq_code);
VS1053_Status_t VS1053_SineTest_Stop(void);

VS1053_Status_t VS1053_Test_Option8(uint32_t ms_play);

/* New continuous sine API */
VS1053_Status_t VS1053_Test_SineContinuousStart(uint8_t freq_code, uint8_t volL, uint8_t volR);
VS1053_Status_t VS1053_Test_SineContinuousStop(void);
