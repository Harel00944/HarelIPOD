/* File: BNO055.h */                                                      // HE: קובץ כותרת לדרייבר BNO055
/* Why: מצהיר רגיסטרים, טיפוסים ו־API לדרייבר, כולל RESET חומרתי על PC0 */ // HE: למה הקובץ הזה קיים

#ifndef INC_BNO055_H_                                                     // HE: הגנה מכפילות include
#define INC_BNO055_H_                                                     // HE: תחילת guard

#include <stdint.h>                                                       // HE: טיפוסים סטנדרטיים
#include <stdbool.h>                                                      // HE: טיפוס bool

/* Default BNO055 I2C address (7-bit) */                                  // HE: כתובת I2C ברירת מחדל (7bit)
#define BNO055_I2C_ADDR              0x28                                  // HE: 0x28 או 0x29 לפי ADR, אצלך משוך ל־GND

/* Main registers */                                                      // HE: כתובות רגיסטרים עיקריים
#define BNO055_CHIP_ID               0x00                                  // HE: Chip ID
#define BNO055_SW_REV_ID_LSB         0x04                                  // HE: גרסת תוכנה LSB
#define BNO055_SW_REV_ID_MSB         0x05                                  // HE: גרסת תוכנה MSB
#define BNO055_BL_REV_ID             0x06                                  // HE: גרסת Bootloader
#define BNO055_PAGE_ID               0x07                                  // HE: בחירת עמוד רגיסטרים

#define BNO055_ACC_DATA_X_LSB        0x08                                  // HE: תאוצה X LSB
#define BNO055_MAG_DATA_X_LSB        0x0E                                  // HE: מגנטומטר X LSB
#define BNO055_GYR_DATA_X_LSB        0x14                                  // HE: ג'יירו X LSB
#define BNO055_EUL_HEADING_LSB       0x1A                                  // HE: Euler Heading LSB
#define BNO055_QUA_DATA_W_LSB        0x20                                  // HE: Quaternion W LSB
#define BNO055_LIA_DATA_X_LSB        0x28                                  // HE: Linear Accel X LSB
#define BNO055_GRV_DATA_X_LSB        0x2E                                  // HE: Gravity X LSB

#define BNO055_TEMP                  0x34                                  // HE: טמפ'
#define BNO055_CALIB_STAT            0x35                                  // HE: סטטוס כיול
#define BNO055_ST_RESULT             0x36                                  // HE: תוצאת Self Test
#define BNO055_SYS_STATUS            0x39                                  // HE: סטטוס מערכת
#define BNO055_SYS_ERR               0x3A                                  // HE: שגיאת מערכת

#define BNO055_UNIT_SEL              0x3B                                  // HE: בחירת יחידות
#define BNO055_OPR_MODE              0x3D                                  // HE: מצב פעולה
#define BNO055_PWR_MODE              0x3E                                  // HE: מצב צריכת חשמל
#define BNO055_SYS_TRIGGER           0x3F                                  // HE: טריגרים מערכתיים
#define BNO055_AXIS_MAP_CONFIG       0x41                                  // HE: מיפוי צירים
#define BNO055_AXIS_MAP_SIGN         0x42                                  // HE: סימן צירים

#define BNO055_ACC_OFFSET_X_LSB      0x55                                  // HE: אופסטים תאוצה

typedef enum                                                               // HE: מצבי עבודה אפשריים
{
    BNO055_OPERATION_MODE_CONFIG = 0x00,                                   // HE: מצב קונפיגורציה
    BNO055_OPERATION_MODE_NDOF   = 0x0C                                    // HE: NDOF פיוז'ן מלא
} bno055_opmode_t;                                                         // HE: typedef

typedef struct                                                             // HE: וקטור כללי (Euler/Accel/Gyro וכו')
{
    double w;                                                              // HE: רכיב W (ל־Quaternion)
    double x;                                                              // HE: רכיב X
    double y;                                                              // HE: רכיב Y
    double z;                                                              // HE: רכיב Z
} bno055_vector_t;                                                         // HE: typedef

typedef struct                                                             // HE: סטטוס כיול לפי 2 ביט לכל חיישן
{
    uint8_t sys;                                                           // HE: כיול מערכת
    uint8_t gyro;                                                          // HE: כיול ג'יירו
    uint8_t accel;                                                         // HE: כיול תאוצה
    uint8_t mag;                                                           // HE: כיול מגנטומטר
} bno055_calibration_state_t;                                              // HE: typedef

/* Public API */                                                           // HE: פונקציות ציבוריות
void bno055_setup(void);                                                   // HE: אתחול חיישן
void bno055_reset(void);                                                   // HE: ריסט (חומרתי אם זמין, אחרת תוכנתי)

void bno055_setOperationMode(bno055_opmode_t mode);                        // HE: קביעת מצב פעולה
void bno055_setOperationModeConfig(void);                                  // HE: מעבר לקונפיג
void bno055_setOperationModeNDOF(void);                                    // HE: מעבר ל־NDOF

int8_t  bno055_getTemp(void);                                              // HE: קריאת טמפ'
uint8_t bno055_getSystemStatus(void);                                      // HE: קריאת סטטוס מערכת
uint8_t bno055_getSystemError(void);                                       // HE: קריאת קוד שגיאה
bno055_calibration_state_t bno055_getCalibrationState(void);               // HE: סטטוס כיול

uint8_t BNO055_ReadLinAcc_raw(int16_t *ax, int16_t *ay, int16_t *az);                                  // HE: קריאת Linear Acceleration בצירי החיישן, RAW

uint8_t BNO055_ReadWorldLinAcc_g(float *ax_w,
                                float *ay_w,
                                float *az_w
                                           );
uint8_t BNO055_ReadUnitSel(uint8_t *unit_sel);

bno055_vector_t bno055_getVectorEuler(void);                               // HE: Euler (Heading/Roll/Pitch)
bno055_vector_t bno055_getVectorQuaternion(void);                          // HE: Quaternion
bno055_vector_t bno055_getVectorAccelerometer(void);                       // HE: Accelerometer
bno055_vector_t bno055_getVectorGyroscope(void);                           // HE: Gyroscope
bno055_vector_t bno055_getVectorMagnetometer(void);                        // HE: Magnetometer
bno055_vector_t bno055_getVectorLinearAccel(void);                         // HE: Linear Accel
bno055_vector_t bno055_getVectorGravity(void);                             // HE: Gravity

/* Low level */                                                            // HE: שכבת HAL נמוכה
void bno055_delay(int time_ms);                                            // HE: השהייה
void bno055_writeData(uint8_t reg, uint8_t data);                          // HE: כתיבה לרגיסטר
int bno055_readData(uint8_t reg, uint8_t *data, uint8_t len);                      // HE: 0=OK, אחרת כשל

/* Helper: convert raw Euler to degrees */                                 // HE: עזר להמרת Euler לעלות
void bno055_euler_to_deg(const bno055_vector_t *raw,                        // HE: קלט וקטור גולמי
                         double *heading_deg,                               // HE: Heading/Yaw במעלות
                         double *roll_deg,                                  // HE: Roll במעלות
                         double *pitch_deg);                                // HE: Pitch במעלות

#endif                                                                      // HE: סוף guard
