/* File: Core/Inc/sdcard.h                                                                            // HE: כותרת דרייבר SD Card
   Why: API אחיד ל-SDIO HAL + RAW block IO + FatFs mount + TEST, מותאם ל-CD1=PA8 בפרויקט שלך             // HE: למה הקובץ קיים
*/
#ifndef SDCARD_H                                                                                         // HE: הגנת include
#define SDCARD_H                                                                                         // HE: הגנת include

#include <stdbool.h>                                                                                    // HE: bool
#include <stdint.h>                                                                                      // HE: uint32_t וכו
#include "stm32f4xx_hal.h"                                                                               // HE: HAL
#include "stm32f4xx_hal_sd.h"                                                                            // HE: HAL SDIO
#include "ff.h"                                                                                          // HE: FatFs טיפוסים

#ifndef SD_TIMEOUT                                                                                       // HE: timeout ברירת מחדל
#define SD_TIMEOUT (30u * 1000u)                                                                         // HE: 30 שניות
#endif                                                                                                   // HE: סוף ifndef

typedef struct                                                                                            // HE: מבנה מידע כרטיס
{
  HAL_SD_CardCIDTypeDef cid;                                                                             // HE: CID
  HAL_SD_CardCSDTypeDef csd;                                                                             // HE: CSD
  HAL_SD_CardInfoTypeDef info;                                                                           // HE: CardInfo
  uint32_t block_size;                                                                                   // HE: גודל בלוק
  uint32_t block_count;                                                                                  // HE: מספר בלוקים
  uint64_t capacity_bytes;                                                                               // HE: קיבולת בבייטים
} SDCard_Info_t;                                                                                          // HE: שם טיפוס

HAL_StatusTypeDef SDCard_Init(void);                                                                     // HE: אתחול SDIO + 4bit
HAL_StatusTypeDef SDCard_GetInfo(SDCard_Info_t *out);                                                    // HE: שליפת מידע
HAL_StatusTypeDef SDCard_ReadBlocks(uint8_t *pData, uint32_t start_block, uint32_t num_blocks, uint32_t timeout_ms);   // HE: קריאה RAW
HAL_StatusTypeDef SDCard_WriteBlocks(const uint8_t *pData, uint32_t start_block, uint32_t num_blocks, uint32_t timeout_ms); // HE: כתיבה RAW
FRESULT SDCard_Mount(void);                                                                              // HE: mount ל-FatFs
FRESULT SDCard_Unmount(void);                                                                            // HE: unmount
bool SDCard_Test_All(void);                                                                              // HE: RAW + FatFs test

#endif /* SDCARD_H */                                                                                    // HE: סוף קובץ
