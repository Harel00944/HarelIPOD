/* File: sd_tests.h                                                                                 // HE: כותרת לפונקציות בדיקת SD, כדי לפתור undefined reference בלינקר
   Why: Provide prototypes for SD test functions referenced by app_usb.c                            // HE: למה הקובץ קיים
*/
#ifndef SD_TESTS_H                                                                                  // HE: הגנה מהכללה כפולה
#define SD_TESTS_H                                                                                  // HE: הגדרת מאקרו הגנה

#ifdef __cplusplus                                                                                  // HE: תאימות ל-C++
extern "C" {                                                                                        // HE: תחילת בלוק C
#endif                                                                                              // HE: סוף תאימות C++

void SD_Test_SDIO_Registers(void);                                                                  // HE: בדיקת רגיסטרים בסיסית ל-SDIO
void SD_Test_DetailedInfo(void);                                                                    // HE: הדפסת מידע מפורט על כרטיס SD
void SD_Test_FatFs_Extended(void);                                                                  // HE: בדיקה מורחבת ל-FatFs על ה-SD

#ifdef __cplusplus                                                                                  // HE: תאימות ל-C++
}                                                                                                   // HE: סוף בלוק C
#endif                                                                                              // HE: סוף תאימות C++

#endif /* SD_TESTS_H */                                                                             // HE: סוף הגנה מהכללה כפולה
